/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { createContext, useContext, useState, useEffect, useRef, useCallback } from 'react';
import {
  Patient,
  ClinicalAlert,
  AuditLogEntry,
  UserProfile,
  UserRole,
  RiskThresholds,
  MLModelType,
  PatientMeasurement,
  ClinicalNote,
} from '../types/sepsis';
import { generateInitialIcuCohort } from '../services/syntheticPatients';
import { DEFAULT_THRESHOLDS, runSepsisPrediction } from '../services/mlEngine';
import { simulateNextStep, SimulationScenarioId, SIMULATION_SCENARIOS } from '../services/simulationService';

export type NavView =
  | 'overview'
  | 'icu-monitor'
  | 'patients'
  | 'alerts'
  | 'model-performance'
  | 'simulation'
  | 'reports'
  | 'data-import'
  | 'audit-logs'
  | 'settings';

export interface AppContextType {
  // Navigation & User
  currentView: NavView;
  setCurrentView: (view: NavView) => void;
  selectedPatientId: string | null;
  setSelectedPatientId: (id: string | null) => void;
  currentUser: UserProfile;
  setCurrentUser: (user: UserProfile) => void;
  switchUserRole: (role: UserRole) => void;

  // Patient & Clinical Data
  patients: Patient[];
  setPatients: React.Dispatch<React.SetStateAction<Patient[]>>;
  selectedPatient: Patient | null;
  alerts: ClinicalAlert[];
  unacknowledgedAlertsCount: number;
  acknowledgeAlert: (alertId: string, note?: string) => void;
  addMeasurementToPatient: (patientId: string, measurement: Partial<PatientMeasurement>) => void;
  importPatients: (newPatients: Patient[]) => void;

  // Clinical Notes
  clinicalNotes: ClinicalNote[];
  addClinicalNote: (note: Omit<ClinicalNote, 'id' | 'timestamp'>) => void;
  updateClinicalNote: (id: string, updates: Partial<Pick<ClinicalNote, 'content' | 'title' | 'category' | 'isConfidential'>>) => void;
  deleteClinicalNote: (id: string) => void;

  // ML & System Config
  activeModel: MLModelType;
  setActiveModel: (model: MLModelType) => void;
  thresholds: RiskThresholds;
  setThresholds: (thresholds: RiskThresholds) => void;
  temperatureUnit: '°C' | '°F';
  setTemperatureUnit: (unit: '°C' | '°F') => void;
  staleHoursLimit: number;
  setStaleHoursLimit: (hours: number) => void;

  // Simulation
  simulationScenario: SimulationScenarioId;
  setSimulationScenario: (id: SimulationScenarioId) => void;
  isSimulating: boolean;
  simulationSpeed: number;
  setSimulationSpeed: (speed: number) => void;
  toggleSimulation: () => void;
  stepSimulationForward: () => void;
  resetSimulation: () => void;

  // Audit Log
  auditLogs: AuditLogEntry[];
  addAuditLog: (action: string, category: AuditLogEntry['category'], details: string, patientId?: string) => void;

  // Theme
  isDarkMode: boolean;
  toggleDarkMode: () => void;

  // Reset demo
  resetEntireDemo: () => void;
}

const AVAILABLE_USERS: Record<UserRole, UserProfile> = {
  Doctor: {
    id: 'u-101',
    name: 'Dr. Sarah Lin, MD',
    role: 'Doctor',
    department: 'Critical Care Medicine / Attending Intensivist',
  },
  Nurse: {
    id: 'u-102',
    name: 'Marcus Vance, BSN, RN',
    role: 'Nurse',
    department: 'Medical Intensive Care Unit (MICU)',
  },
  'Admin/Researcher': {
    id: 'u-103',
    name: 'Dr. Elena Rostova, PhD',
    role: 'Admin/Researcher',
    department: 'Clinical AI & Informatics Laboratory',
  },
};

const INITIAL_CLINICAL_NOTES: ClinicalNote[] = [
  {
    id: 'note-104-1',
    patientId: 'P-104',
    authorId: 'u-101',
    authorName: 'Dr. Sarah Lin, MD',
    authorRole: 'Doctor',
    authorTitle: 'Attending Intensivist',
    timestamp: new Date(Date.now() - 4 * 3600 * 1000).toISOString(),
    category: 'Assessment & Plan',
    title: 'Post-Hartmann Insidious Deterioration Review',
    content: 'Patient exhibiting subacute tachycardia (HR 108 bpm) and tachypnea (RR 24 bpm) with upward-drifting lactate (now 2.4 mmol/L). Abdomen mildly distended, tender in left lower quadrant. Blood cultures drawn x2 from central line and peripheral site. Initiated targeted piperacillin-tazobactam. Repeat lactate and blood gas ordered in 2 hours. Sepsis early warning risk estimated at 58.2% (Moderate-to-High). Will re-evaluate need for abdominal CT angiography if MAP dips below 65 mmHg.',
    linkedRiskScore: 58.2,
    linkedRiskLevel: 'HIGH',
    linkedObservationTime: new Date(Date.now() - 4 * 3600 * 1000).toISOString(),
  },
  {
    id: 'note-107-1',
    patientId: 'P-107',
    authorId: 'u-101',
    authorName: 'Dr. Sarah Lin, MD',
    authorRole: 'Doctor',
    authorTitle: 'Attending Intensivist',
    timestamp: new Date(Date.now() - 2 * 3600 * 1000).toISOString(),
    category: 'Resuscitation Response',
    title: 'Refractory Hypotension & Septic Shock Decompensation',
    content: 'Bedside evaluation in response to Critical Sepsis alert (Risk 92.4%). MAP plummeted to 52 mmHg despite 30 mL/kg crystalloid bolus. Lactate spiked to 5.4 mmol/L with worsening metabolic acidosis. Norepinephrine infusion initiated and titrated to maintain MAP >= 65 mmHg. Emergent surgical consult placed for necrotizing fasciitis debridement. Arterial line placed in right radial artery. Broad-spectrum meropenem + vancomycin + clindamycin administered.',
    linkedRiskScore: 92.4,
    linkedRiskLevel: 'CRITICAL',
    linkedObservationTime: new Date(Date.now() - 2 * 3600 * 1000).toISOString(),
  },
  {
    id: 'note-110-1',
    patientId: 'P-110',
    authorId: 'u-101',
    authorName: 'Dr. Sarah Lin, MD',
    authorRole: 'Doctor',
    authorTitle: 'Attending Intensivist',
    timestamp: new Date(Date.now() - 1 * 3600 * 1000).toISOString(),
    category: 'Resuscitation Response',
    title: 'Clinical Improvement Post-Antimicrobial Source Control',
    content: 'Telemetry trajectory shows substantial stabilization over past 6 hours. MAP stable at 78 mmHg off vasopressors. Serum lactate cleared from peak 4.6 down to 1.8 mmol/L. Urine output brisk (>0.8 mL/kg/hr). Respiratory rate normalized to 16 bpm. Sepsis early warning risk de-escalated to 24.1% (Low-Moderate). Continue current antimicrobial regimen.',
    linkedRiskScore: 24.1,
    linkedRiskLevel: 'LOW',
    linkedObservationTime: new Date(Date.now() - 1 * 3600 * 1000).toISOString(),
  },
];

const AppContext = createContext<AppContextType | null>(null);

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [currentView, setCurrentView] = useState<NavView>('overview');
  const [selectedPatientId, setSelectedPatientId] = useState<string | null>('P-104');
  const [currentUser, setCurrentUser] = useState<UserProfile>(AVAILABLE_USERS.Doctor);
  const [isDarkMode, setIsDarkMode] = useState<boolean>(true);

  // Core data
  const [patients, setPatients] = useState<Patient[]>([]);
  const [alerts, setAlerts] = useState<ClinicalAlert[]>([]);
  const [auditLogs, setAuditLogs] = useState<AuditLogEntry[]>([]);
  const [clinicalNotes, setClinicalNotes] = useState<ClinicalNote[]>(INITIAL_CLINICAL_NOTES);

  // Settings
  const [activeModel, setActiveModel] = useState<MLModelType>('Gradient Boosted Trees (XGBoost)');
  const [thresholds, setThresholds] = useState<RiskThresholds>(DEFAULT_THRESHOLDS);
  const [temperatureUnit, setTemperatureUnit] = useState<'°C' | '°F'>('°C');
  const [staleHoursLimit, setStaleHoursLimit] = useState<number>(4);

  // Simulation controls
  const [simulationScenario, setSimulationScenario] = useState<SimulationScenarioId>('gradual_deterioration');
  const [isSimulating, setIsSimulating] = useState<boolean>(false);
  const [simulationSpeed, setSimulationSpeed] = useState<number>(1);
  const simStepRef = useRef<number>(0);

  // Initialize demo data
  const initCohort = useCallback(() => {
    const { patients: initPatients, initialAlerts } = generateInitialIcuCohort();
    setPatients(initPatients);
    setAlerts(initialAlerts);
    setAuditLogs([
      {
        id: `aud-${Date.now()}-1`,
        timestamp: new Date().toISOString(),
        userId: currentUser.id,
        userName: currentUser.name,
        userRole: currentUser.role,
        category: 'SYSTEM',
        action: 'System Bootstrapped',
        details: 'Loaded ICU cohort (12 synthetic beds). Initialized ML ensemble v2.4.1.',
      },
      {
        id: `aud-${Date.now()}-2`,
        timestamp: new Date(Date.now() - 3600000).toISOString(),
        userId: currentUser.id,
        userName: currentUser.name,
        userRole: currentUser.role,
        category: 'ALERT',
        action: 'Critical Alert Raised',
        details: 'Automated alert trigger for P-107 (Bed ICU-07): Risk 92.4% (Severe Septic Shock onset).',
        patientId: 'P-107',
      },
    ]);
  }, [currentUser]);

  useEffect(() => {
    initCohort();
  }, [initCohort]);

  // Sync dark mode class on document element
  useEffect(() => {
    if (isDarkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [isDarkMode]);

  const toggleDarkMode = () => setIsDarkMode((prev) => !prev);

  const addAuditLog = useCallback(
    (action: string, category: AuditLogEntry['category'], details: string, patientId?: string) => {
      const entry: AuditLogEntry = {
        id: `aud-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
        timestamp: new Date().toISOString(),
        userId: currentUser.id,
        userName: currentUser.name,
        userRole: currentUser.role,
        category,
        action,
        details,
        patientId,
      };
      setAuditLogs((prev) => [entry, ...prev]);
    },
    [currentUser]
  );

  const switchUserRole = (role: UserRole) => {
    const newUser = AVAILABLE_USERS[role];
    setCurrentUser(newUser);
    addAuditLog('Role Switched', 'AUTH', `User switched active persona to ${newUser.name} (${role}).`);
  };

  const acknowledgeAlert = (alertId: string, note?: string) => {
    setAlerts((prev) =>
      prev.map((alt) => {
        if (alt.id === alertId) {
          return {
            ...alt,
            status: 'acknowledged',
            acknowledgedBy: `${currentUser.name} (${currentUser.role})`,
            acknowledgedAt: new Date().toISOString(),
            clinicalNote: note || 'Clinical review completed by attending team. Trajectory acknowledged.',
          };
        }
        return alt;
      })
    );
    const target = alerts.find((a) => a.id === alertId);
    addAuditLog(
      'Alert Acknowledged',
      'ALERT',
      `Alert for ${target?.patientName || 'Patient'} (${target?.bed}) acknowledged with note: "${note || 'Review completed'}"`,
      target?.patientId
    );
  };

  const addMeasurementToPatient = (patientId: string, raw: Partial<PatientMeasurement>) => {
    setPatients((prev) =>
      prev.map((p) => {
        if (p.id !== patientId) return p;

        const newMeasurement: PatientMeasurement = {
          id: `m-manual-${Date.now()}`,
          patientId: p.id,
          timestamp: raw.timestamp || new Date().toISOString(),
          heartRate: raw.heartRate ?? (p.latestMeasurement?.heartRate || 75),
          sbp: raw.sbp ?? (p.latestMeasurement?.sbp || 120),
          dbp: raw.dbp ?? (p.latestMeasurement?.dbp || 75),
          map: raw.map ?? Math.round((((raw.sbp ?? 120) + 2 * (raw.dbp ?? 75)) / 3) * 10) / 10,
          respiratoryRate: raw.respiratoryRate ?? (p.latestMeasurement?.respiratoryRate || 16),
          temperature: raw.temperature ?? (p.latestMeasurement?.temperature || 36.8),
          spo2: raw.spo2 ?? (p.latestMeasurement?.spo2 || 98),
          wbc: raw.wbc ?? (p.latestMeasurement?.wbc || 7.5),
          lactate: raw.lactate ?? (p.latestMeasurement?.lactate || 1.1),
          platelets: raw.platelets ?? (p.latestMeasurement?.platelets || 240),
          creatinine: raw.creatinine ?? (p.latestMeasurement?.creatinine || 0.9),
          glucose: raw.glucose ?? (p.latestMeasurement?.glucose || 110),
          isSynthetic: true,
        };

        const updatedHistory = [...p.history, newMeasurement];
        const newPred = runSepsisPrediction(
          newMeasurement,
          p.history,
          p.age,
          activeModel,
          thresholds
        );

        return {
          ...p,
          history: updatedHistory,
          latestMeasurement: newMeasurement,
          latestPrediction: newPred,
        };
      })
    );

    addAuditLog(
      'Manual Vitals Entered',
      'PREDICTION',
      `New clinical telemetry entered for ${patientId}; prediction recalculated.`,
      patientId
    );
  };

  const importPatients = (newPatients: Patient[]) => {
    setPatients((prev) => [...prev, ...newPatients]);
    addAuditLog(
      'Batch CSV Imported',
      'IMPORT',
      `Imported ${newPatients.length} new patient records into ICU monitoring grid.`
    );
  };

  const addClinicalNote = (noteData: Omit<ClinicalNote, 'id' | 'timestamp'>) => {
    const newNote: ClinicalNote = {
      ...noteData,
      id: `note-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
      timestamp: new Date().toISOString(),
    };
    setClinicalNotes((prev) => [newNote, ...prev]);
    addAuditLog(
      'Clinical Note Added',
      'ALERT',
      `Clinical note added by ${currentUser.name} (${currentUser.role}) for patient ${noteData.patientId} linked to risk observation ${noteData.linkedRiskScore}%: "${noteData.title}".`,
      noteData.patientId
    );
  };

  const updateClinicalNote = (id: string, updates: Partial<Pick<ClinicalNote, 'content' | 'title' | 'category' | 'isConfidential'>>) => {
    setClinicalNotes((prev) =>
      prev.map((n) => {
        if (n.id === id) {
          return {
            ...n,
            ...updates,
            lastEditedAt: new Date().toISOString(),
            lastEditedBy: `${currentUser.name} (${currentUser.role})`,
          };
        }
        return n;
      })
    );
    addAuditLog(
      'Clinical Note Edited',
      'ALERT',
      `Clinical note ${id} updated by ${currentUser.name} (${currentUser.role}).`
    );
  };

  const deleteClinicalNote = (id: string) => {
    const target = clinicalNotes.find((n) => n.id === id);
    setClinicalNotes((prev) => prev.filter((n) => n.id !== id));
    addAuditLog(
      'Clinical Note Archived',
      'ALERT',
      `Clinical note "${target?.title || id}" archived by ${currentUser.name} (${currentUser.role}).`,
      target?.patientId
    );
  };

  // Re-run predictions when active model or thresholds change
  useEffect(() => {
    setPatients((prev) =>
      prev.map((p) => {
        if (!p.latestMeasurement) return p;
        const prevHist = p.history.slice(0, -1);
        const pred = runSepsisPrediction(
          p.latestMeasurement,
          prevHist,
          p.age,
          activeModel,
          thresholds
        );
        return {
          ...p,
          latestPrediction: pred,
        };
      })
    );
  }, [activeModel, thresholds]);

  // Simulation Step forward
  const stepSimulationForward = useCallback(() => {
    simStepRef.current += 1;
    const scenarioConfig = SIMULATION_SCENARIOS.find((s) => s.id === simulationScenario);
    const targetPatientId = scenarioConfig?.patientId || 'P-104';

    setPatients((prev) => {
      let alertToAdd: ClinicalAlert | undefined;
      const updated = prev.map((p) => {
        if (p.id === targetPatientId) {
          const { updatedPatient, newAlert } = simulateNextStep(
            p,
            simulationScenario,
            simStepRef.current,
            activeModel,
            thresholds
          );
          if (newAlert) alertToAdd = newAlert;
          return updatedPatient;
        }
        return p;
      });

      if (alertToAdd) {
        setAlerts((altPrev) => [alertToAdd!, ...altPrev]);
        addAuditLog(
          'Simulation Alert Triggered',
          'ALERT',
          `Simulation event for ${targetPatientId} generated ${alertToAdd!.severity} alert (${alertToAdd!.headline})`,
          targetPatientId
        );
      }
      return updated;
    });
  }, [simulationScenario, activeModel, thresholds, addAuditLog]);

  // Simulation timer loop
  useEffect(() => {
    if (!isSimulating) return;

    const intervalTime = Math.max(800, 3000 / simulationSpeed);
    const timer = setInterval(() => {
      stepSimulationForward();
    }, intervalTime);

    return () => clearInterval(timer);
  }, [isSimulating, simulationSpeed, stepSimulationForward]);

  const toggleSimulation = () => {
    setIsSimulating((prev) => {
      const next = !prev;
      addAuditLog(
        next ? 'Simulation Started' : 'Simulation Paused',
        'SYSTEM',
        `Real-time ICU scenario playback (${simulationScenario}) ${next ? 'activated' : 'paused'} at ${simulationSpeed}x.`
      );
      return next;
    });
  };

  const resetSimulation = () => {
    setIsSimulating(false);
    simStepRef.current = 0;
    initCohort();
    addAuditLog('Simulation Reset', 'SYSTEM', 'Simulation reset to baseline synthetic ICU state.');
  };

  const resetEntireDemo = () => {
    setIsSimulating(false);
    simStepRef.current = 0;
    initCohort();
  };

  const selectedPatient = patients.find((p) => p.id === selectedPatientId) || patients[0] || null;
  const unacknowledgedAlertsCount = alerts.filter((a) => a.status === 'active').length;

  return (
    <AppContext.Provider
      value={{
        currentView,
        setCurrentView,
        selectedPatientId,
        setSelectedPatientId,
        currentUser,
        setCurrentUser,
        switchUserRole,
        patients,
        setPatients,
        selectedPatient,
        alerts,
        unacknowledgedAlertsCount,
        acknowledgeAlert,
        addMeasurementToPatient,
        importPatients,
        clinicalNotes,
        addClinicalNote,
        updateClinicalNote,
        deleteClinicalNote,
        activeModel,
        setActiveModel,
        thresholds,
        setThresholds,
        temperatureUnit,
        setTemperatureUnit,
        staleHoursLimit,
        setStaleHoursLimit,
        simulationScenario,
        setSimulationScenario,
        isSimulating,
        simulationSpeed,
        setSimulationSpeed,
        toggleSimulation,
        stepSimulationForward,
        resetSimulation,
        auditLogs,
        addAuditLog,
        isDarkMode,
        toggleDarkMode,
        resetEntireDemo,
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const ctx = useContext(AppContext);
  if (!ctx) throw new Error('useApp must be used within an AppProvider');
  return ctx;
};
