/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { Patient, PatientMeasurement } from '../types/sepsis';
import { runSepsisPrediction, DEFAULT_THRESHOLDS } from './mlEngine';
import { PHYSIOLOGICAL_BOUNDS } from './dataValidator';

export interface CsvValidationIssue {
  row: number;
  field: string;
  value: string;
  type: 'error' | 'warning';
  message: string;
}

export interface CsvParseResult {
  success: boolean;
  totalRows: number;
  validRows: number;
  warningRows: number;
  errorRows: number;
  issues: CsvValidationIssue[];
  parsedPatients: Patient[];
  rawPreview: Record<string, string>[];
}

export const SAMPLE_ICU_CSV = `patient_id,timestamp,age,sex,heart_rate,sbp,dbp,map,respiratory_rate,temperature,spo2,wbc,lactate,platelets,creatinine,glucose
P-201,2026-10-03T08:00:00Z,68,Male,112,94,58,70,26,38.6,92,16.8,3.4,120,1.8,155
P-201,2026-10-03T09:00:00Z,68,Male,124,86,52,63,28,38.9,90,19.2,4.6,95,2.1,170
P-202,2026-10-03T08:00:00Z,54,Female,74,122,76,91,16,36.8,98,6.8,1.1,260,0.8,98
P-202,2026-10-03T09:00:00Z,54,Female,76,118,74,88,15,36.7,99,7.1,1.0,255,0.9,102
P-203,2026-10-03T08:00:00Z,73,Female,96,104,64,77,22,37.8,94,12.4,2.3,165,1.3,140
P-203,2026-10-03T09:00:00Z,73,Female,105,98,60,72,24,38.1,93,14.1,2.8,142,1.5,148
P-204,2026-10-03T08:00:00Z,61,Male,68,130,80,96,14,36.6,99,5.9,0.9,290,0.85,115
P-205,2026-10-03T08:00:00Z,82,Female,132,78,46,56,32,39.4,88,23.5,6.2,68,2.8,210`;

export function parseIcuCsv(csvText: string): CsvParseResult {
  const lines = csvText.trim().split(/\r?\n/).filter((l) => l.trim().length > 0);

  if (lines.length < 2) {
    return {
      success: false,
      totalRows: 0,
      validRows: 0,
      warningRows: 0,
      errorRows: 0,
      issues: [{ row: 0, field: 'header', value: '', type: 'error', message: 'CSV file is empty or missing data rows.' }],
      parsedPatients: [],
      rawPreview: [],
    };
  }

  // Parse header
  const header = lines[0].split(',').map((h) => h.trim().toLowerCase());
  const requiredColumns = [
    'patient_id',
    'heart_rate',
    'sbp',
    'dbp',
    'respiratory_rate',
    'temperature',
    'spo2',
    'lactate',
  ];

  const missingColumns = requiredColumns.filter((col) => !header.includes(col));
  if (missingColumns.length > 0) {
    return {
      success: false,
      totalRows: lines.length - 1,
      validRows: 0,
      warningRows: 0,
      errorRows: lines.length - 1,
      issues: [
        {
          row: 1,
          field: 'header',
          value: missingColumns.join(', '),
          type: 'error',
          message: `Missing required column headers: ${missingColumns.join(', ')}`,
        },
      ],
      parsedPatients: [],
      rawPreview: [],
    };
  }

  const issues: CsvValidationIssue[] = [];
  const rawPreview: Record<string, string>[] = [];
  const patientMap = new Map<string, { age: number; sex: 'Male' | 'Female' | 'Other'; measurements: PatientMeasurement[] }>();

  let validRowsCount = 0;
  let warningRowsCount = 0;
  let errorRowsCount = 0;

  for (let i = 1; i < lines.length; i++) {
    const rowNum = i + 1;
    const cols = lines[i].split(',').map((c) => c.trim());
    if (cols.length < 5) continue;

    const rowObj: Record<string, string> = {};
    header.forEach((h, idx) => {
      rowObj[h] = cols[idx] ?? '';
    });

    if (rawPreview.length < 8) {
      rawPreview.push(rowObj);
    }

    const patientId = rowObj.patient_id || `P-${1000 + i}`;
    const timestamp = rowObj.timestamp || new Date(Date.now() - (lines.length - i) * 3600 * 1000).toISOString();
    const age = Number(rowObj.age) || 65;
    const sexRaw = (rowObj.sex || 'Female').toLowerCase();
    const sex: 'Male' | 'Female' | 'Other' = sexRaw.startsWith('m') ? 'Male' : sexRaw.startsWith('f') ? 'Female' : 'Other';

    // Parse numeric fields
    let rowHasError = false;
    let rowHasWarning = false;

    const parseNum = (colName: string, defVal: number): number => {
      const valStr = rowObj[colName];
      if (valStr === undefined || valStr === '') {
        issues.push({ row: rowNum, field: colName, value: '', type: 'warning', message: `Missing ${colName}, defaulted to ${defVal}` });
        rowHasWarning = true;
        return defVal;
      }
      const num = Number(valStr);
      if (Number.isNaN(num)) {
        issues.push({ row: rowNum, field: colName, value: valStr, type: 'error', message: `Invalid numeric value '${valStr}' for ${colName}` });
        rowHasError = true;
        return defVal;
      }
      const bounds = PHYSIOLOGICAL_BOUNDS[colName];
      if (bounds) {
        if (num < bounds.min || num > bounds.max) {
          issues.push({ row: rowNum, field: colName, value: String(num), type: 'warning', message: `Value ${num} is outside physiological limits (${bounds.min} - ${bounds.max}) and will be clamped` });
          rowHasWarning = true;
        }
      }
      return num;
    };

    const heartRate = parseNum('heart_rate', 80);
    const sbp = parseNum('sbp', 120);
    const dbp = parseNum('dbp', 75);
    let map = Number(rowObj.map);
    if (Number.isNaN(map) || map <= 0) {
      map = Math.round(((sbp + 2 * dbp) / 3) * 10) / 10;
    }
    const respiratoryRate = parseNum('respiratory_rate', 16);
    const temperature = parseNum('temperature', 37.0);
    const spo2 = parseNum('spo2', 98);
    const wbc = parseNum('wbc', 7.5);
    const lactate = parseNum('lactate', 1.2);
    const platelets = parseNum('platelets', 230);
    const creatinine = parseNum('creatinine', 0.9);
    const glucose = parseNum('glucose', 110);

    if (rowHasError) {
      errorRowsCount++;
    } else {
      if (rowHasWarning) warningRowsCount++;
      else validRowsCount++;

      const measurement: PatientMeasurement = {
        id: `m-csv-${patientId}-${i}`,
        patientId,
        timestamp,
        heartRate,
        sbp,
        dbp,
        map,
        respiratoryRate,
        temperature,
        spo2,
        wbc,
        lactate,
        platelets,
        creatinine,
        glucose,
        isSynthetic: true,
      };

      if (!patientMap.has(patientId)) {
        patientMap.set(patientId, { age, sex, measurements: [] });
      }
      patientMap.get(patientId)!.measurements.push(measurement);
    }
  }

  // Assemble Patient objects
  const parsedPatients: Patient[] = [];
  let bedCounter = 13;

  patientMap.forEach((data, pId) => {
    // Sort measurements by timestamp
    const history = data.measurements.sort(
      (a, b) => new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime()
    );

    const latestMeas = history[history.length - 1];
    const prevHistory = history.slice(0, -1);
    const pred = runSepsisPrediction(
      latestMeas,
      prevHistory,
      data.age,
      'Gradient Boosted Trees (XGBoost)',
      DEFAULT_THRESHOLDS
    );

    parsedPatients.push({
      id: pId,
      mrn: `MRN-CSV-${pId.replace(/[^0-9]/g, '') || Math.floor(100000 + Math.random() * 900000)}`,
      name: `Imported Cohort Patient ${pId}`,
      age: data.age,
      sex: data.sex,
      bed: `ICU-${bedCounter < 10 ? '0' + bedCounter : bedCounter}`,
      admissionDate: history[0]?.timestamp || new Date().toISOString(),
      admissionDiagnosis: 'Clinical ICU Admission (Batch CSV)',
      weightKg: 72,
      codeStatus: 'Full Code',
      history,
      latestMeasurement: latestMeas,
      latestPrediction: pred,
      isSimulationPatient: false,
    });

    bedCounter++;
  });

  return {
    success: parsedPatients.length > 0,
    totalRows: lines.length - 1,
    validRows: validRowsCount,
    warningRows: warningRowsCount,
    errorRows: errorRowsCount,
    issues,
    parsedPatients,
    rawPreview,
  };
}
