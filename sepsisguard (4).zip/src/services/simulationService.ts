/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { Patient, PatientMeasurement, MLModelType, RiskThresholds, ClinicalAlert } from '../types/sepsis';
import { runSepsisPrediction, DEFAULT_THRESHOLDS } from './mlEngine';

export type SimulationScenarioId = 'stable' | 'gradual_deterioration' | 'rapid_deterioration' | 'recovery';

export interface SimulationScenarioConfig {
  id: SimulationScenarioId;
  name: string;
  patientId: string;
  bed: string;
  description: string;
  expectedOutcome: string;
}

export const SIMULATION_SCENARIOS: SimulationScenarioConfig[] = [
  {
    id: 'stable',
    name: 'Scenario 1: Hemodynamically Stable Post-Op',
    patientId: 'P-101',
    bed: 'ICU-01',
    description: 'Post-cardiac surgery recovery patient maintaining normal physiological parameters and low estimated sepsis risk.',
    expectedOutcome: 'Low risk score (<20%), stable trajectory, no clinical alerts triggered.',
  },
  {
    id: 'gradual_deterioration',
    name: 'Scenario 2: Gradual Deterioration (Occult Sepsis)',
    patientId: 'P-104',
    bed: 'ICU-04',
    description: 'Post-abdominal surgery patient developing insidious subclinical deterioration with progressive tachycardia, tachypnea, and slowly rising lactate.',
    expectedOutcome: 'Transition from Moderate (38%) to High Risk (>65%) over 6 hours; early warning alert triggered.',
  },
  {
    id: 'rapid_deterioration',
    name: 'Scenario 3: Rapid Deterioration (Septic Shock)',
    patientId: 'P-107',
    bed: 'ICU-07',
    description: 'Necrotizing soft tissue infection patient abruptly decompensating with refractory hypotension (MAP < 55), hyperlactatemia (>5.0), and severe organ dysfunction.',
    expectedOutcome: 'Sharp escalation into Critical Risk (>85%) with red immediate clinical review alert.',
  },
  {
    id: 'recovery',
    name: 'Scenario 4: Sepsis Resuscitation & Recovery',
    patientId: 'P-110',
    bed: 'ICU-10',
    description: 'Bacteremic patient responding to targeted broad-spectrum IV antibiotics, fluid resuscitation, and source control with clearing lactate and normalizing MAP.',
    expectedOutcome: 'De-escalation from High Risk (78%) down to Low/Moderate (<30%) with improving trajectory.',
  },
];

/**
 * Generate next step measurement based on scenario physics
 */
export function simulateNextStep(
  patient: Patient,
  scenario: SimulationScenarioId,
  stepNumber: number,
  modelType: MLModelType = 'Gradient Boosted Trees (XGBoost)',
  thresholds: RiskThresholds = DEFAULT_THRESHOLDS
): { updatedPatient: Patient; newAlert?: ClinicalAlert } {
  const currentMeas = patient.latestMeasurement || patient.history[patient.history.length - 1];
  const now = new Date(new Date(currentMeas.timestamp).getTime() + 60 * 60 * 1000).toISOString();

  let hr = currentMeas.heartRate;
  let sbp = currentMeas.sbp;
  let dbp = currentMeas.dbp;
  let rr = currentMeas.respiratoryRate;
  let temp = currentMeas.temperature;
  let spo2 = currentMeas.spo2;
  let wbc = currentMeas.wbc;
  let lactate = currentMeas.lactate;
  let platelets = currentMeas.platelets;
  let creatinine = currentMeas.creatinine;
  let glucose = currentMeas.glucose;

  const jitter = (range: number) => (Math.random() - 0.5) * range;

  switch (scenario) {
    case 'stable':
      hr = Math.max(62, Math.min(85, Math.round(hr + jitter(4))));
      sbp = Math.max(110, Math.min(130, Math.round(sbp + jitter(6))));
      dbp = Math.max(68, Math.min(82, Math.round(dbp + jitter(4))));
      rr = Math.max(13, Math.min(18, Math.round(rr + jitter(2))));
      temp = Math.max(36.4, Math.min(37.2, Math.round((temp + jitter(0.2)) * 10) / 10));
      spo2 = Math.max(96, Math.min(100, Math.round(spo2 + jitter(1))));
      lactate = Math.max(0.8, Math.min(1.4, Math.round((lactate + jitter(0.1)) * 10) / 10));
      break;

    case 'gradual_deterioration':
      hr = Math.min(140, Math.round(hr + 2.5 + jitter(3)));
      sbp = Math.max(82, Math.round(sbp - 2.0 + jitter(4)));
      dbp = Math.max(50, Math.round(dbp - 1.2 + jitter(3)));
      rr = Math.min(32, Math.round(rr + 0.8 + jitter(1)));
      temp = Math.min(39.4, Math.round((temp + 0.15 + jitter(0.1)) * 10) / 10);
      spo2 = Math.max(90, Math.round(spo2 - 0.4 + jitter(1)));
      wbc = Math.min(24.0, Math.round((wbc + 0.6 + jitter(0.2)) * 10) / 10);
      lactate = Math.min(5.5, Math.round((lactate + 0.25 + jitter(0.1)) * 10) / 10);
      platelets = Math.max(70, Math.round(platelets - 5 + jitter(4)));
      creatinine = Math.min(2.8, Math.round((creatinine + 0.08) * 100) / 100);
      glucose = Math.min(220, Math.round(glucose + 5 + jitter(6)));
      break;

    case 'rapid_deterioration':
      hr = Math.min(155, Math.round(hr + 5.0 + jitter(4)));
      sbp = Math.max(68, Math.round(sbp - 5.5 + jitter(5)));
      dbp = Math.max(38, Math.round(dbp - 3.5 + jitter(3)));
      rr = Math.min(38, Math.round(rr + 1.8 + jitter(2)));
      temp = Math.min(40.2, Math.round((temp + 0.3 + jitter(0.15)) * 10) / 10);
      spo2 = Math.max(84, Math.round(spo2 - 1.2 + jitter(1)));
      wbc = Math.min(28.0, Math.round((wbc + 1.4 + jitter(0.3)) * 10) / 10);
      lactate = Math.min(8.5, Math.round((lactate + 0.65 + jitter(0.15)) * 10) / 10);
      platelets = Math.max(45, Math.round(platelets - 12 + jitter(6)));
      creatinine = Math.min(3.8, Math.round((creatinine + 0.2) * 100) / 100);
      glucose = Math.min(280, Math.round(glucose + 12 + jitter(8)));
      break;

    case 'recovery':
      hr = Math.max(68, Math.round(hr - 3.5 + jitter(3)));
      sbp = Math.min(125, Math.round(sbp + 2.8 + jitter(4)));
      dbp = Math.min(78, Math.round(dbp + 1.8 + jitter(3)));
      rr = Math.max(14, Math.round(rr - 1.0 + jitter(1)));
      temp = Math.max(36.7, Math.round((temp - 0.2 + jitter(0.1)) * 10) / 10);
      spo2 = Math.min(99, Math.round(spo2 + 0.6 + jitter(1)));
      wbc = Math.max(7.0, Math.round((wbc - 0.8 + jitter(0.2)) * 10) / 10);
      lactate = Math.max(1.0, Math.round((lactate - 0.35 + jitter(0.08)) * 10) / 10);
      platelets = Math.min(260, Math.round(platelets + 8 + jitter(5)));
      creatinine = Math.max(0.9, Math.round((creatinine - 0.08) * 100) / 100);
      glucose = Math.max(105, Math.round(glucose - 6 + jitter(5)));
      break;
  }

  const map = Math.round(((sbp + 2 * dbp) / 3) * 10) / 10;

  const newMeasurement: PatientMeasurement = {
    id: `m-sim-${patient.id}-${stepNumber}-${Date.now()}`,
    patientId: patient.id,
    timestamp: now,
    heartRate: hr,
    sbp,
    dbp,
    map,
    respiratoryRate: rr,
    temperature: temp,
    spo2,
    wbc,
    lactate,
    platelets,
    creatinine,
    glucose,
    isSynthetic: true,
  };

  const updatedHistory = [...patient.history, newMeasurement];

  // Re-run prediction pipeline
  const newPrediction = runSepsisPrediction(
    newMeasurement,
    patient.history,
    patient.age,
    modelType,
    thresholds
  );

  const updatedPatient: Patient = {
    ...patient,
    history: updatedHistory,
    latestMeasurement: newMeasurement,
    latestPrediction: newPrediction,
  };

  let newAlert: ClinicalAlert | undefined;
  // Trigger alert if breached thresholds and wasn't already critical or if worsening
  if (
    newPrediction.riskScore >= thresholds.moderateMax &&
    (!patient.latestPrediction ||
      newPrediction.riskScore > patient.latestPrediction.riskScore + 3 ||
      newPrediction.riskLevel !== patient.latestPrediction.riskLevel)
  ) {
    const topFactor = newPrediction.featureContributions[0];
    const severity =
      newPrediction.riskScore >= thresholds.highMax
        ? 'critical'
        : newPrediction.riskScore >= 60
        ? 'high'
        : 'moderate';

    const headline =
      severity === 'critical'
        ? 'CRITICAL SEPSIS RISK — Immediate clinical review recommended'
        : severity === 'high'
        ? 'HIGH SEPSIS RISK — Clinical review recommended'
        : 'MODERATE SEPSIS RISK — Monitor physiological trajectory';

    newAlert = {
      id: `alt-sim-${patient.id}-${Date.now()}`,
      patientId: patient.id,
      patientName: patient.name,
      bed: patient.bed,
      riskScore: newPrediction.riskScore,
      severity,
      headline,
      primaryReason: topFactor ? topFactor.clinicalInterpretation : 'Telemetry anomaly detected',
      contributingFactors: newPrediction.featureContributions
        .slice(0, 3)
        .map((fc) => `${fc.label}: ${fc.contributionPercent > 0 ? '+' : ''}${fc.contributionPercent}%`),
      timestamp: newPrediction.timestamp,
      status: 'active',
    };
  }

  return { updatedPatient, newAlert };
}
