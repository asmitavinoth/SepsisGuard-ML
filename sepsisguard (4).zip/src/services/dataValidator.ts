/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { PatientMeasurement, DataQualityReport } from '../types/sepsis';

export interface ValidationBounds {
  min: number;
  max: number;
  normalMin: number;
  normalMax: number;
  unit: string;
  label: string;
}

export const PHYSIOLOGICAL_BOUNDS: Record<string, ValidationBounds> = {
  heartRate: { min: 20, max: 250, normalMin: 60, normalMax: 100, unit: 'bpm', label: 'Heart Rate' },
  sbp: { min: 30, max: 280, normalMin: 90, normalMax: 120, unit: 'mmHg', label: 'Systolic BP' },
  dbp: { min: 20, max: 180, normalMin: 60, normalMax: 80, unit: 'mmHg', label: 'Diastolic BP' },
  map: { min: 25, max: 200, normalMin: 70, normalMax: 105, unit: 'mmHg', label: 'Mean Arterial Pressure' },
  respiratoryRate: { min: 4, max: 65, normalMin: 12, normalMax: 20, unit: 'breaths/min', label: 'Respiratory Rate' },
  temperature: { min: 31.0, max: 43.0, normalMin: 36.1, normalMax: 37.5, unit: '°C', label: 'Temperature' },
  spo2: { min: 40, max: 100, normalMin: 95, normalMax: 100, unit: '%', label: 'Oxygen Saturation' },
  wbc: { min: 0.2, max: 80.0, normalMin: 4.5, normalMax: 11.0, unit: '×10⁹/L', label: 'White Blood Cell Count' },
  lactate: { min: 0.2, max: 25.0, normalMin: 0.5, normalMax: 2.0, unit: 'mmol/L', label: 'Lactate' },
  platelets: { min: 5, max: 1000, normalMin: 150, normalMax: 450, unit: '×10⁹/L', label: 'Platelets' },
  creatinine: { min: 0.2, max: 20.0, normalMin: 0.6, normalMax: 1.2, unit: 'mg/dL', label: 'Creatinine' },
  glucose: { min: 20, max: 1000, normalMin: 70, normalMax: 140, unit: 'mg/dL', label: 'Glucose' },
};

export const MEDIAN_POPULATION_VALUES: Record<string, number> = {
  heartRate: 78,
  sbp: 118,
  dbp: 72,
  map: 87,
  respiratoryRate: 16,
  temperature: 36.8,
  spo2: 98,
  wbc: 7.2,
  lactate: 1.1,
  platelets: 230,
  creatinine: 0.9,
  glucose: 105,
};

/**
 * Validate, clamp outliers, impute missing values, and calculate data quality.
 */
export function validateAndPreprocessMeasurement(
  raw: Partial<PatientMeasurement>,
  previousMeasurement?: PatientMeasurement,
  currentTimeMs: number = Date.now(),
  staleThresholdHours: number = 4
): { cleaned: PatientMeasurement; quality: DataQualityReport } {
  const imputedFields: string[] = [];
  const outlierFields: string[] = [];

  // Helper to validate and clamp or impute a numeric parameter
  const resolveField = (key: keyof typeof PHYSIOLOGICAL_BOUNDS, rawVal: unknown): number => {
    const bounds = PHYSIOLOGICAL_BOUNDS[key];
    let val: number;

    if (rawVal === undefined || rawVal === null || rawVal === '' || Number.isNaN(Number(rawVal))) {
      // Missing value: forward-fill from previous measurement if available, otherwise population median
      if (previousMeasurement && typeof previousMeasurement[key as keyof PatientMeasurement] === 'number') {
        val = previousMeasurement[key as keyof PatientMeasurement] as number;
        imputedFields.push(`${bounds.label} (Forward-filled: ${val} ${bounds.unit})`);
      } else {
        val = MEDIAN_POPULATION_VALUES[key] ?? 0;
        imputedFields.push(`${bounds.label} (Median imputed: ${val} ${bounds.unit})`);
      }
    } else {
      val = Number(rawVal);
      if (val < bounds.min) {
        outlierFields.push(`${bounds.label} clamped from ${val} to min ${bounds.min} ${bounds.unit}`);
        val = bounds.min;
      } else if (val > bounds.max) {
        outlierFields.push(`${bounds.label} clamped from ${val} to max ${bounds.max} ${bounds.unit}`);
        val = bounds.max;
      }
    }
    return Math.round(val * 100) / 100;
  };

  const heartRate = resolveField('heartRate', raw.heartRate);
  const sbp = resolveField('sbp', raw.sbp);
  const dbp = resolveField('dbp', raw.dbp);

  // If MAP is not supplied or 0, calculate MAP = (SBP + 2 * DBP) / 3
  let rawMap = raw.map;
  if (rawMap === undefined || rawMap === null || Number.isNaN(Number(rawMap)) || Number(rawMap) <= 0) {
    rawMap = (sbp + 2 * dbp) / 3;
  }
  const map = resolveField('map', rawMap);

  const respiratoryRate = resolveField('respiratoryRate', raw.respiratoryRate);
  const temperature = resolveField('temperature', raw.temperature);
  const spo2 = resolveField('spo2', raw.spo2);
  const wbc = resolveField('wbc', raw.wbc);
  const lactate = resolveField('lactate', raw.lactate);
  const platelets = resolveField('platelets', raw.platelets);
  const creatinine = resolveField('creatinine', raw.creatinine);
  const glucose = resolveField('glucose', raw.glucose);

  // Feature Engineering
  const shockIndex = sbp > 0 ? Math.round((heartRate / sbp) * 100) / 100 : 0.7;
  const pulsePressure = Math.max(0, sbp - dbp);
  const mapDeficit = Math.max(0, 65 - map);

  // SIRS Criteria (0-4):
  // 1. HR > 90 bpm
  // 2. RR > 20 or PaCO2 < 32
  // 3. Temp > 38.0°C or < 36.0°C
  // 4. WBC > 12.0 or < 4.0 (x10^9/L)
  let sirs = 0;
  if (heartRate > 90) sirs++;
  if (respiratoryRate > 20) sirs++;
  if (temperature > 38.0 || temperature < 36.0) sirs++;
  if (wbc > 12.0 || wbc < 4.0) sirs++;

  // qSOFA Score (0-3):
  // 1. RR >= 22
  // 2. SBP <= 100
  // 3. (Altered mental status simulated if high lactate/hypotension)
  let qsofa = 0;
  if (respiratoryRate >= 22) qsofa++;
  if (sbp <= 100) qsofa++;
  if (lactate > 3.0 || map < 60) qsofa++;

  // Delta Lactate (rate of change compared to previous measurement)
  let deltaLactate6h = 0;
  if (previousMeasurement && previousMeasurement.lactate) {
    deltaLactate6h = Math.round((lactate - previousMeasurement.lactate) * 100) / 100;
  }

  // Stale measurement calculation
  const timestampStr = raw.timestamp || new Date(currentTimeMs).toISOString();
  const measurementTime = new Date(timestampStr).getTime();
  const hoursSince = Math.max(0, Math.round(((currentTimeMs - measurementTime) / (1000 * 60 * 60)) * 10) / 10);
  const isStale = hoursSince > staleThresholdHours;

  // Data Quality Score (0-100)
  let qualityScore = 100;
  qualityScore -= imputedFields.length * 8; // each imputed field penalizes
  qualityScore -= outlierFields.length * 6; // each clamped outlier penalizes
  if (isStale) qualityScore -= Math.min(30, Math.round(hoursSince * 3));
  qualityScore = Math.max(15, Math.min(100, qualityScore));

  const qualityLevel: 'High' | 'Moderate' | 'Low' =
    qualityScore >= 80 ? 'High' : qualityScore >= 50 ? 'Moderate' : 'Low';

  let notes = 'Complete physiological capture.';
  if (isStale) {
    notes = `Telemetry is ${hoursSince}h old; updated vitals and repeat labs recommended.`;
  } else if (imputedFields.length > 0) {
    notes = `${imputedFields.length} missing parameter(s) imputed.`;
  }

  const quality: DataQualityReport = {
    score: qualityScore,
    level: qualityLevel,
    isStale,
    hoursSinceLastMeasurement: hoursSince,
    imputedFields,
    outlierFields,
    notes,
  };

  const cleaned: PatientMeasurement = {
    id: raw.id || `m-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
    patientId: raw.patientId || 'unknown',
    timestamp: timestampStr,
    heartRate,
    sbp,
    dbp,
    map,
    respiratoryRate,
    temperature,
    spo2,
    wbc,
    lactate,
    platelets,
    creatinine,
    glucose,
    shockIndex,
    pulsePressure,
    mapDeficit,
    sirsCriteriaMet: sirs,
    qSofaScore: qsofa,
    deltaLactate6h,
    isSynthetic: true,
  };

  return { cleaned, quality };
}
