/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { Patient, PatientMeasurement, ClinicalAlert } from '../types/sepsis';
import { runSepsisPrediction, DEFAULT_THRESHOLDS } from './mlEngine';

/**
 * Generate hourly synthetic timestamps ending at reference time
 */
function generateTimestamps(hoursCount: number, endTimestampMs: number = Date.now()): string[] {
  const times: string[] = [];
  for (let i = hoursCount - 1; i >= 0; i--) {
    times.push(new Date(endTimestampMs - i * 60 * 60 * 1000).toISOString());
  }
  return times;
}

/**
 * Build initial realistic ICU Cohort with 12 patients across 12 ICU beds
 */
export function generateInitialIcuCohort(): { patients: Patient[]; initialAlerts: ClinicalAlert[] } {
  const now = Date.now();
  const times12h = generateTimestamps(12, now);
  const times18h = generateTimestamps(18, now);

  const cohortData: Omit<Patient, 'history' | 'latestMeasurement' | 'latestPrediction'>[] = [
    {
      id: 'P-101',
      mrn: 'MRN-849201',
      name: 'Eleanor Vance',
      age: 64,
      sex: 'Female',
      bed: 'ICU-01',
      admissionDate: new Date(now - 36 * 3600 * 1000).toISOString(),
      admissionDiagnosis: 'Post-Op CABG x3 Recovery',
      weightKg: 68,
      codeStatus: 'Full Code',
      isSimulationPatient: true,
      scenarioType: 'stable',
    },
    {
      id: 'P-102',
      mrn: 'MRN-723109',
      name: 'Robert Chen',
      age: 58,
      sex: 'Male',
      bed: 'ICU-02',
      admissionDate: new Date(now - 48 * 3600 * 1000).toISOString(),
      admissionDiagnosis: 'Community-Acquired Pneumonia',
      weightKg: 82,
      codeStatus: 'Full Code',
    },
    {
      id: 'P-103',
      mrn: 'MRN-912445',
      name: 'Margaret Hayes',
      age: 79,
      sex: 'Female',
      bed: 'ICU-03',
      admissionDate: new Date(now - 24 * 3600 * 1000).toISOString(),
      admissionDiagnosis: 'Urosepsis with AKI',
      weightKg: 61,
      codeStatus: 'DNR/DNI',
    },
    {
      id: 'P-104',
      mrn: 'MRN-531882',
      name: 'James Rodriguez',
      age: 67,
      sex: 'Male',
      bed: 'ICU-04',
      admissionDate: new Date(now - 16 * 3600 * 1000).toISOString(),
      admissionDiagnosis: 'Perforated Diverticulitis Post-Hartmann',
      weightKg: 79,
      codeStatus: 'Full Code',
      isSimulationPatient: true,
      scenarioType: 'gradual_deterioration',
    },
    {
      id: 'P-105',
      mrn: 'MRN-640192',
      name: 'Dorothy Miller',
      age: 71,
      sex: 'Female',
      bed: 'ICU-05',
      admissionDate: new Date(now - 72 * 3600 * 1000).toISOString(),
      admissionDiagnosis: 'Elective Abdominal Aortic Aneurysm Repair',
      weightKg: 74,
      codeStatus: 'Full Code',
    },
    {
      id: 'P-106',
      mrn: 'MRN-419088',
      name: 'David Okafor',
      age: 63,
      sex: 'Male',
      bed: 'ICU-06',
      admissionDate: new Date(now - 30 * 3600 * 1000).toISOString(),
      admissionDiagnosis: 'Acute COPD Exacerbation with Hypercapnia',
      weightKg: 88,
      codeStatus: 'Full Code',
    },
    {
      id: 'P-107',
      mrn: 'MRN-302911',
      name: 'Arthur Pendelton',
      age: 73,
      sex: 'Male',
      bed: 'ICU-07',
      admissionDate: new Date(now - 14 * 3600 * 1000).toISOString(),
      admissionDiagnosis: 'Necrotizing Fasciitis Right Lower Extremity',
      weightKg: 85,
      codeStatus: 'Full Code',
      isSimulationPatient: true,
      scenarioType: 'rapid_deterioration',
    },
    {
      id: 'P-108',
      mrn: 'MRN-882194',
      name: 'Maria Santos',
      age: 69,
      sex: 'Female',
      bed: 'ICU-08',
      admissionDate: new Date(now - 40 * 3600 * 1000).toISOString(),
      admissionDiagnosis: 'Aspiration Pneumonitis with Thrombocytopenia',
      weightKg: 65,
      codeStatus: 'Full Code',
    },
    {
      id: 'P-109',
      mrn: 'MRN-551203',
      name: 'Thomas Brennan',
      age: 54,
      sex: 'Male',
      bed: 'ICU-09',
      admissionDate: new Date(now - 20 * 3600 * 1000).toISOString(),
      admissionDiagnosis: 'Acute Necrotizing Pancreatitis',
      weightKg: 92,
      codeStatus: 'Full Code',
    },
    {
      id: 'P-110',
      mrn: 'MRN-773412',
      name: 'Patricia Morales',
      age: 62,
      sex: 'Female',
      bed: 'ICU-10',
      admissionDate: new Date(now - 52 * 3600 * 1000).toISOString(),
      admissionDiagnosis: 'Gram-Negative Bacteremia (E. coli)',
      weightKg: 70,
      codeStatus: 'Full Code',
      isSimulationPatient: true,
      scenarioType: 'recovery',
    },
    {
      id: 'P-111',
      mrn: 'MRN-229104',
      name: 'George Washington Jr.',
      age: 59,
      sex: 'Male',
      bed: 'ICU-11',
      admissionDate: new Date(now - 28 * 3600 * 1000).toISOString(),
      admissionDiagnosis: 'Post-Stroke ICU Observation',
      weightKg: 81,
      codeStatus: 'Full Code',
    },
    {
      id: 'P-112',
      mrn: 'MRN-664321',
      name: 'Linda Kowalski',
      age: 76,
      sex: 'Female',
      bed: 'ICU-12',
      admissionDate: new Date(now - 34 * 3600 * 1000).toISOString(),
      admissionDiagnosis: 'Secondary Sepsis with Moderate ARDS',
      weightKg: 63,
      codeStatus: 'Full Code',
    },
  ];

  const patients: Patient[] = [];
  const initialAlerts: ClinicalAlert[] = [];

  cohortData.forEach((pMeta, idx) => {
    const history: PatientMeasurement[] = [];
    const tArray = idx % 2 === 0 ? times12h : times18h;

    tArray.forEach((ts, stepIdx) => {
      const progress = stepIdx / (tArray.length - 1); // 0.0 to 1.0

      let hr = 75;
      let sbp = 120;
      let dbp = 75;
      let rr = 16;
      let temp = 36.8;
      let spo2 = 98;
      let wbc = 7.5;
      let lactate = 1.1;
      let platelets = 240;
      let creatinine = 0.9;
      let glucose = 105;

      switch (pMeta.scenarioType) {
        case 'stable': // Scenario 1: Stable
          hr = 72 + Math.sin(stepIdx) * 4;
          sbp = 118 + Math.cos(stepIdx) * 5;
          dbp = 74 + Math.sin(stepIdx * 1.5) * 3;
          rr = 15 + Math.round(Math.sin(stepIdx * 0.8));
          temp = 36.7 + Math.sin(stepIdx * 0.5) * 0.2;
          spo2 = 98 - (stepIdx % 2);
          wbc = 7.2;
          lactate = 1.0 + Math.sin(stepIdx) * 0.1;
          platelets = 245;
          creatinine = 0.85;
          glucose = 110;
          break;

        case 'gradual_deterioration': // Scenario 2: Gradual Deterioration (P-104)
          // Starts moderate, slowly deteriorates
          hr = Math.round(82 + progress * 36 + Math.sin(stepIdx) * 3); // 82 -> 118
          sbp = Math.round(118 - progress * 26 + Math.cos(stepIdx) * 4); // 118 -> 92
          dbp = Math.round(76 - progress * 18); // 76 -> 58
          rr = Math.round(18 + progress * 8); // 18 -> 26
          temp = Math.round((37.2 + progress * 1.3) * 10) / 10; // 37.2 -> 38.5
          spo2 = Math.round(97 - progress * 4); // 97 -> 93
          wbc = Math.round((9.5 + progress * 7.5) * 10) / 10; // 9.5 -> 17.0
          lactate = Math.round((1.3 + progress * 1.9) * 10) / 10; // 1.3 -> 3.2
          platelets = Math.round(210 - progress * 75); // 210 -> 135
          creatinine = Math.round((1.0 + progress * 0.6) * 10) / 10; // 1.0 -> 1.6
          glucose = Math.round(120 + progress * 45);
          break;

        case 'rapid_deterioration': // Scenario 3: Rapid Deterioration / Septic Shock (P-107)
          // Sharp crash over the last half of the timeline
          if (progress < 0.4) {
            hr = 88;
            sbp = 112;
            dbp = 70;
            rr = 19;
            temp = 37.6;
            spo2 = 96;
            lactate = 1.6;
            wbc = 11.2;
          } else {
            const crashP = (progress - 0.4) / 0.6;
            hr = Math.round(88 + crashP * 46); // 88 -> 134
            sbp = Math.round(112 - crashP * 34); // 112 -> 78
            dbp = Math.round(70 - crashP * 24); // 70 -> 46
            rr = Math.round(19 + crashP * 13); // 19 -> 32
            temp = Math.round((37.6 + crashP * 1.6) * 10) / 10; // 37.6 -> 39.2
            spo2 = Math.round(96 - crashP * 8); // 96 -> 88
            wbc = Math.round((11.2 + crashP * 10.4) * 10) / 10; // 11.2 -> 21.6
            lactate = Math.round((1.6 + crashP * 3.8) * 10) / 10; // 1.6 -> 5.4
            platelets = Math.round(195 - crashP * 105); // 195 -> 90
            creatinine = Math.round((1.1 + crashP * 1.1) * 10) / 10; // 1.1 -> 2.2
            glucose = Math.round(130 + crashP * 65);
          }
          break;

        case 'recovery': // Scenario 4: Recovery (P-110)
          // Starts severe/critical, steadily improves after treatment
          hr = Math.round(124 - progress * 42); // 124 -> 82
          sbp = Math.round(86 + progress * 32); // 86 -> 118
          dbp = Math.round(52 + progress * 22); // 52 -> 74
          rr = Math.round(28 - progress * 11); // 28 -> 17
          temp = Math.round((38.8 - progress * 1.9) * 10) / 10; // 38.8 -> 36.9
          spo2 = Math.round(92 + progress * 6); // 92 -> 98
          wbc = Math.round((18.4 - progress * 9.8) * 10) / 10; // 18.4 -> 8.6
          lactate = Math.round((4.6 - progress * 3.2) * 10) / 10; // 4.6 -> 1.4
          platelets = Math.round(110 + progress * 80); // 110 -> 190
          creatinine = Math.round((1.8 - progress * 0.7) * 10) / 10; // 1.8 -> 1.1
          glucose = Math.round(165 - progress * 45);
          break;

        default:
          // Varied non-simulation baseline cohort
          if (idx === 2) {
            // P-103: High risk urosepsis
            hr = 104 + Math.round(Math.sin(stepIdx) * 5);
            sbp = 96 - Math.round(Math.cos(stepIdx) * 4);
            dbp = 58;
            rr = 24;
            temp = 38.4;
            spo2 = 94;
            lactate = 2.8 + (stepIdx % 3) * 0.2;
            wbc = 16.4;
            platelets = 135;
            creatinine = 1.7;
          } else if (idx === 7) {
            // P-108: High risk
            hr = 110;
            sbp = 98;
            dbp = 60;
            rr = 25;
            temp = 38.2;
            spo2 = 93;
            lactate = 3.1;
            wbc = 15.8;
            platelets = 98;
            creatinine = 1.5;
          } else if (idx === 11) {
            // P-112: Critical risk ARDS
            hr = 126;
            sbp = 88;
            dbp = 54;
            rr = 30;
            temp = 38.9;
            spo2 = 90;
            lactate = 4.2;
            wbc = 19.5;
            platelets = 85;
            creatinine = 2.0;
          } else if (idx === 5) {
            // P-106: Moderate COPD
            hr = 92;
            sbp = 128;
            dbp = 78;
            rr = 22;
            temp = 37.3;
            spo2 = 92;
            lactate = 1.8;
            wbc = 11.5;
            platelets = 220;
            creatinine = 1.1;
          } else {
            // Stable baseline
            hr = 74 + (idx % 5);
            sbp = 122 - (idx % 4);
            dbp = 76;
            rr = 15 + (idx % 3);
            temp = 36.8 + (idx % 3) * 0.1;
            spo2 = 97 + (idx % 2);
            lactate = 1.1 + (idx % 3) * 0.15;
            wbc = 6.8 + (idx % 4) * 0.4;
            platelets = 230 + (idx % 4) * 10;
            creatinine = 0.9;
          }
          break;
      }

      const map = Math.round(((sbp + 2 * dbp) / 3) * 10) / 10;

      history.push({
        id: `m-${pMeta.id}-${stepIdx}`,
        patientId: pMeta.id,
        timestamp: ts,
        heartRate: hr,
        sbp,
        dbp,
        map,
        respiratoryRate: rr,
        temperature: temp,
        spo2,
        wbc,
        lactate,
        platelets,
        creatinine,
        glucose,
        isSynthetic: true,
      });
    });

    // Run prediction on latest measurement
    const latestMeas = history[history.length - 1];
    const prevHistory = history.slice(0, -1);
    const pred = runSepsisPrediction(
      latestMeas,
      prevHistory,
      pMeta.age,
      'Gradient Boosted Trees (XGBoost)',
      DEFAULT_THRESHOLDS
    );

    const fullPatient: Patient = {
      ...pMeta,
      history,
      latestMeasurement: latestMeas,
      latestPrediction: pred,
    };

    patients.push(fullPatient);

    // If prediction triggers an alert, create ClinicalAlert
    if (pred.riskScore >= DEFAULT_THRESHOLDS.moderateMax) {
      const topFactor = pred.featureContributions[0];
      const severity = pred.riskScore >= DEFAULT_THRESHOLDS.highMax ? 'critical' : pred.riskScore >= 60 ? 'high' : 'moderate';
      const headline =
        severity === 'critical'
          ? 'CRITICAL SEPSIS RISK — Immediate clinical review recommended'
          : severity === 'high'
          ? 'HIGH SEPSIS RISK — Clinical review recommended'
          : 'MODERATE SEPSIS RISK — Monitor physiological trajectory';

      initialAlerts.push({
        id: `alt-${pMeta.id}-${Date.now() + idx}`,
        patientId: pMeta.id,
        patientName: pMeta.name,
        bed: pMeta.bed,
        riskScore: pred.riskScore,
        severity,
        headline,
        primaryReason: topFactor ? topFactor.clinicalInterpretation : 'Multi-parameter clinical deterioration',
        contributingFactors: pred.featureContributions.slice(0, 3).map((fc) => `${fc.label} (${fc.currentValue} ${fc.unit}): +${fc.contributionPercent}%`),
        timestamp: pred.timestamp,
        status: 'active',
      });
    }
  });

  return { patients, initialAlerts };
}
