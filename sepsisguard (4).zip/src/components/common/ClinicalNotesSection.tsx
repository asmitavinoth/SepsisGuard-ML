/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { Patient, ClinicalNote, ClinicalNoteCategory, RiskLevel } from '../../types/sepsis';
import { RiskBadge } from './RiskBadge';
import {
  FileText,
  Lock,
  PlusCircle,
  Edit3,
  Trash2,
  CheckCircle2,
  Clock,
  ShieldCheck,
  AlertTriangle,
  UserCheck,
  ChevronDown,
  Filter,
} from 'lucide-react';

interface ClinicalNotesSectionProps {
  patient: Patient;
}

export const ClinicalNotesSection: React.FC<ClinicalNotesSectionProps> = ({ patient }) => {
  const { clinicalNotes, addClinicalNote, updateClinicalNote, deleteClinicalNote, currentUser } = useApp();

  const patientNotes = clinicalNotes.filter((n) => n.patientId === patient.id);

  // Filter state
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [isAddingNote, setIsAddingNote] = useState<boolean>(false);
  const [editingNoteId, setEditingNoteId] = useState<string | null>(null);

  // Form states for creating note
  const [newTitle, setNewTitle] = useState('');
  const [newCategory, setNewCategory] = useState<ClinicalNoteCategory>('Assessment & Plan');
  const [newContent, setNewContent] = useState('');
  const [selectedEpochIndex, setSelectedEpochIndex] = useState<number>(-1); // -1 = latest
  const [isConfidential, setIsConfidential] = useState(false);

  // Form states for editing note
  const [editTitle, setEditTitle] = useState('');
  const [editCategory, setEditCategory] = useState<ClinicalNoteCategory>('Assessment & Plan');
  const [editContent, setEditContent] = useState('');

  // Observation choices
  const latestPred = patient.latestPrediction;
  const observations = [
    {
      index: -1,
      label: `Current Observation (${latestPred?.riskScore ?? 15}% — ${latestPred?.riskLevel ?? 'LOW'})`,
      riskScore: latestPred?.riskScore ?? 15,
      riskLevel: latestPred?.riskLevel ?? 'LOW',
      time: latestPred?.timestamp || new Date().toISOString(),
    },
    ...patient.history.slice(-6).reverse().map((h, idx) => ({
      index: idx,
      label: `${new Date(h.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })} (HR ${h.heartRate}, MAP ${h.map}, Lactate ${h.lactate})`,
      riskScore: patient.latestPrediction?.riskScore ?? 15,
      riskLevel: patient.latestPrediction?.riskLevel ?? 'LOW',
      time: h.timestamp,
    })),
  ];

  const handleStartAdd = () => {
    setNewTitle('');
    setNewCategory('Assessment & Plan');
    setNewContent('');
    setSelectedEpochIndex(-1);
    setIsConfidential(false);
    setIsAddingNote(true);
    setEditingNoteId(null);
  };

  const handleCreateNote = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle.trim() || !newContent.trim()) return;

    const chosenObs = observations.find((o) => o.index === selectedEpochIndex) || observations[0];

    addClinicalNote({
      patientId: patient.id,
      authorId: currentUser.id,
      authorName: currentUser.name,
      authorRole: currentUser.role,
      authorTitle: currentUser.role === 'Doctor' ? 'Attending Intensivist' : currentUser.role === 'Nurse' ? 'ICU Staff Nurse' : 'Clinical AI Researcher',
      category: newCategory,
      title: newTitle.trim(),
      content: newContent.trim(),
      linkedRiskScore: chosenObs.riskScore,
      linkedRiskLevel: chosenObs.riskLevel,
      linkedObservationTime: chosenObs.time,
      isConfidential,
    });

    setIsAddingNote(false);
    setNewTitle('');
    setNewContent('');
  };

  const handleStartEdit = (note: ClinicalNote) => {
    setEditingNoteId(note.id);
    setEditTitle(note.title);
    setEditCategory(note.category);
    setEditContent(note.content);
    setIsAddingNote(false);
  };

  const handleSaveEdit = (e: React.FormEvent, noteId: string) => {
    e.preventDefault();
    if (!editTitle.trim() || !editContent.trim()) return;

    updateClinicalNote(noteId, {
      title: editTitle.trim(),
      category: editCategory,
      content: editContent.trim(),
    });

    setEditingNoteId(null);
  };

  const filteredNotes = patientNotes.filter((n) => {
    if (selectedCategory === 'all') return true;
    return n.category === selectedCategory;
  });

  const categories: ClinicalNoteCategory[] = [
    'Assessment & Plan',
    'Bedside Evaluation',
    'Resuscitation Response',
    'Diagnostic Workup',
    'Attending Sign-Off',
  ];

  const canEdit = currentUser.role === 'Doctor' || currentUser.role === 'Nurse';

  return (
    <div className="bg-slate-900/90 border border-slate-800 rounded-lg p-5 space-y-4 font-sans">
      {/* Section Header with Security Badge */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-800 pb-3">
        <div>
          <div className="flex items-center gap-2">
            <Lock className="w-4 h-4 text-cyan-400" />
            <h3 className="text-sm font-bold text-white uppercase tracking-wider">
              Secure Clinical Notes &amp; Observation Attestation
            </h3>
            <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-cyan-950/80 text-cyan-300 border border-cyan-800">
              AUDITED CDS
            </span>
          </div>
          <p className="text-xs text-slate-400 mt-0.5">
            Timestamped clinical observations linked to model-estimated sepsis risk trajectories.
          </p>
        </div>

        <div className="flex items-center gap-2">
          {/* Add Note Button */}
          {canEdit && (
            <button
              onClick={handleStartAdd}
              className="px-3.5 py-1.5 rounded bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold text-xs flex items-center gap-1.5 transition-colors shadow-sm"
            >
              <PlusCircle className="w-3.5 h-3.5" />
              Add Clinical Note
            </button>
          )}
        </div>
      </div>

      {/* Filter Tabs by Note Category */}
      <div className="flex items-center gap-1 overflow-x-auto pb-1 text-xs">
        <button
          onClick={() => setSelectedCategory('all')}
          className={`px-3 py-1 rounded transition-colors whitespace-nowrap ${
            selectedCategory === 'all'
              ? 'bg-slate-800 text-white font-semibold border border-slate-700'
              : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          All Notes ({patientNotes.length})
        </button>
        {categories.map((cat) => {
          const count = patientNotes.filter((n) => n.category === cat).length;
          return (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`px-3 py-1 rounded transition-colors whitespace-nowrap ${
                selectedCategory === cat
                  ? 'bg-slate-800 text-cyan-300 font-semibold border border-slate-700'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              {cat} {count > 0 && `(${count})`}
            </button>
          );
        })}
      </div>

      {/* Add New Note Form Drawer */}
      {isAddingNote && (
        <form
          onSubmit={handleCreateNote}
          className="bg-slate-950/90 border border-cyan-500/50 rounded-lg p-4 space-y-3.5 text-xs shadow-xl"
        >
          <div className="flex items-center justify-between border-b border-slate-800 pb-2">
            <div className="flex items-center gap-2 text-cyan-300 font-bold text-xs uppercase tracking-wider">
              <PlusCircle className="w-4 h-4" />
              <span>Draft New Clinical Observation Note</span>
            </div>
            <button
              type="button"
              onClick={() => setIsAddingNote(false)}
              className="text-slate-400 hover:text-white font-bold text-sm"
            >
              &times;
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {/* Note Category */}
            <div>
              <label className="text-slate-300 font-medium block mb-1">Note Category:</label>
              <select
                value={newCategory}
                onChange={(e) => setNewCategory(e.target.value as ClinicalNoteCategory)}
                className="w-full bg-slate-900 border border-slate-700 rounded px-2.5 py-1.5 text-slate-200 focus:outline-none focus:border-cyan-500"
              >
                {categories.map((cat) => (
                  <option key={cat} value={cat}>
                    {cat}
                  </option>
                ))}
              </select>
            </div>

            {/* Linked Sepsis Risk Observation */}
            <div>
              <label className="text-slate-300 font-medium block mb-1">
                Link to Telemetry Risk Observation:
              </label>
              <select
                value={selectedEpochIndex}
                onChange={(e) => setSelectedEpochIndex(Number(e.target.value))}
                className="w-full bg-slate-900 border border-slate-700 rounded px-2.5 py-1.5 text-slate-200 font-mono text-[11px] focus:outline-none focus:border-cyan-500"
              >
                {observations.map((obs) => (
                  <option key={obs.index} value={obs.index}>
                    {obs.label}
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Note Title */}
          <div>
            <label className="text-slate-300 font-medium block mb-1">Note Title / Clinical Summary:</label>
            <input
              type="text"
              required
              value={newTitle}
              onChange={(e) => setNewTitle(e.target.value)}
              placeholder="e.g. Sepsis Resuscitation Assessment & Vasopressor Protocol Titration"
              className="w-full bg-slate-900 border border-slate-700 rounded px-3 py-1.5 text-slate-100 placeholder-slate-500 focus:outline-none focus:border-cyan-500"
            />
          </div>

          {/* Note Content */}
          <div>
            <label className="text-slate-300 font-medium block mb-1">
              Physiological Evaluation, Plan &amp; Diagnostic Rationale:
            </label>
            <textarea
              required
              rows={4}
              value={newContent}
              onChange={(e) => setNewContent(e.target.value)}
              placeholder="Document physical findings, clinical correlation with elevated risk score, organ perfusion, antibiotic coverage, fluids, or attending recommendations..."
              className="w-full bg-slate-900 border border-slate-700 rounded p-2.5 text-slate-100 placeholder-slate-500 focus:outline-none focus:border-cyan-500 font-sans text-xs"
            />
          </div>

          {/* Author Badge & Save Button */}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pt-2 border-t border-slate-800">
            <div className="flex items-center gap-2 text-[11px] text-slate-400">
              <UserCheck className="w-3.5 h-3.5 text-cyan-400 shrink-0" />
              <span>
                Signing as: <strong>{currentUser.name}</strong> ({currentUser.role} · {currentUser.department.split('/')[0]})
              </span>
            </div>

            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => setIsAddingNote(false)}
                className="px-3 py-1.5 rounded bg-slate-800 hover:bg-slate-700 text-slate-300"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-4 py-1.5 rounded bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold"
              >
                Sign &amp; Append Note
              </button>
            </div>
          </div>
        </form>
      )}

      {/* Notes List */}
      <div className="space-y-3">
        {filteredNotes.length === 0 ? (
          <div className="p-8 text-center bg-slate-950/50 rounded-lg border border-slate-800 text-xs text-slate-500">
            No clinical notes documented under category &quot;{selectedCategory}&quot; for {patient.name} ({patient.bed}).
          </div>
        ) : (
          filteredNotes.map((note) => {
            const isEditing = editingNoteId === note.id;

            if (isEditing) {
              return (
                <form
                  key={note.id}
                  onSubmit={(e) => handleSaveEdit(e, note.id)}
                  className="bg-slate-950 border border-cyan-500/60 rounded-lg p-4 space-y-3 text-xs"
                >
                  <div className="flex items-center justify-between text-xs font-bold text-cyan-300">
                    <span>Editing Clinical Note: {note.title}</span>
                    <button
                      type="button"
                      onClick={() => setEditingNoteId(null)}
                      className="text-slate-400 hover:text-white"
                    >
                      Cancel
                    </button>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                    <div>
                      <label className="text-slate-400 block mb-1">Category</label>
                      <select
                        value={editCategory}
                        onChange={(e) => setEditCategory(e.target.value as ClinicalNoteCategory)}
                        className="w-full bg-slate-900 border border-slate-700 rounded px-2.5 py-1 text-slate-200"
                      >
                        {categories.map((c) => (
                          <option key={c} value={c}>
                            {c}
                          </option>
                        ))}
                      </select>
                    </div>

                    <div>
                      <label className="text-slate-400 block mb-1">Title</label>
                      <input
                        type="text"
                        value={editTitle}
                        onChange={(e) => setEditTitle(e.target.value)}
                        className="w-full bg-slate-900 border border-slate-700 rounded px-2.5 py-1 text-slate-100"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="text-slate-400 block mb-1">Content</label>
                    <textarea
                      rows={4}
                      value={editContent}
                      onChange={(e) => setEditContent(e.target.value)}
                      className="w-full bg-slate-900 border border-slate-700 rounded p-2 text-slate-100 font-sans"
                    />
                  </div>

                  <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-800">
                    <button
                      type="button"
                      onClick={() => setEditingNoteId(null)}
                      className="px-3 py-1 rounded bg-slate-800 text-slate-300"
                    >
                      Cancel
                    </button>
                    <button
                      type="submit"
                      className="px-4 py-1 rounded bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold"
                    >
                      Save Changes
                    </button>
                  </div>
                </form>
              );
            }

            return (
              <div
                key={note.id}
                className="bg-slate-950/70 border border-slate-800/90 rounded-lg p-4 space-y-2.5 text-xs transition-colors hover:border-slate-700"
              >
                {/* Note Header: Category | Title | Linked Observation Badge | Author */}
                <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-2 border-b border-slate-800/80 pb-2.5">
                  <div className="space-y-1">
                    <div className="flex flex-wrap items-center gap-2">
                      <span className="font-semibold text-cyan-400 text-[11px] uppercase tracking-wider">
                        {note.category}
                      </span>
                      <span className="text-slate-600">·</span>
                      <h4 className="font-bold text-slate-100 text-sm">{note.title}</h4>
                    </div>

                    <div className="flex flex-wrap items-center gap-2 text-[11px] text-slate-400">
                      <span className="font-semibold text-slate-300">{note.authorName}</span>
                      <span className="text-slate-500 font-mono">({note.authorTitle})</span>
                      <span className="text-slate-600">·</span>
                      <span className="font-mono text-slate-500">
                        {new Date(note.timestamp).toLocaleString()}
                      </span>
                      {note.lastEditedAt && (
                        <span className="text-slate-500 italic">
                          (Edited {new Date(note.lastEditedAt).toLocaleTimeString()})
                        </span>
                      )}
                    </div>
                  </div>

                  {/* Linked Sepsis Risk Observation Badge */}
                  <div className="flex items-center gap-2 shrink-0 self-start sm:self-center">
                    <div className="p-1.5 bg-slate-900 rounded border border-slate-800 flex items-center gap-2 font-mono text-[11px]">
                      <span className="text-slate-500 text-[10px] uppercase">Linked Risk:</span>
                      <RiskBadge
                        score={note.linkedRiskScore}
                        level={note.linkedRiskLevel}
                        showTrend={false}
                        size="sm"
                      />
                    </div>

                    {/* Doctor Edit / Delete Controls */}
                    {canEdit && (
                      <div className="flex items-center gap-1 pl-1">
                        <button
                          onClick={() => handleStartEdit(note)}
                          className="p-1 text-slate-400 hover:text-white rounded hover:bg-slate-800 transition-colors"
                          title="Edit Note"
                        >
                          <Edit3 className="w-3.5 h-3.5" />
                        </button>
                        <button
                          onClick={() => deleteClinicalNote(note.id)}
                          className="p-1 text-slate-400 hover:text-rose-400 rounded hover:bg-slate-800 transition-colors"
                          title="Archive Note"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    )}
                  </div>
                </div>

                {/* Note Body */}
                <p className="text-slate-200 leading-relaxed text-xs whitespace-pre-wrap">
                  {note.content}
                </p>

                {/* Observation Anchor Timestamp */}
                <div className="pt-2 border-t border-slate-800/60 flex items-center justify-between text-[10px] text-slate-500 font-mono">
                  <span>
                    Linked Observation Epoch: {new Date(note.linkedObservationTime).toLocaleString()}
                  </span>
                  <span className="text-emerald-500 flex items-center gap-1">
                    <ShieldCheck className="w-3 h-3" />
                    Attested in Clinical Audit Log
                  </span>
                </div>
              </div>
            );
          })
        )}
      </div>
    </div>
  );
};
