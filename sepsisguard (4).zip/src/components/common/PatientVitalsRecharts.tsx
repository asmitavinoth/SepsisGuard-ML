/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useMemo } from 'react';
import {
  ResponsiveContainer,
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ReferenceLine,
  ReferenceArea,
} from 'recharts';
import { PatientMeasurement } from '../../types/sepsis';
import { Heart, Droplets, Wind, Activity, Maximize2, Minimize2 } from 'lucide-react';

interface PatientVitalsRechartsProps {
  history: PatientMeasurement[];
  height?: number;
  className?: string;
  showReferenceBands?: boolean;
}

interface CustomTooltipProps {
  active?: boolean;
  payload?: any[];
  label?: string;
}

const CustomVitalsTooltip: React.FC<CustomTooltipProps> = ({ active, payload, label }) => {
  if (!active || !payload || payload.length === 0) return null;

  return (
    <div className="bg-slate-900/95 border border-slate-700/80 rounded-lg p-3 shadow-xl backdrop-blur-md text-xs font-sans min-w-[200px] z-50">
      <div className="font-mono text-[11px] text-slate-400 border-b border-slate-800 pb-1.5 mb-2 flex items-center justify-between">
        <span className="font-semibold text-slate-200">ICU Telemetry Epoch</span>
        <span className="text-cyan-400 font-bold">{label}</span>
      </div>

      <div className="space-y-1.5 font-mono">
        {payload.map((entry, index) => {
          const val = entry.value;
          let target = '';
          let isAbnormal = false;

          if (entry.dataKey === 'heartRate') {
            target = 'Target: 60–100 bpm';
            isAbnormal = val < 55 || val > 100;
          } else if (entry.dataKey === 'map') {
            target = 'Target: 70–105 mmHg (Min ≥ 65)';
            isAbnormal = val < 65;
          } else if (entry.dataKey === 'spo2') {
            target = 'Target: 95–100%';
            isAbnormal = val < 94;
          }

          return (
            <div key={`item-${index}`} className="flex items-center justify-between text-xs py-0.5">
              <div className="flex items-center gap-1.5">
                <span
                  className="w-2.5 h-2.5 rounded-full shrink-0"
                  style={{ backgroundColor: entry.color }}
                />
                <span className="text-slate-300 font-sans">{entry.name}:</span>
              </div>

              <div className="text-right">
                <span
                  className={`font-bold tabular-nums ${
                    isAbnormal ? 'text-rose-400 font-black' : 'text-slate-100'
                  }`}
                >
                  {val} {entry.unit}
                </span>
                <span className="text-[10px] text-slate-500 block font-sans">{target}</span>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};

export const PatientVitalsRecharts: React.FC<PatientVitalsRechartsProps> = ({
  history,
  height = 320,
  className = '',
  showReferenceBands = true,
}) => {
  // Metric visibility toggles
  const [showHR, setShowHR] = useState(true);
  const [showMAP, setShowMAP] = useState(true);
  const [showSpO2, setShowSpO2] = useState(true);
  const [displayMode, setDisplayMode] = useState<'combined' | 'separated'>('combined');
  const [highlightReferenceLines, setHighlightReferenceLines] = useState(true);

  // Transform data for Recharts
  const chartData = useMemo(() => {
    if (!history || history.length === 0) return [];

    return history.map((m, index) => {
      const date = new Date(m.timestamp);
      const timeLabel = !isNaN(date.getTime())
        ? date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
        : `T+${index}h`;

      return {
        timestamp: m.timestamp,
        timeLabel,
        heartRate: m.heartRate,
        map: m.map,
        sbp: m.sbp,
        dbp: m.dbp,
        spo2: m.spo2,
        lactate: m.lactate,
        respiratoryRate: m.respiratoryRate,
      };
    });
  }, [history]);

  if (!chartData || chartData.length === 0) {
    return (
      <div className="p-8 text-center text-xs text-slate-500 bg-slate-950/50 rounded-lg border border-slate-800">
        No continuous telemetry recorded for this patient.
      </div>
    );
  }

  const latest = chartData[chartData.length - 1];

  return (
    <div className={`space-y-3 font-sans ${className}`}>
      {/* Vitals Telemetry Header & Interactive Toggles */}
      <div className="flex flex-wrap items-center justify-between gap-3 p-3 bg-slate-950/80 rounded-lg border border-slate-800/90 text-xs">
        {/* Real-Time Snapshot Pills with toggle behavior */}
        <div className="flex flex-wrap items-center gap-2">
          {/* Heart Rate Toggle */}
          <button
            onClick={() => setShowHR(!showHR)}
            className={`px-2.5 py-1.5 rounded flex items-center gap-2 transition-all border ${
              showHR
                ? 'bg-rose-950/40 border-rose-500/50 text-rose-300 font-semibold'
                : 'bg-slate-900 border-slate-800 text-slate-500 opacity-60'
            }`}
            title="Toggle Heart Rate trace"
          >
            <Heart className="w-3.5 h-3.5 text-rose-400" />
            <span>Heart Rate</span>
            <span className="font-mono text-slate-100 font-bold tabular-nums">
              {latest.heartRate} <span className="text-[10px] text-slate-400">bpm</span>
            </span>
          </button>

          {/* MAP Toggle */}
          <button
            onClick={() => setShowMAP(!showMAP)}
            className={`px-2.5 py-1.5 rounded flex items-center gap-2 transition-all border ${
              showMAP
                ? 'bg-sky-950/40 border-sky-500/50 text-sky-300 font-semibold'
                : 'bg-slate-900 border-slate-800 text-slate-500 opacity-60'
            }`}
            title="Toggle Mean Arterial Pressure trace"
          >
            <Droplets className="w-3.5 h-3.5 text-sky-400" />
            <span>MAP</span>
            <span className="font-mono text-slate-100 font-bold tabular-nums">
              {latest.map} <span className="text-[10px] text-slate-400">mmHg</span>
            </span>
          </button>

          {/* SpO2 Toggle */}
          <button
            onClick={() => setShowSpO2(!showSpO2)}
            className={`px-2.5 py-1.5 rounded flex items-center gap-2 transition-all border ${
              showSpO2
                ? 'bg-emerald-950/40 border-emerald-500/50 text-emerald-300 font-semibold'
                : 'bg-slate-900 border-slate-800 text-slate-500 opacity-60'
            }`}
            title="Toggle Oxygen Saturation trace"
          >
            <Wind className="w-3.5 h-3.5 text-emerald-400" />
            <span>SpO₂</span>
            <span className="font-mono text-slate-100 font-bold tabular-nums">
              {latest.spo2} <span className="text-[10px] text-slate-400">%</span>
            </span>
          </button>
        </div>

        {/* View Options */}
        <div className="flex items-center gap-2">
          {/* Reference Line Toggle */}
          <button
            onClick={() => setHighlightReferenceLines(!highlightReferenceLines)}
            className={`px-2 py-1 rounded text-[11px] font-medium border transition-colors ${
              highlightReferenceLines
                ? 'bg-slate-800 text-cyan-300 border-cyan-500/40'
                : 'bg-slate-900 text-slate-500 border-slate-800'
            }`}
          >
            Clinical Thresholds ({highlightReferenceLines ? 'On' : 'Off'})
          </button>

          {/* Mode Switcher */}
          <div className="flex items-center gap-0.5 p-0.5 bg-slate-900 rounded border border-slate-800 text-[11px]">
            <button
              onClick={() => setDisplayMode('combined')}
              className={`px-2 py-1 rounded transition-colors ${
                displayMode === 'combined'
                  ? 'bg-slate-800 text-white font-semibold'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              Overlay
            </button>
            <button
              onClick={() => setDisplayMode('separated')}
              className={`px-2 py-1 rounded transition-colors ${
                displayMode === 'separated'
                  ? 'bg-slate-800 text-white font-semibold'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              Split View
            </button>
          </div>
        </div>
      </div>

      {/* Main Chart Canvas: Combined Mode */}
      {displayMode === 'combined' ? (
        <div className="bg-slate-950/80 border border-slate-800/90 rounded-lg p-3 pt-4">
          <div className="h-[300px] w-full">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={chartData} margin={{ top: 10, right: 20, left: -10, bottom: 5 }}>
                <CartesianGrid stroke="#1e293b" strokeDasharray="3 3" vertical={false} />

                <XAxis
                  dataKey="timeLabel"
                  stroke="#64748b"
                  fontSize={11}
                  tickLine={false}
                  axisLine={{ stroke: '#334155' }}
                />

                {/* Left Y Axis for HR and MAP (Pressure / Rate 40-160) */}
                <YAxis
                  yAxisId="hemodynamics"
                  domain={[40, 160]}
                  stroke="#94a3b8"
                  fontSize={11}
                  tickLine={false}
                  axisLine={{ stroke: '#334155' }}
                  tickFormatter={(val) => `${val}`}
                />

                {/* Right Y Axis for SpO2 percentage (75-100) */}
                <YAxis
                  yAxisId="saturation"
                  orientation="right"
                  domain={[75, 100]}
                  stroke="#34d399"
                  fontSize={11}
                  tickLine={false}
                  axisLine={{ stroke: '#334155' }}
                  tickFormatter={(val) => `${val}%`}
                />

                <Tooltip content={<CustomVitalsTooltip />} />

                {/* Clinical Reference Areas / Lines */}
                {highlightReferenceLines && (
                  <>
                    {/* Critical MAP Threshold = 65 mmHg line */}
                    {showMAP && (
                      <ReferenceLine
                        yAxisId="hemodynamics"
                        y={65}
                        stroke="#f43f5e"
                        strokeDasharray="4 4"
                        strokeWidth={1.5}
                        label={{
                          value: 'MAP < 65 Target',
                          fill: '#f43f5e',
                          fontSize: 10,
                          position: 'insideBottomLeft',
                        }}
                      />
                    )}

                    {/* Nominal Heart Rate Zone (60-100 bpm) */}
                    {showHR && (
                      <ReferenceArea
                        yAxisId="hemodynamics"
                        y1={60}
                        y2={100}
                        fill="#f43f5e"
                        fillOpacity={0.04}
                      />
                    )}

                    {/* Critical SpO2 Threshold = 93% line */}
                    {showSpO2 && (
                      <ReferenceLine
                        yAxisId="saturation"
                        y={93}
                        stroke="#f59e0b"
                        strokeDasharray="3 3"
                        strokeWidth={1}
                        label={{
                          value: 'SpO₂ < 93%',
                          fill: '#f59e0b',
                          fontSize: 10,
                          position: 'insideTopRight',
                        }}
                      />
                    )}
                  </>
                )}

                {/* Heart Rate Line */}
                {showHR && (
                  <Line
                    yAxisId="hemodynamics"
                    type="monotone"
                    dataKey="heartRate"
                    name="Heart Rate"
                    unit="bpm"
                    stroke="#f43f5e"
                    strokeWidth={2.5}
                    dot={{ r: 3, fill: '#f43f5e', stroke: '#0f172a', strokeWidth: 1.5 }}
                    activeDot={{ r: 5, fill: '#ffffff', stroke: '#f43f5e', strokeWidth: 2 }}
                    isAnimationActive={false}
                  />
                )}

                {/* MAP Line */}
                {showMAP && (
                  <Line
                    yAxisId="hemodynamics"
                    type="monotone"
                    dataKey="map"
                    name="MAP"
                    unit="mmHg"
                    stroke="#38bdf8"
                    strokeWidth={2.5}
                    dot={{ r: 3, fill: '#38bdf8', stroke: '#0f172a', strokeWidth: 1.5 }}
                    activeDot={{ r: 5, fill: '#ffffff', stroke: '#38bdf8', strokeWidth: 2 }}
                    isAnimationActive={false}
                  />
                )}

                {/* SpO2 Line */}
                {showSpO2 && (
                  <Line
                    yAxisId="saturation"
                    type="monotone"
                    dataKey="spo2"
                    name="SpO₂"
                    unit="%"
                    stroke="#34d399"
                    strokeWidth={2.5}
                    dot={{ r: 3, fill: '#34d399', stroke: '#0f172a', strokeWidth: 1.5 }}
                    activeDot={{ r: 5, fill: '#ffffff', stroke: '#34d399', strokeWidth: 2 }}
                    isAnimationActive={false}
                  />
                )}
              </LineChart>
            </ResponsiveContainer>
          </div>

          {/* Reference Legend Bar */}
          <div className="flex flex-wrap items-center justify-between gap-2 pt-2 border-t border-slate-800/80 text-[11px] text-slate-400">
            <div className="flex items-center gap-4">
              <span className="flex items-center gap-1.5">
                <span className="w-2.5 h-0.5 bg-rose-500 inline-block" />
                <span>Heart Rate (Left Axis)</span>
              </span>
              <span className="flex items-center gap-1.5">
                <span className="w-2.5 h-0.5 bg-sky-400 inline-block" />
                <span>MAP (Left Axis, cutoff 65 mmHg)</span>
              </span>
              <span className="flex items-center gap-1.5">
                <span className="w-2.5 h-0.5 bg-emerald-400 inline-block" />
                <span>SpO₂ (Right Axis, target ≥ 95%)</span>
              </span>
            </div>

            <div className="font-mono text-slate-500">
              {chartData.length} observations ({chartData[0].timeLabel} → {latest.timeLabel})
            </div>
          </div>
        </div>
      ) : (
        /* Separated Strip Mode */
        <div className="space-y-3">
          {/* Heart Rate Strip */}
          {showHR && (
            <div className="bg-slate-950/80 border border-slate-800/90 rounded-lg p-3">
              <div className="flex items-center justify-between text-xs mb-1">
                <div className="flex items-center gap-1.5 text-rose-400 font-semibold">
                  <Heart className="w-3.5 h-3.5" />
                  <span>Heart Rate Trajectory (bpm)</span>
                </div>
                <span className="font-mono text-slate-300 font-bold tabular-nums">
                  Latest: {latest.heartRate} bpm
                </span>
              </div>
              <div className="h-[120px] w-full">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={chartData} margin={{ top: 5, right: 15, left: -20, bottom: 0 }}>
                    <CartesianGrid stroke="#1e293b" strokeDasharray="2 2" vertical={false} />
                    <XAxis dataKey="timeLabel" stroke="#64748b" fontSize={10} tickLine={false} />
                    <YAxis domain={[50, 150]} stroke="#64748b" fontSize={10} tickLine={false} />
                    <Tooltip content={<CustomVitalsTooltip />} />
                    {highlightReferenceLines && (
                      <ReferenceLine y={100} stroke="#f43f5e" strokeDasharray="3 3" />
                    )}
                    <Line
                      type="monotone"
                      dataKey="heartRate"
                      name="Heart Rate"
                      unit="bpm"
                      stroke="#f43f5e"
                      strokeWidth={2}
                      dot={{ r: 2.5, fill: '#f43f5e' }}
                      isAnimationActive={false}
                    />
                  </LineChart>
                </ResponsiveContainer>
              </div>
            </div>
          )}

          {/* MAP Strip */}
          {showMAP && (
            <div className="bg-slate-950/80 border border-slate-800/90 rounded-lg p-3">
              <div className="flex items-center justify-between text-xs mb-1">
                <div className="flex items-center gap-1.5 text-sky-400 font-semibold">
                  <Droplets className="w-3.5 h-3.5" />
                  <span>Mean Arterial Pressure (MAP, mmHg)</span>
                </div>
                <span className="font-mono text-slate-300 font-bold tabular-nums">
                  Latest: {latest.map} mmHg (BP: {latest.sbp}/{latest.dbp})
                </span>
              </div>
              <div className="h-[120px] w-full">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={chartData} margin={{ top: 5, right: 15, left: -20, bottom: 0 }}>
                    <CartesianGrid stroke="#1e293b" strokeDasharray="2 2" vertical={false} />
                    <XAxis dataKey="timeLabel" stroke="#64748b" fontSize={10} tickLine={false} />
                    <YAxis domain={[45, 120]} stroke="#64748b" fontSize={10} tickLine={false} />
                    <Tooltip content={<CustomVitalsTooltip />} />
                    {highlightReferenceLines && (
                      <ReferenceLine
                        y={65}
                        stroke="#f43f5e"
                        strokeDasharray="4 4"
                        label={{ value: 'Critical 65', fill: '#f43f5e', fontSize: 9 }}
                      />
                    )}
                    <Line
                      type="monotone"
                      dataKey="map"
                      name="MAP"
                      unit="mmHg"
                      stroke="#38bdf8"
                      strokeWidth={2}
                      dot={{ r: 2.5, fill: '#38bdf8' }}
                      isAnimationActive={false}
                    />
                  </LineChart>
                </ResponsiveContainer>
              </div>
            </div>
          )}

          {/* SpO2 Strip */}
          {showSpO2 && (
            <div className="bg-slate-950/80 border border-slate-800/90 rounded-lg p-3">
              <div className="flex items-center justify-between text-xs mb-1">
                <div className="flex items-center gap-1.5 text-emerald-400 font-semibold">
                  <Wind className="w-3.5 h-3.5" />
                  <span>Oxygen Saturation (SpO₂, %)</span>
                </div>
                <span className="font-mono text-slate-300 font-bold tabular-nums">
                  Latest: {latest.spo2}%
                </span>
              </div>
              <div className="h-[120px] w-full">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={chartData} margin={{ top: 5, right: 15, left: -20, bottom: 0 }}>
                    <CartesianGrid stroke="#1e293b" strokeDasharray="2 2" vertical={false} />
                    <XAxis dataKey="timeLabel" stroke="#64748b" fontSize={10} tickLine={false} />
                    <YAxis domain={[80, 100]} stroke="#64748b" fontSize={10} tickLine={false} />
                    <Tooltip content={<CustomVitalsTooltip />} />
                    {highlightReferenceLines && (
                      <ReferenceLine y={93} stroke="#f59e0b" strokeDasharray="3 3" />
                    )}
                    <Line
                      type="monotone"
                      dataKey="spo2"
                      name="SpO₂"
                      unit="%"
                      stroke="#34d399"
                      strokeWidth={2}
                      dot={{ r: 2.5, fill: '#34d399' }}
                      isAnimationActive={false}
                    />
                  </LineChart>
                </ResponsiveContainer>
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
