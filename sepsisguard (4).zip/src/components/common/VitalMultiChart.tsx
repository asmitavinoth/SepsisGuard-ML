/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { PatientMeasurement } from '../../types/sepsis';

interface MetricConfig {
  key: keyof PatientMeasurement;
  label: string;
  unit: string;
  normalMin: number;
  normalMax: number;
  color: string;
  minScale?: number;
  maxScale?: number;
}

const AVAILABLE_METRICS: MetricConfig[] = [
  { key: 'heartRate', label: 'Heart Rate', unit: 'bpm', normalMin: 60, normalMax: 100, color: '#f43f5e' },
  { key: 'map', label: 'MAP', unit: 'mmHg', normalMin: 70, normalMax: 105, color: '#38bdf8' },
  { key: 'sbp', label: 'Systolic BP', unit: 'mmHg', normalMin: 90, normalMax: 120, color: '#818cf8' },
  { key: 'respiratoryRate', label: 'Resp Rate', unit: 'bpm', normalMin: 12, normalMax: 20, color: '#fb923c' },
  { key: 'temperature', label: 'Temp', unit: '°C', normalMin: 36.1, normalMax: 37.5, color: '#facc15' },
  { key: 'spo2', label: 'SpO₂', unit: '%', normalMin: 95, normalMax: 100, color: '#34d399' },
  { key: 'lactate', label: 'Lactate', unit: 'mmol/L', normalMin: 0.5, normalMax: 2.0, color: '#e11d48' },
  { key: 'wbc', label: 'WBC', unit: '×10⁹/L', normalMin: 4.5, normalMax: 11.0, color: '#a78bfa' },
  { key: 'platelets', label: 'Platelets', unit: '×10⁹/L', normalMin: 150, normalMax: 450, color: '#2dd4bf' },
  { key: 'creatinine', label: 'Creatinine', unit: 'mg/dL', normalMin: 0.6, normalMax: 1.2, color: '#f97316' },
];

interface VitalMultiChartProps {
  history: PatientMeasurement[];
  height?: number;
}

export const VitalMultiChart: React.FC<VitalMultiChartProps> = ({ history, height = 240 }) => {
  const [selectedKeys, setSelectedKeys] = useState<string[]>(['lactate', 'map', 'heartRate']);
  const [hoverIndex, setHoverIndex] = useState<number | null>(null);

  if (!history || history.length === 0) {
    return <div className="p-8 text-center text-xs text-slate-500">No telemetry records available.</div>;
  }

  const primaryMetric = AVAILABLE_METRICS.find((m) => m.key === selectedKeys[0]) || AVAILABLE_METRICS[0];
  const secondaryMetric = AVAILABLE_METRICS.find((m) => m.key === selectedKeys[1]);

  const toggleMetric = (key: string) => {
    setSelectedKeys((prev) => {
      if (prev.includes(key)) {
        if (prev.length === 1) return prev; // keep at least 1
        return prev.filter((k) => k !== key);
      }
      if (prev.length >= 3) {
        return [prev[1], prev[2], key];
      }
      return [...prev, key];
    });
  };

  // Dimensions
  const padding = { top: 20, right: 30, bottom: 30, left: 45 };
  const width = 640;
  const chartWidth = width - padding.left - padding.right;
  const chartHeight = height - padding.top - padding.bottom;

  // Primary metric scaling
  const valuesP = history.map((h) => Number(h[primaryMetric.key as keyof PatientMeasurement]) || 0);
  const minValP = Math.min(primaryMetric.normalMin * 0.85, ...valuesP);
  const maxValP = Math.max(primaryMetric.normalMax * 1.15, ...valuesP);
  const rangeP = maxValP - minValP || 1;

  const getYPos = (val: number) => {
    return padding.top + chartHeight - ((val - minValP) / rangeP) * chartHeight;
  };

  const getXPos = (index: number) => {
    if (history.length <= 1) return padding.left + chartWidth / 2;
    return padding.left + (index / (history.length - 1)) * chartWidth;
  };

  // Build SVG path for primary metric
  const pointsP = history.map((h, i) => `${getXPos(i)},${getYPos(Number(h[primaryMetric.key as keyof PatientMeasurement]) || 0)}`);
  const pathD = `M ${pointsP.join(' L ')}`;

  // Normal zone bounds for primary metric
  const normalTopY = Math.max(padding.top, getYPos(primaryMetric.normalMax));
  const normalBottomY = Math.min(padding.top + chartHeight, getYPos(primaryMetric.normalMin));
  const normalHeight = Math.max(4, normalBottomY - normalTopY);

  const hoveredMeas = hoverIndex !== null ? history[hoverIndex] : history[history.length - 1];

  return (
    <div className="space-y-3 font-sans">
      {/* Metric Selector Bar */}
      <div className="flex flex-wrap items-center gap-1.5 p-1 bg-slate-900/90 rounded border border-slate-800 text-xs">
        <span className="text-[11px] font-semibold text-slate-500 uppercase px-2">Metrics:</span>
        {AVAILABLE_METRICS.map((m) => {
          const isSelected = selectedKeys.includes(m.key);
          return (
            <button
              key={m.key}
              onClick={() => toggleMetric(m.key)}
              className={`px-2.5 py-1 text-xs rounded transition-colors whitespace-nowrap flex items-center gap-1.5 ${
                isSelected
                  ? 'bg-slate-800 text-white font-medium border border-slate-700 shadow-sm'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <span
                className="w-2 h-2 rounded-full shrink-0"
                style={{ backgroundColor: isSelected ? m.color : '#64748b' }}
              />
              <span>{m.label}</span>
            </button>
          );
        })}
      </div>

      {/* SVG Canvas Area */}
      <div className="relative bg-slate-950/70 border border-slate-800/80 rounded-lg p-3 overflow-hidden">
        <div className="flex items-center justify-between text-xs mb-2">
          <div className="flex items-center gap-3">
            <div className="flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: primaryMetric.color }} />
              <span className="font-semibold text-slate-200">{primaryMetric.label}</span>
              <span className="text-slate-400 font-mono text-[11px]">({primaryMetric.unit})</span>
            </div>
            <span className="text-slate-600">·</span>
            <span className="text-[11px] text-slate-400">
              Ref Target: {primaryMetric.normalMin}–{primaryMetric.normalMax} {primaryMetric.unit}
            </span>
          </div>

          {hoveredMeas && (
            <div className="font-mono text-xs flex items-center gap-3">
              <span className="text-slate-400">
                {new Date(hoveredMeas.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}:
              </span>
              <span className="font-bold text-cyan-400">
                {primaryMetric.label} = {hoveredMeas[primaryMetric.key as keyof PatientMeasurement]} {primaryMetric.unit}
              </span>
            </div>
          )}
        </div>

        <svg
          viewBox={`0 0 ${width} ${height}`}
          className="w-full h-auto overflow-visible select-none"
          onMouseLeave={() => setHoverIndex(null)}
        >
          {/* Normal Reference Range Shading */}
          <rect
            x={padding.left}
            y={normalTopY}
            width={chartWidth}
            height={normalHeight}
            fill="#10b981"
            fillOpacity="0.08"
            stroke="#10b981"
            strokeOpacity="0.25"
            strokeDasharray="2 2"
          />

          {/* Grid lines */}
          {[0, 0.25, 0.5, 0.75, 1].map((pct, idx) => {
            const y = padding.top + chartHeight * pct;
            const val = maxValP - pct * rangeP;
            return (
              <g key={idx}>
                <line
                  x1={padding.left}
                  y1={y}
                  x2={padding.left + chartWidth}
                  y2={y}
                  stroke="#334155"
                  strokeWidth="0.75"
                  strokeDasharray="3 3"
                />
                <text
                  x={padding.left - 6}
                  y={y + 3}
                  textAnchor="end"
                  className="text-[10px] fill-slate-500 font-mono tabular-nums"
                >
                  {val >= 10 ? Math.round(val) : val.toFixed(1)}
                </text>
              </g>
            );
          })}

          {/* Primary Trend Line */}
          <path
            d={pathD}
            fill="none"
            stroke={primaryMetric.color}
            strokeWidth="2.5"
            strokeLinecap="round"
            strokeLinejoin="round"
          />

          {/* Secondary metric line if selected */}
          {secondaryMetric && (
            (() => {
              const valsS = history.map((h) => Number(h[secondaryMetric.key as keyof PatientMeasurement]) || 0);
              const minValS = Math.min(secondaryMetric.normalMin * 0.85, ...valsS);
              const maxValS = Math.max(secondaryMetric.normalMax * 1.15, ...valsS);
              const rangeS = maxValS - minValS || 1;
              const pointsS = history.map(
                (h, i) =>
                  `${getXPos(i)},${
                    padding.top + chartHeight - ((Number(h[secondaryMetric.key as keyof PatientMeasurement]) - minValS) / rangeS) * chartHeight
                  }`
              );
              return (
                <path
                  d={`M ${pointsS.join(' L ')}`}
                  fill="none"
                  stroke={secondaryMetric.color}
                  strokeWidth="2"
                  strokeDasharray="4 2"
                  strokeOpacity="0.8"
                />
              );
            })()
          )}

          {/* Data Points */}
          {history.map((h, i) => {
            const val = Number(h[primaryMetric.key as keyof PatientMeasurement]) || 0;
            const cx = getXPos(i);
            const cy = getYPos(val);
            const isHovered = hoverIndex === i;

            return (
              <g
                key={i}
                className="cursor-pointer"
                onMouseEnter={() => setHoverIndex(i)}
              >
                {/* Invisible hit box for easier hovering */}
                <rect
                  x={cx - 12}
                  y={padding.top}
                  width="24"
                  height={chartHeight}
                  fill="transparent"
                />
                {isHovered && (
                  <line
                    x1={cx}
                    y1={padding.top}
                    x2={cx}
                    y2={padding.top + chartHeight}
                    stroke="#94a3b8"
                    strokeWidth="1"
                    strokeDasharray="2 2"
                  />
                )}
                <circle
                  cx={cx}
                  cy={cy}
                  r={isHovered ? 5.5 : 3.5}
                  fill={isHovered ? '#ffffff' : primaryMetric.color}
                  stroke="#0f172a"
                  strokeWidth="1.5"
                />
              </g>
            );
          })}

          {/* Time axis labels */}
          {history.map((h, i) => {
            if (i % Math.ceil(history.length / 5) !== 0 && i !== history.length - 1) return null;
            const cx = getXPos(i);
            const timeStr = new Date(h.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
            return (
              <text
                key={i}
                x={cx}
                y={height - 8}
                textAnchor="middle"
                className="text-[10px] fill-slate-500 font-mono"
              >
                {timeStr}
              </text>
            );
          })}
        </svg>

        {secondaryMetric && (
          <div className="flex items-center gap-1.5 text-[11px] text-slate-400 mt-1">
            <span className="w-2.5 h-0.5" style={{ backgroundColor: secondaryMetric.color }} />
            <span>Secondary: {secondaryMetric.label} (dashed line)</span>
          </div>
        )}
      </div>
    </div>
  );
};
