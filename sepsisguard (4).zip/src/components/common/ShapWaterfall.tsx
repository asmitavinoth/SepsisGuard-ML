/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { FeatureContribution } from '../../types/sepsis';
import { ArrowUpRight, ArrowDownRight, Info, ShieldCheck } from 'lucide-react';

interface ShapWaterfallProps {
  baseRisk: number; // e.g. 14.5%
  finalRisk: number; // e.g. 74.2%
  features: FeatureContribution[];
  compact?: boolean;
}

export const ShapWaterfall: React.FC<ShapWaterfallProps> = ({
  baseRisk,
  finalRisk,
  features,
  compact = false,
}) => {
  // Take top 6-8 most influential features
  const displayFeatures = compact ? features.slice(0, 5) : features.slice(0, 8);
  const maxContrib = Math.max(15, ...displayFeatures.map((f) => Math.abs(f.contributionPercent)));

  return (
    <div className="space-y-4 font-sans">
      <div className="flex items-center justify-between text-xs border-b border-slate-800 pb-2.5">
        <div>
          <span className="text-slate-400">Baseline Cohort Risk: </span>
          <span className="font-mono text-slate-300 font-medium tabular-nums">{baseRisk.toFixed(1)}%</span>
        </div>
        <div className="text-right">
          <span className="text-slate-400">Model-Estimated Risk: </span>
          <span
            className={`font-mono font-bold tabular-nums ${
              finalRisk >= 75
                ? 'text-rose-400'
                : finalRisk >= 50
                ? 'text-orange-400'
                : finalRisk >= 25
                ? 'text-amber-400'
                : 'text-emerald-400'
            }`}
          >
            {finalRisk.toFixed(1)}%
          </span>
        </div>
      </div>

      <div className="space-y-2.5">
        {displayFeatures.map((fc) => {
          const isIncreasing = fc.direction === 'risk_increasing';
          const absVal = Math.abs(fc.contributionPercent);
          const barWidthPercent = Math.min(100, Math.round((absVal / maxContrib) * 100));

          return (
            <div key={fc.featureKey} className="group text-xs bg-slate-900/60 p-2.5 rounded border border-slate-800/80 hover:border-slate-700 transition-colors">
              <div className="flex items-center justify-between mb-1">
                <div className="flex items-center gap-1.5">
                  {isIncreasing ? (
                    <ArrowUpRight className="w-3.5 h-3.5 text-rose-400 shrink-0" />
                  ) : (
                    <ArrowDownRight className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                  )}
                  <span className="font-medium text-slate-200">{fc.label}</span>
                  <span className="text-[11px] font-mono text-slate-400">
                    ({fc.currentValue} {fc.unit})
                  </span>
                </div>

                <div className="font-mono font-semibold tabular-nums text-right">
                  <span className={isIncreasing ? 'text-rose-400' : 'text-emerald-400'}>
                    {isIncreasing ? '+' : '-'}
                    {absVal.toFixed(1)}%
                  </span>
                </div>
              </div>

              {/* Attribution Bar visual */}
              <div className="w-full bg-slate-950 h-1.5 rounded-full overflow-hidden flex items-center my-1.5">
                <div
                  className={`h-full rounded-full transition-all duration-300 ${
                    isIncreasing ? 'bg-gradient-to-r from-rose-500 to-rose-400' : 'bg-gradient-to-r from-emerald-600 to-emerald-400'
                  }`}
                  style={{ width: `${barWidthPercent}%` }}
                />
              </div>

              {/* Clinical rationale with mandatory safety wording */}
              <p className="text-[11px] text-slate-400 leading-relaxed mt-1">
                {fc.clinicalInterpretation}
                <span className="text-slate-500 ml-1">· Target: {fc.normalRange} {fc.unit}</span>
              </p>
            </div>
          );
        })}
      </div>

      <div className="p-2.5 bg-slate-950/70 border border-slate-800 rounded text-[11px] text-slate-400 flex items-center gap-2">
        <Info className="w-3.5 h-3.5 text-cyan-400 shrink-0" />
        <span>
          Attributions computed via tree SHAP Shapley decomposition. Features <strong className="text-slate-300">contributed to estimated risk</strong> relative to the ICU population baseline; attributions do not establish direct medical causality.
        </span>
      </div>
    </div>
  );
};
