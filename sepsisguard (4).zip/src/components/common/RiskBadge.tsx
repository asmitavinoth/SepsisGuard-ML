/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { RiskLevel, TrendDirection } from '../../types/sepsis';
import { TrendingUp, TrendingDown, Minus } from 'lucide-react';

interface RiskBadgeProps {
  score?: number;
  level: RiskLevel;
  trend?: TrendDirection;
  showTrend?: boolean;
  size?: 'sm' | 'md' | 'lg';
}

export const RiskBadge: React.FC<RiskBadgeProps> = ({
  score,
  level,
  trend,
  showTrend = true,
  size = 'md',
}) => {
  // Color configuration adhering to accessible contrast
  const colorMap: Record<RiskLevel, { text: string; bg: string; border: string; indicator: string }> = {
    LOW: {
      text: 'text-emerald-400 dark:text-emerald-300',
      bg: 'bg-emerald-950/40 dark:bg-emerald-950/60',
      border: 'border-emerald-700/50 dark:border-emerald-600/40',
      indicator: 'bg-emerald-400',
    },
    MODERATE: {
      text: 'text-amber-400 dark:text-amber-300',
      bg: 'bg-amber-950/40 dark:bg-amber-950/60',
      border: 'border-amber-700/50 dark:border-amber-600/40',
      indicator: 'bg-amber-400',
    },
    HIGH: {
      text: 'text-orange-400 dark:text-orange-300',
      bg: 'bg-orange-950/40 dark:bg-orange-950/60',
      border: 'border-orange-700/50 dark:border-orange-600/40',
      indicator: 'bg-orange-400',
    },
    CRITICAL: {
      text: 'text-rose-400 dark:text-rose-300',
      bg: 'bg-rose-950/40 dark:bg-rose-950/60',
      border: 'border-rose-700/50 dark:border-rose-600/40',
      indicator: 'bg-rose-400',
    },
  };

  const c = colorMap[level] || colorMap.LOW;

  const sizeClasses = {
    sm: 'text-[11px] px-2 py-0.5',
    md: 'text-xs px-2.5 py-1',
    lg: 'text-sm px-3.5 py-1.5',
  };

  return (
    <div
      className={`inline-flex items-center gap-1.5 rounded border font-mono font-medium tabular-nums ${c.bg} ${c.border} ${c.text} ${sizeClasses[size]}`}
    >
      <span className={`w-1.5 h-1.5 rounded-full ${c.indicator} shrink-0`} aria-hidden="true" />
      <span>{level}</span>
      {score !== undefined && (
        <>
          <span className="opacity-50">/</span>
          <span className="font-semibold">{score.toFixed(1)}%</span>
        </>
      )}

      {showTrend && trend && (
        <span className="flex items-center gap-0.5 ml-1 border-l border-current/25 pl-1.5 opacity-90">
          {trend === 'Worsening' && (
            <span className="inline-flex items-center text-rose-400 font-sans text-[11px]">
              <TrendingUp className="w-3 h-3 inline mr-0.5" />
              Worsening
            </span>
          )}
          {trend === 'Improving' && (
            <span className="inline-flex items-center text-emerald-400 font-sans text-[11px]">
              <TrendingDown className="w-3 h-3 inline mr-0.5" />
              Improving
            </span>
          )}
          {trend === 'Stable' && (
            <span className="inline-flex items-center text-slate-400 font-sans text-[11px]">
              <Minus className="w-3 h-3 inline mr-0.5" />
              Stable
            </span>
          )}
        </span>
      )}
    </div>
  );
};
