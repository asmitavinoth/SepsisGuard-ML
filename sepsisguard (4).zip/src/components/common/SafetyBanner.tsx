/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { AlertTriangle, Info } from 'lucide-react';

export const SafetyBanner: React.FC<{ compact?: boolean }> = ({ compact = false }) => {
  if (compact) {
    return (
      <div className="flex items-center gap-2 px-3 py-1.5 bg-amber-500/10 border-b border-amber-500/20 text-xs text-amber-300">
        <AlertTriangle className="w-3.5 h-3.5 shrink-0 text-amber-400" />
        <span className="truncate">
          <strong className="font-semibold">Research & Educational Prototype:</strong> Not FDA cleared. Never replace clinical judgment or provide diagnostic confirmation. Synthetic data only.
        </span>
      </div>
    );
  }

  return (
    <div className="relative overflow-hidden rounded-lg border border-amber-500/30 bg-gradient-to-r from-amber-950/40 via-amber-900/20 to-slate-900/60 p-3.5 text-xs text-amber-200/90 shadow-sm">
      <div className="flex items-start gap-2.5">
        <AlertTriangle className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
        <div className="space-y-1">
          <div className="flex items-center gap-2">
            <span className="font-bold uppercase tracking-wider text-[11px] text-amber-400">
              Clinical Decision Support Prototype Notice
            </span>
            <span className="text-slate-400">·</span>
            <span className="text-amber-300 font-medium">SYNTHETIC DATA — NOT REAL PATIENT DATA</span>
          </div>
          <p className="text-slate-300 leading-relaxed">
            SepsisGuard is an investigational and educational early warning decision-support system. Risk estimates (0–100%) represent statistical models trained on synthetic physiological trajectories. Predictions do not confirm sepsis, do not replace clinician bedside assessment, and must never dictate medication or therapy without independent clinical evaluation.
          </p>
        </div>
      </div>
    </div>
  );
};
