/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { RiskBadge } from '../common/RiskBadge';
import { SafetyBanner } from '../common/SafetyBanner';
import {
  Users,
  AlertTriangle,
  TrendingUp,
  Activity,
  ArrowRight,
  Search,
  Filter,
  CheckCircle2,
  Clock,
  HeartPulse,
} from 'lucide-react';
import { RiskLevel } from '../../types/sepsis';

export const OverviewView: React.FC = () => {
  const {
    patients,
    alerts,
    unacknowledgedAlertsCount,
    setCurrentView,
    setSelectedPatientId,
    acknowledgeAlert,
  } = useApp();

  const [searchQuery, setSearchQuery] = useState('');
  const [filterLevel, setFilterLevel] = useState<string>('all');

  const totalPatients = patients.length;
  const criticalPatients = patients.filter((p) => p.latestPrediction?.riskLevel === 'CRITICAL');
  const highPatients = patients.filter((p) => p.latestPrediction?.riskLevel === 'HIGH');
  const moderatePatients = patients.filter((p) => p.latestPrediction?.riskLevel === 'MODERATE');
  const lowPatients = patients.filter((p) => p.latestPrediction?.riskLevel === 'LOW');
  const worseningPatients = patients.filter((p) => p.latestPrediction?.trend === 'Worsening');

  const filteredPatients = patients.filter((p) => {
    const matchesSearch =
      p.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      p.id.toLowerCase().includes(searchQuery.toLowerCase()) ||
      p.bed.toLowerCase().includes(searchQuery.toLowerCase()) ||
      p.admissionDiagnosis.toLowerCase().includes(searchQuery.toLowerCase());

    if (filterLevel === 'all') return matchesSearch;
    if (filterLevel === 'worsening') return matchesSearch && p.latestPrediction?.trend === 'Worsening';
    return matchesSearch && p.latestPrediction?.riskLevel === filterLevel;
  });

  const activeAlerts = alerts.filter((a) => a.status === 'active');

  const handleInspectPatient = (id: string) => {
    setSelectedPatientId(id);
    setCurrentView('patients');
  };

  return (
    <div className="space-y-6">
      {/* Research disclaimer */}
      <SafetyBanner />

      {/* Top ICU KPI Telemetry Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
        <div className="bg-slate-900/80 border border-slate-800 rounded-lg p-3.5 flex flex-col justify-between">
          <div className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider">
            Total ICU Census
          </div>
          <div className="mt-2 flex items-baseline justify-between">
            <span className="text-2xl font-bold font-mono text-white tabular-nums">{totalPatients}</span>
            <span className="text-xs text-slate-500 font-mono">Beds Active</span>
          </div>
        </div>

        <button
          onClick={() => setFilterLevel(filterLevel === 'CRITICAL' ? 'all' : 'CRITICAL')}
          className={`text-left border rounded-lg p-3.5 flex flex-col justify-between transition-all ${
            filterLevel === 'CRITICAL'
              ? 'bg-rose-950/40 border-rose-500/60 ring-1 ring-rose-500/50'
              : 'bg-slate-900/80 border-slate-800 hover:border-rose-900/50'
          }`}
        >
          <div className="text-[11px] font-semibold text-rose-400 uppercase tracking-wider flex items-center justify-between">
            <span>Critical Risk</span>
            <span className="w-2 h-2 rounded-full bg-rose-500" />
          </div>
          <div className="mt-2 flex items-baseline justify-between">
            <span className="text-2xl font-bold font-mono text-rose-300 tabular-nums">
              {criticalPatients.length}
            </span>
            <span className="text-xs text-rose-400/80 font-mono">≥75%</span>
          </div>
        </button>

        <button
          onClick={() => setFilterLevel(filterLevel === 'HIGH' ? 'all' : 'HIGH')}
          className={`text-left border rounded-lg p-3.5 flex flex-col justify-between transition-all ${
            filterLevel === 'HIGH'
              ? 'bg-orange-950/40 border-orange-500/60 ring-1 ring-orange-500/50'
              : 'bg-slate-900/80 border-slate-800 hover:border-orange-900/50'
          }`}
        >
          <div className="text-[11px] font-semibold text-orange-400 uppercase tracking-wider flex items-center justify-between">
            <span>High Risk</span>
            <span className="w-2 h-2 rounded-full bg-orange-500" />
          </div>
          <div className="mt-2 flex items-baseline justify-between">
            <span className="text-2xl font-bold font-mono text-orange-300 tabular-nums">
              {highPatients.length}
            </span>
            <span className="text-xs text-orange-400/80 font-mono">50–74%</span>
          </div>
        </button>

        <button
          onClick={() => setFilterLevel(filterLevel === 'MODERATE' ? 'all' : 'MODERATE')}
          className={`text-left border rounded-lg p-3.5 flex flex-col justify-between transition-all ${
            filterLevel === 'MODERATE'
              ? 'bg-amber-950/40 border-amber-500/60 ring-1 ring-amber-500/50'
              : 'bg-slate-900/80 border-slate-800 hover:border-amber-900/50'
          }`}
        >
          <div className="text-[11px] font-semibold text-amber-400 uppercase tracking-wider flex items-center justify-between">
            <span>Moderate Risk</span>
            <span className="w-2 h-2 rounded-full bg-amber-500" />
          </div>
          <div className="mt-2 flex items-baseline justify-between">
            <span className="text-2xl font-bold font-mono text-amber-300 tabular-nums">
              {moderatePatients.length}
            </span>
            <span className="text-xs text-amber-400/80 font-mono">25–49%</span>
          </div>
        </button>

        <button
          onClick={() => setFilterLevel(filterLevel === 'LOW' ? 'all' : 'LOW')}
          className={`text-left border rounded-lg p-3.5 flex flex-col justify-between transition-all ${
            filterLevel === 'LOW'
              ? 'bg-emerald-950/40 border-emerald-500/60 ring-1 ring-emerald-500/50'
              : 'bg-slate-900/80 border-slate-800 hover:border-emerald-900/50'
          }`}
        >
          <div className="text-[11px] font-semibold text-emerald-400 uppercase tracking-wider flex items-center justify-between">
            <span>Low Risk</span>
            <span className="w-2 h-2 rounded-full bg-emerald-500" />
          </div>
          <div className="mt-2 flex items-baseline justify-between">
            <span className="text-2xl font-bold font-mono text-emerald-300 tabular-nums">
              {lowPatients.length}
            </span>
            <span className="text-xs text-emerald-400/80 font-mono">&lt;25%</span>
          </div>
        </button>

        <button
          onClick={() => setFilterLevel(filterLevel === 'worsening' ? 'all' : 'worsening')}
          className={`text-left border rounded-lg p-3.5 flex flex-col justify-between transition-all ${
            filterLevel === 'worsening'
              ? 'bg-rose-950/40 border-rose-500/60 ring-1 ring-rose-500/50'
              : 'bg-slate-900/80 border-slate-800 hover:border-rose-900/50'
          }`}
        >
          <div className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider flex items-center justify-between">
            <span>Worsening</span>
            <TrendingUp className="w-3.5 h-3.5 text-rose-400" />
          </div>
          <div className="mt-2 flex items-baseline justify-between">
            <span className="text-2xl font-bold font-mono text-rose-300 tabular-nums">
              {worseningPatients.length}
            </span>
            <span className="text-xs text-slate-500 font-mono">Velocity &gt;0</span>
          </div>
        </button>
      </div>

      {/* Active High-Priority Clinical Review Queue */}
      {activeAlerts.length > 0 && (
        <div className="bg-slate-900/90 border border-rose-500/30 rounded-lg p-4 space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <span className="w-2.5 h-2.5 rounded-full bg-rose-500 animate-ping" />
              <h2 className="text-sm font-bold text-white tracking-wide uppercase">
                Active Clinical Review Recommended ({activeAlerts.length})
              </h2>
            </div>
            <button
              onClick={() => setCurrentView('alerts')}
              className="text-xs text-cyan-400 hover:text-cyan-300 font-medium flex items-center gap-1"
            >
              Open Alerts Queue
              <ArrowRight className="w-3 h-3" />
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {activeAlerts.slice(0, 4).map((alt) => (
              <div
                key={alt.id}
                className="bg-slate-950/80 border border-slate-800 rounded p-3 flex flex-col justify-between gap-2 text-xs"
              >
                <div>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <span className="font-mono font-bold text-slate-200">{alt.bed}</span>
                      <span className="text-slate-500">·</span>
                      <span className="font-medium text-slate-300">{alt.patientName}</span>
                    </div>
                    <RiskBadge
                      score={alt.riskScore}
                      level={alt.severity.toUpperCase() as RiskLevel}
                      showTrend={false}
                      size="sm"
                    />
                  </div>
                  <p className="text-rose-300/90 mt-1.5 font-medium leading-snug">{alt.headline}</p>
                  <p className="text-slate-400 text-[11px] mt-0.5 line-clamp-1">{alt.primaryReason}</p>
                </div>

                <div className="flex items-center justify-between pt-2 border-t border-slate-800/80">
                  <span className="text-[10px] text-slate-500 font-mono">
                    {new Date(alt.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                  </span>
                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => handleInspectPatient(alt.patientId)}
                      className="px-2.5 py-1 text-[11px] rounded bg-slate-800 hover:bg-slate-700 text-slate-200"
                    >
                      Inspect Patient
                    </button>
                    <button
                      onClick={() => acknowledgeAlert(alt.id)}
                      className="px-2.5 py-1 text-[11px] rounded bg-rose-600/30 hover:bg-rose-600/50 text-rose-200 border border-rose-500/40"
                    >
                      Acknowledge
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* ICU Bed Overview Section */}
      <div className="space-y-3">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <h2 className="text-base font-bold text-white tracking-tight flex items-center gap-2">
              <Activity className="w-4 h-4 text-cyan-400" />
              ICU Bed Telemetry Grid
            </h2>
            <div className="text-xs text-slate-400">
              Real-time physiological telemetry, 0–100% estimated sepsis risk scores, and deterioration trajectories.
            </div>
          </div>

          {/* Search & Filter Bar */}
          <div className="flex items-center gap-2">
            <div className="relative">
              <Search className="w-3.5 h-3.5 absolute left-2.5 top-2.5 text-slate-500" />
              <input
                type="text"
                placeholder="Search bed, patient, diagnosis..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-8 pr-3 py-1.5 text-xs bg-slate-900 border border-slate-700 rounded-md text-slate-200 placeholder-slate-500 focus:outline-none focus:border-cyan-500 w-48 sm:w-64"
              />
            </div>

            <div className="flex items-center gap-1 p-0.5 bg-slate-900 rounded-md border border-slate-800 text-xs">
              <button
                onClick={() => setFilterLevel('all')}
                className={`px-2.5 py-1 rounded text-xs transition-colors ${
                  filterLevel === 'all' ? 'bg-slate-800 text-white font-medium' : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                All ({patients.length})
              </button>
              <button
                onClick={() => setFilterLevel('worsening')}
                className={`px-2.5 py-1 rounded text-xs transition-colors ${
                  filterLevel === 'worsening'
                    ? 'bg-rose-950/60 text-rose-300 font-medium'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                Worsening ({worseningPatients.length})
              </button>
            </div>
          </div>
        </div>

        {/* Patient Bed Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 2xl:grid-cols-4 gap-3.5">
          {filteredPatients.map((patient) => {
            const pred = patient.latestPrediction;
            const meas = patient.latestMeasurement;
            const riskScore = pred?.riskScore ?? 15;
            const riskLevel = pred?.riskLevel ?? 'LOW';
            const trend = pred?.trend ?? 'Stable';
            const quality = pred?.dataQuality;
            const topFactor = pred?.featureContributions?.[0];

            return (
              <div
                key={patient.id}
                onClick={() => handleInspectPatient(patient.id)}
                className="group bg-slate-900/70 hover:bg-slate-900 border border-slate-800 hover:border-slate-700 rounded-lg p-3.5 cursor-pointer transition-all duration-150 flex flex-col justify-between gap-3 relative"
              >
                {/* Header row: Bed ID | Patient ID | Risk Badge */}
                <div>
                  <div className="flex items-start justify-between gap-2">
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-mono text-sm font-bold text-white bg-slate-800 px-2 py-0.5 rounded border border-slate-700">
                          {patient.bed}
                        </span>
                        <span className="font-semibold text-slate-200 text-sm group-hover:text-cyan-300 transition-colors">
                          {patient.name}
                        </span>
                      </div>
                      <div className="text-[11px] text-slate-400 mt-1 truncate max-w-[200px]">
                        {patient.admissionDiagnosis}
                      </div>
                    </div>

                    <RiskBadge score={riskScore} level={riskLevel} trend={trend} size="sm" />
                  </div>

                  {/* Vitals Telemetry Mini Strip */}
                  {meas && (
                    <div className="grid grid-cols-4 gap-1.5 mt-3 pt-2.5 border-t border-slate-800/80 text-center font-mono">
                      <div className="bg-slate-950/60 p-1.5 rounded">
                        <div className="text-[10px] text-slate-500">HR</div>
                        <div
                          className={`text-xs font-semibold tabular-nums ${
                            meas.heartRate > 100 || meas.heartRate < 55 ? 'text-rose-400' : 'text-slate-200'
                          }`}
                        >
                          {meas.heartRate}
                        </div>
                      </div>

                      <div className="bg-slate-950/60 p-1.5 rounded">
                        <div className="text-[10px] text-slate-500">MAP</div>
                        <div
                          className={`text-xs font-semibold tabular-nums ${
                            meas.map < 65 ? 'text-rose-400 font-bold' : 'text-slate-200'
                          }`}
                        >
                          {meas.map}
                        </div>
                      </div>

                      <div className="bg-slate-950/60 p-1.5 rounded">
                        <div className="text-[10px] text-slate-500">RR</div>
                        <div
                          className={`text-xs font-semibold tabular-nums ${
                            meas.respiratoryRate > 22 ? 'text-amber-400' : 'text-slate-200'
                          }`}
                        >
                          {meas.respiratoryRate}
                        </div>
                      </div>

                      <div className="bg-slate-950/60 p-1.5 rounded">
                        <div className="text-[10px] text-slate-500">Lactate</div>
                        <div
                          className={`text-xs font-semibold tabular-nums ${
                            meas.lactate > 2.0 ? 'text-rose-400 font-bold' : 'text-slate-200'
                          }`}
                        >
                          {meas.lactate}
                        </div>
                      </div>
                    </div>
                  )}

                  {/* Top Contributing Feature / Explainability Teaser */}
                  {topFactor && (
                    <div className="mt-2.5 text-[11px] text-slate-400 bg-slate-950/40 p-2 rounded border border-slate-800/60">
                      <span className="text-slate-500">Primary Factor: </span>
                      <span className={topFactor.direction === 'risk_increasing' ? 'text-rose-300 font-medium' : 'text-emerald-300'}>
                        {topFactor.label} ({topFactor.currentValue} {topFactor.unit}): {topFactor.contributionPercent > 0 ? '+' : ''}{topFactor.contributionPercent}%
                      </span>
                    </div>
                  )}
                </div>

                {/* Footer: Quality & Trajectory */}
                <div className="pt-2 border-t border-slate-800/80 flex items-center justify-between text-[11px] text-slate-400">
                  <div className="flex items-center gap-1.5">
                    <span className="text-slate-500">Data Quality:</span>
                    <span
                      className={`font-medium ${
                        quality?.level === 'High'
                          ? 'text-emerald-400'
                          : quality?.level === 'Moderate'
                          ? 'text-amber-400'
                          : 'text-rose-400'
                      }`}
                    >
                      {quality?.level || 'High'} ({quality?.score ?? 95}%)
                    </span>
                  </div>

                  <span className="text-cyan-400 group-hover:translate-x-0.5 transition-transform flex items-center gap-1">
                    Details
                    <ArrowRight className="w-3 h-3" />
                  </span>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
