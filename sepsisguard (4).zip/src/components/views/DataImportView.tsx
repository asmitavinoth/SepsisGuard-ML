/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { SafetyBanner } from '../common/SafetyBanner';
import { parseIcuCsv, SAMPLE_ICU_CSV, CsvParseResult } from '../../services/csvService';
import {
  UploadCloud,
  FileCheck,
  AlertCircle,
  Download,
  Play,
  CheckCircle2,
  Table,
  ArrowRight,
} from 'lucide-react';

export const DataImportView: React.FC = () => {
  const { importPatients, setCurrentView, setSelectedPatientId } = useApp();
  const [csvContent, setCsvContent] = useState<string>('');
  const [parseResult, setParseResult] = useState<CsvParseResult | null>(null);
  const [isProcessing, setIsProcessing] = useState<boolean>(false);
  const [importSuccessMessage, setImportSuccessMessage] = useState<string | null>(null);

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const text = event.target?.result as string;
      setCsvContent(text);
      validateCsv(text);
    };
    reader.readAsText(file);
  };

  const handleLoadSample = () => {
    setCsvContent(SAMPLE_ICU_CSV);
    validateCsv(SAMPLE_ICU_CSV);
  };

  const validateCsv = (text: string) => {
    setIsProcessing(true);
    setTimeout(() => {
      const res = parseIcuCsv(text);
      setParseResult(res);
      setIsProcessing(false);
      setImportSuccessMessage(null);
    }, 150);
  };

  const handleExecuteImport = () => {
    if (!parseResult || parseResult.parsedPatients.length === 0) return;

    importPatients(parseResult.parsedPatients);
    setImportSuccessMessage(
      `Successfully ingested and calculated sepsis risk predictions for ${parseResult.parsedPatients.length} patient records.`
    );

    // If first imported patient exists, select it
    if (parseResult.parsedPatients[0]) {
      setSelectedPatientId(parseResult.parsedPatients[0].id);
    }
  };

  const handleDownloadTemplate = () => {
    const blob = new Blob([SAMPLE_ICU_CSV], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', 'sepsisguard_icu_template.csv');
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="space-y-6 font-sans">
      <SafetyBanner />

      {/* Header and Download Template */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-lg p-5 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-base font-bold text-white flex items-center gap-2">
            <UploadCloud className="w-5 h-5 text-cyan-400" />
            ICU Batch CSV Ingestion &amp; Validation Pipeline
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            Ingest structured ICU records with automatic range clamping, median imputation, and batch ML risk scoring.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleDownloadTemplate}
            className="px-3.5 py-2 rounded bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-medium flex items-center gap-1.5 border border-slate-700 transition-colors"
          >
            <Download className="w-3.5 h-3.5 text-slate-400" />
            Download Sample CSV
          </button>

          <button
            onClick={handleLoadSample}
            className="px-3.5 py-2 rounded bg-cyan-600/20 hover:bg-cyan-600/30 text-cyan-300 border border-cyan-500/40 text-xs font-medium flex items-center gap-1.5 transition-colors"
          >
            Load 5-Patient Test Dataset
          </button>
        </div>
      </div>

      {/* File Upload Box */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-slate-900/90 border border-slate-800 rounded-lg p-5 space-y-4">
          <h3 className="text-xs font-bold text-slate-300 uppercase tracking-wider">
            1. Select or Paste CSV Data
          </h3>

          <div className="border-2 border-dashed border-slate-700 hover:border-cyan-500 rounded-lg p-6 text-center transition-colors">
            <UploadCloud className="w-8 h-8 text-slate-500 mx-auto mb-2" />
            <div className="text-xs text-slate-300 font-medium">
              Click to select a CSV file from your device
            </div>
            <p className="text-[11px] text-slate-500 mt-1">
              Supports standard ICU column formats with vitals &amp; labs
            </p>
            <input
              type="file"
              accept=".csv,text/csv"
              onChange={handleFileUpload}
              className="mt-3 text-xs text-slate-400 file:mr-3 file:py-1.5 file:px-3 file:rounded file:border-0 file:text-xs file:font-semibold file:bg-cyan-500 file:text-slate-950 hover:file:bg-cyan-400 cursor-pointer"
            />
          </div>

          <div>
            <label className="text-xs text-slate-400 font-medium block mb-1">
              Or Paste CSV Text Directly:
            </label>
            <textarea
              rows={6}
              value={csvContent}
              onChange={(e) => {
                setCsvContent(e.target.value);
                validateCsv(e.target.value);
              }}
              placeholder="patient_id,timestamp,age,sex,heart_rate,sbp,dbp,map,respiratory_rate,temperature,spo2,wbc,lactate,platelets,creatinine,glucose"
              className="w-full bg-slate-950 border border-slate-800 rounded p-2.5 text-slate-200 font-mono text-[11px] placeholder-slate-600 focus:outline-none focus:border-cyan-500"
            />
          </div>
        </div>

        {/* Validation Report Box */}
        <div className="bg-slate-900/90 border border-slate-800 rounded-lg p-5 space-y-4 flex flex-col justify-between">
          <div>
            <h3 className="text-xs font-bold text-slate-300 uppercase tracking-wider">
              2. Pipeline Validation &amp; Quality Audit
            </h3>

            {!parseResult ? (
              <div className="p-8 text-center text-xs text-slate-500">
                Load or upload a CSV file to inspect validation results.
              </div>
            ) : (
              <div className="space-y-4 mt-3">
                <div className="grid grid-cols-4 gap-2 text-center font-mono">
                  <div className="bg-slate-950 p-2 rounded border border-slate-800">
                    <span className="text-[10px] text-slate-500 block">Total Rows</span>
                    <span className="text-base font-bold text-slate-200">{parseResult.totalRows}</span>
                  </div>

                  <div className="bg-slate-950 p-2 rounded border border-slate-800">
                    <span className="text-[10px] text-slate-500 block">Valid Rows</span>
                    <span className="text-base font-bold text-emerald-400">{parseResult.validRows}</span>
                  </div>

                  <div className="bg-slate-950 p-2 rounded border border-slate-800">
                    <span className="text-[10px] text-slate-500 block">Warnings</span>
                    <span className="text-base font-bold text-amber-400">{parseResult.warningRows}</span>
                  </div>

                  <div className="bg-slate-950 p-2 rounded border border-slate-800">
                    <span className="text-[10px] text-slate-500 block">Patients</span>
                    <span className="text-base font-bold text-cyan-400">
                      {parseResult.parsedPatients.length}
                    </span>
                  </div>
                </div>

                {parseResult.issues.length > 0 && (
                  <div className="max-h-48 overflow-y-auto space-y-1 p-2 bg-slate-950 rounded border border-slate-800 text-[11px] font-mono">
                    {parseResult.issues.map((issue, idx) => (
                      <div
                        key={idx}
                        className={`flex items-start gap-1.5 p-1 rounded ${
                          issue.type === 'error'
                            ? 'text-rose-400 bg-rose-950/20'
                            : 'text-amber-300 bg-amber-950/20'
                        }`}
                      >
                        <AlertCircle className="w-3.5 h-3.5 shrink-0 mt-0.5" />
                        <span>
                          Row {issue.row} [{issue.field}]: {issue.message}
                        </span>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )}
          </div>

          {/* Import Execution Button */}
          {parseResult && parseResult.parsedPatients.length > 0 && (
            <div className="pt-3 border-t border-slate-800 space-y-2">
              <button
                onClick={handleExecuteImport}
                className="w-full py-2.5 rounded bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold text-xs flex items-center justify-center gap-2 transition-colors shadow-lg shadow-cyan-950/50"
              >
                <Play className="w-3.5 h-3.5 fill-current" />
                Run ML Pipeline &amp; Ingest {parseResult.parsedPatients.length} Patients
              </button>

              {importSuccessMessage && (
                <div className="p-3 bg-emerald-950/40 border border-emerald-500/40 rounded text-xs text-emerald-300 flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                    <span>{importSuccessMessage}</span>
                  </div>
                  <button
                    onClick={() => setCurrentView('icu-monitor')}
                    className="underline hover:text-white font-semibold flex items-center gap-1"
                  >
                    View Monitor <ArrowRight className="w-3 h-3" />
                  </button>
                </div>
              )}
            </div>
          )}
        </div>
      </div>

      {/* Preview Table */}
      {parseResult && parseResult.rawPreview.length > 0 && (
        <div className="bg-slate-900/90 border border-slate-800 rounded-lg p-5 space-y-3">
          <h3 className="text-xs font-bold text-slate-300 uppercase tracking-wider flex items-center gap-2">
            <Table className="w-4 h-4 text-slate-400" />
            CSV Ingestion Data Preview (First 8 Rows)
          </h3>

          <div className="overflow-x-auto">
            <table className="w-full text-xs text-left font-mono">
              <thead className="bg-slate-950 text-slate-400 uppercase text-[10px] border-b border-slate-800">
                <tr>
                  <th className="p-2">Patient ID</th>
                  <th className="p-2">Age/Sex</th>
                  <th className="p-2">HR (bpm)</th>
                  <th className="p-2">BP (mmHg)</th>
                  <th className="p-2">MAP</th>
                  <th className="p-2">RR</th>
                  <th className="p-2">Temp</th>
                  <th className="p-2">SpO₂</th>
                  <th className="p-2">Lactate</th>
                  <th className="p-2">WBC</th>
                  <th className="p-2">Platelets</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800 text-slate-300">
                {parseResult.rawPreview.map((row, idx) => (
                  <tr key={idx} className="hover:bg-slate-800/40">
                    <td className="p-2 font-bold text-cyan-400">{row.patient_id}</td>
                    <td className="p-2">{row.age}y / {row.sex}</td>
                    <td className="p-2">{row.heart_rate}</td>
                    <td className="p-2">{row.sbp}/{row.dbp}</td>
                    <td className="p-2">{row.map || Math.round(((Number(row.sbp) + 2 * Number(row.dbp)) / 3) * 10) / 10}</td>
                    <td className="p-2">{row.respiratory_rate}</td>
                    <td className="p-2">{row.temperature}°C</td>
                    <td className="p-2">{row.spo2}%</td>
                    <td className="p-2 font-bold text-rose-400">{row.lactate}</td>
                    <td className="p-2">{row.wbc}</td>
                    <td className="p-2">{row.platelets}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
};
