/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { RiskBadge } from '../common/RiskBadge';
import { SafetyBanner } from '../common/SafetyBanner';
import {
  Bell,
  CheckCircle2,
  AlertTriangle,
  Clock,
  Search,
  Filter,
  Eye,
  MessageSquare,
  ShieldAlert,
} from 'lucide-react';
import { AlertSeverity, ClinicalAlert, RiskLevel } from '../../types/sepsis';

export const AlertsView: React.FC = () => {
  const { alerts, acknowledgeAlert, setSelectedPatientId, setCurrentView, currentUser } = useApp();
  const [filterStatus, setFilterStatus] = useState<'all' | 'active' | 'acknowledged'>('active');
  const [filterSeverity, setFilterSeverity] = useState<string>('all');
  const [search, setSearch] = useState('');

  // Acknowledge note modal state
  const [selectedAlertForAck, setSelectedAlertForAck] = useState<ClinicalAlert | null>(null);
  const [ackNote, setAckNote] = useState('');

  const filteredAlerts = alerts.filter((alt) => {
    if (filterStatus !== 'all' && alt.status !== filterStatus) return false;
    if (filterSeverity !== 'all' && alt.severity !== filterSeverity) return false;
    if (search) {
      const q = search.toLowerCase();
      return (
        alt.patientName.toLowerCase().includes(q) ||
        alt.bed.toLowerCase().includes(q) ||
        alt.patientId.toLowerCase().includes(q) ||
        alt.primaryReason.toLowerCase().includes(q)
      );
    }
    return true;
  });

  const handleOpenAcknowledge = (alert: ClinicalAlert) => {
    setSelectedAlertForAck(alert);
    setAckNote(
      currentUser.role === 'Doctor'
        ? 'Bedside clinical evaluation conducted. Fluid resuscitation and blood cultures in progress.'
        : 'Attending physician notified. Telemetry frequency increased to Q15M.'
    );
  };

  const handleConfirmAcknowledge = (e: React.FormEvent) => {
    e.preventDefault();
    if (selectedAlertForAck) {
      acknowledgeAlert(selectedAlertForAck.id, ackNote);
      setSelectedAlertForAck(null);
      setAckNote('');
    }
  };

  const handleInspect = (patientId: string) => {
    setSelectedPatientId(patientId);
    setCurrentView('patients');
  };

  return (
    <div className="space-y-6">
      <SafetyBanner />

      {/* Top Filter and Controls Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-slate-900/80 p-4 rounded-lg border border-slate-800">
        <div>
          <h2 className="text-sm font-bold text-white uppercase tracking-wider flex items-center gap-2">
            <Bell className="w-4 h-4 text-rose-400" />
            Clinical Early Warning Alerts Queue
          </h2>
          <p className="text-xs text-slate-400 mt-0.5">
            Multi-tier early warning notifications triggered by algorithm threshold breaches.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          {/* Search */}
          <div className="relative">
            <Search className="w-3.5 h-3.5 absolute left-2.5 top-2.5 text-slate-500" />
            <input
              type="text"
              placeholder="Search alerts..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="pl-8 pr-3 py-1 text-xs bg-slate-950 border border-slate-700 rounded text-slate-200 placeholder-slate-500 focus:outline-none focus:border-cyan-500 w-44"
            />
          </div>

          {/* Status Segmented Filter */}
          <div className="flex items-center gap-1 p-0.5 bg-slate-950 rounded border border-slate-800 text-xs">
            <button
              onClick={() => setFilterStatus('active')}
              className={`px-3 py-1 rounded transition-colors ${
                filterStatus === 'active'
                  ? 'bg-rose-950/70 text-rose-300 font-semibold border border-rose-800/60'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              Active ({alerts.filter((a) => a.status === 'active').length})
            </button>
            <button
              onClick={() => setFilterStatus('acknowledged')}
              className={`px-3 py-1 rounded transition-colors ${
                filterStatus === 'acknowledged'
                  ? 'bg-slate-800 text-white font-semibold'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              Acknowledged ({alerts.filter((a) => a.status === 'acknowledged').length})
            </button>
            <button
              onClick={() => setFilterStatus('all')}
              className={`px-3 py-1 rounded transition-colors ${
                filterStatus === 'all'
                  ? 'bg-slate-800 text-white font-semibold'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              All ({alerts.length})
            </button>
          </div>
        </div>
      </div>

      {/* Alerts List */}
      <div className="space-y-3">
        {filteredAlerts.length === 0 ? (
          <div className="bg-slate-900/60 border border-slate-800 rounded-lg p-12 text-center">
            <CheckCircle2 className="w-10 h-10 text-emerald-400 mx-auto mb-2 opacity-80" />
            <h3 className="text-sm font-semibold text-slate-200">No Alerts Matching Filter</h3>
            <p className="text-xs text-slate-500 mt-1">
              All active clinical review triggers for this view have been acknowledged or resolved.
            </p>
          </div>
        ) : (
          filteredAlerts.map((alt) => {
            const isCritical = alt.severity === 'critical';
            const isHigh = alt.severity === 'high';
            const isModerate = alt.severity === 'moderate';

            const severityBorder = isCritical
              ? 'border-rose-500/50 bg-rose-950/15'
              : isHigh
              ? 'border-orange-500/40 bg-orange-950/15'
              : isModerate
              ? 'border-amber-500/30 bg-amber-950/10'
              : 'border-slate-800 bg-slate-900/60';

            return (
              <div
                key={alt.id}
                className={`p-4 rounded-lg border transition-colors flex flex-col md:flex-row md:items-start justify-between gap-4 ${severityBorder}`}
              >
                <div className="space-y-2 flex-1">
                  {/* Top line: Bed | Name | Risk | Timestamp */}
                  <div className="flex flex-wrap items-center gap-2.5">
                    <span className="font-mono text-xs font-bold text-white bg-slate-800 px-2 py-0.5 rounded border border-slate-700">
                      {alt.bed}
                    </span>
                    <span className="font-bold text-slate-200 text-sm">{alt.patientName}</span>
                    <span className="text-slate-500 text-xs">({alt.patientId})</span>
                    <span className="text-slate-700">·</span>
                    <RiskBadge
                      score={alt.riskScore}
                      level={alt.severity.toUpperCase() as RiskLevel}
                      showTrend={false}
                      size="sm"
                    />

                    <span className="text-xs text-slate-400 font-mono ml-auto">
                      <Clock className="w-3 h-3 inline mr-1 text-slate-500" />
                      {new Date(alt.timestamp).toLocaleString()}
                    </span>
                  </div>

                  {/* Headline & Clinical reason */}
                  <div>
                    <h3
                      className={`text-sm font-bold ${
                        isCritical ? 'text-rose-300' : isHigh ? 'text-orange-300' : 'text-amber-300'
                      }`}
                    >
                      {alt.headline}
                    </h3>
                    <p className="text-xs text-slate-300 mt-1 leading-relaxed">{alt.primaryReason}</p>
                  </div>

                  {/* Contributing features list */}
                  {alt.contributingFactors && alt.contributingFactors.length > 0 && (
                    <div className="flex flex-wrap items-center gap-2 pt-1">
                      <span className="text-[11px] font-semibold text-slate-500">Key Contributors:</span>
                      {alt.contributingFactors.map((factor, idx) => (
                        <span
                          key={idx}
                          className="text-[11px] font-mono px-2 py-0.5 rounded bg-slate-900 border border-slate-800 text-slate-300"
                        >
                          {factor}
                        </span>
                      ))}
                    </div>
                  )}

                  {/* Acknowledgment details if present */}
                  {alt.status === 'acknowledged' && (
                    <div className="mt-2 p-2.5 bg-slate-950/80 rounded border border-slate-800/80 text-xs text-slate-400 space-y-1">
                      <div className="flex items-center gap-1.5 text-emerald-400 font-medium">
                        <CheckCircle2 className="w-3.5 h-3.5" />
                        <span>Acknowledged by {alt.acknowledgedBy}</span>
                        <span className="text-slate-500 font-mono">
                          at {new Date(alt.acknowledgedAt!).toLocaleTimeString()}
                        </span>
                      </div>
                      {alt.clinicalNote && (
                        <p className="text-slate-300 italic pl-5">“{alt.clinicalNote}”</p>
                      )}
                    </div>
                  )}
                </div>

                {/* Actions: Acknowledge or Inspect Dossier */}
                <div className="flex items-center gap-2 shrink-0 self-end md:self-start">
                  <button
                    onClick={() => handleInspect(alt.patientId)}
                    className="px-3 py-1.5 rounded bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-medium flex items-center gap-1.5 border border-slate-700 transition-colors"
                  >
                    <Eye className="w-3.5 h-3.5 text-cyan-400" />
                    Inspect Patient
                  </button>

                  {alt.status === 'active' && (
                    <button
                      onClick={() => handleOpenAcknowledge(alt)}
                      className="px-3.5 py-1.5 rounded bg-rose-600/30 hover:bg-rose-600/50 text-rose-200 border border-rose-500/50 text-xs font-semibold flex items-center gap-1.5 transition-colors"
                    >
                      <CheckCircle2 className="w-3.5 h-3.5 text-rose-400" />
                      Acknowledge Alert
                    </button>
                  )}
                </div>
              </div>
            );
          })
        )}
      </div>

      {/* Acknowledge Alert Modal */}
      {selectedAlertForAck && (
        <div className="fixed inset-0 bg-black/75 backdrop-blur-xs z-50 flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-700 rounded-xl max-w-lg w-full p-5 space-y-4 shadow-2xl">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div className="flex items-center gap-2">
                <AlertTriangle className="w-4 h-4 text-amber-400" />
                <h3 className="text-sm font-bold text-white">Acknowledge Clinical Alert</h3>
              </div>
              <button
                onClick={() => setSelectedAlertForAck(null)}
                className="text-slate-400 hover:text-white text-lg font-bold"
              >
                &times;
              </button>
            </div>

            <div className="text-xs space-y-2">
              <div className="p-3 bg-slate-950 rounded border border-slate-800">
                <div className="flex items-center justify-between font-bold text-slate-200">
                  <span>{selectedAlertForAck.bed} — {selectedAlertForAck.patientName}</span>
                  <span className="font-mono text-rose-400">{selectedAlertForAck.riskScore}% Risk</span>
                </div>
                <p className="text-slate-400 mt-1">{selectedAlertForAck.headline}</p>
              </div>

              <form onSubmit={handleConfirmAcknowledge} className="space-y-3 pt-2">
                <div>
                  <label className="text-slate-300 font-medium block mb-1">
                    Clinical Action Note &amp; Reviewer Attestation:
                  </label>
                  <textarea
                    rows={3}
                    value={ackNote}
                    onChange={(e) => setAckNote(e.target.value)}
                    required
                    placeholder="Enter clinical review notes, verification of vitals, or bedside response..."
                    className="w-full bg-slate-950 border border-slate-700 rounded p-2.5 text-slate-100 placeholder-slate-500 focus:outline-none focus:border-cyan-500 text-xs"
                  />
                </div>

                <div className="p-2.5 bg-slate-950/60 rounded border border-slate-800 text-[11px] text-slate-400 flex items-center gap-2">
                  <ShieldAlert className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                  <span>
                    Logging as <strong>{currentUser.name} ({currentUser.role})</strong> into the clinical audit trail.
                  </span>
                </div>

                <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-800">
                  <button
                    type="button"
                    onClick={() => setSelectedAlertForAck(null)}
                    className="px-3.5 py-1.5 text-xs rounded bg-slate-800 text-slate-300 hover:bg-slate-700"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="px-4 py-1.5 text-xs font-semibold rounded bg-rose-600 hover:bg-rose-500 text-white"
                  >
                    Sign &amp; Acknowledge Alert
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
