/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useRef } from 'react';
import { useApp } from '../../context/AppContext';
import { RiskBadge } from '../common/RiskBadge';
import {
  FileText,
  Printer,
  Download,
  AlertTriangle,
  CheckCircle2,
  Calendar,
  Building,
  ShieldAlert,
} from 'lucide-react';
import { RiskLevel } from '../../types/sepsis';

export const ReportsView: React.FC = () => {
  const { patients, selectedPatientId, setSelectedPatientId, currentUser, alerts, activeModel, clinicalNotes } = useApp();
  const reportRef = useRef<HTMLDivElement>(null);

  const selectedPatient =
    patients.find((p) => p.id === selectedPatientId) || patients[0] || null;

  if (!selectedPatient) {
    return <div className="p-8 text-center text-xs text-slate-500">No patient selected for report generation.</div>;
  }

  const pred = selectedPatient.latestPrediction;
  const m = selectedPatient.latestMeasurement || selectedPatient.history[selectedPatient.history.length - 1];
  const patientAlerts = alerts.filter((a) => a.patientId === selectedPatient.id);
  const patientNotes = clinicalNotes.filter((n) => n.patientId === selectedPatient.id);

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="space-y-6 font-sans">
      {/* Top Patient Selector & Action Bar (Hidden during print) */}
      <div className="print:hidden bg-slate-900/90 border border-slate-800 rounded-lg p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <FileText className="w-5 h-5 text-cyan-400 shrink-0" />
          <div>
            <h2 className="text-sm font-bold text-white uppercase tracking-wider">
              Clinical Sepsis Early Warning Report Generator
            </h2>
            <p className="text-xs text-slate-400">
              Generate standardized, auditable decision-support summaries for patient chart reviews.
            </p>
          </div>
        </div>

        <div className="flex items-center gap-3">
          {/* Patient Selector */}
          <select
            value={selectedPatient.id}
            onChange={(e) => setSelectedPatientId(e.target.value)}
            className="text-xs bg-slate-950 border border-slate-700 rounded px-3 py-1.5 text-slate-200 focus:outline-none"
          >
            {patients.map((p) => (
              <option key={p.id} value={p.id}>
                {p.bed} — {p.name} ({p.latestPrediction?.riskScore ?? 0}%)
              </option>
            ))}
          </select>

          {/* Print / Save as PDF Button */}
          <button
            onClick={handlePrint}
            className="px-4 py-2 rounded bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold text-xs flex items-center gap-1.5 transition-colors shadow-sm"
          >
            <Printer className="w-4 h-4" />
            Print / Export PDF
          </button>
        </div>
      </div>

      {/* Printable Clinical Report Document Container */}
      <div
        ref={reportRef}
        className="bg-white text-slate-900 p-8 sm:p-12 rounded-xl shadow-xl max-w-4xl mx-auto space-y-6 print:shadow-none print:p-0 print:m-0 print:max-w-none print:w-full"
      >
        {/* Hospital & Report Header */}
        <div className="flex items-start justify-between border-b-2 border-slate-900 pb-4">
          <div>
            <div className="flex items-center gap-2 text-slate-900">
              <Building className="w-5 h-5 text-cyan-700" />
              <span className="font-extrabold text-lg tracking-tight uppercase">
                Metropolitan Intensive Care Unit
              </span>
            </div>
            <div className="text-xs text-slate-600 mt-0.5">
              Division of Critical Care Medicine · Clinical AI Decision Support Service
            </div>
          </div>

          <div className="text-right text-xs font-mono text-slate-600">
            <div className="font-bold text-slate-900">SEPSIS EARLY WARNING SUMMARY</div>
            <div>Report Generated: {new Date().toLocaleString()}</div>
            <div>Attending: {currentUser.name}</div>
          </div>
        </div>

        {/* Mandatory Research Prototype Warning in Document */}
        <div className="p-3 bg-amber-50 border border-amber-300 rounded text-xs text-amber-900 flex items-start gap-2">
          <AlertTriangle className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
          <div>
            <strong>INVESTIGATIONAL / EDUCATIONAL DECISION-SUPPORT PROTOTYPE ONLY:</strong> SepsisGuard estimates sepsis risk percentages from synthetic and observational physiological streams. Predictions do not confirm sepsis, do not replace clinician bedside assessment, and must never dictate therapy without independent clinical evaluation.
          </div>
        </div>

        {/* Patient Demographics Matrix */}
        <div className="bg-slate-50 p-4 rounded border border-slate-200 grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
          <div>
            <span className="text-slate-500 block text-[10px] uppercase font-semibold">Patient Name</span>
            <span className="font-bold text-slate-900 text-sm">{selectedPatient.name}</span>
          </div>

          <div>
            <span className="text-slate-500 block text-[10px] uppercase font-semibold">ICU Bed &amp; MRN</span>
            <span className="font-bold font-mono text-slate-900">{selectedPatient.bed} · {selectedPatient.mrn}</span>
          </div>

          <div>
            <span className="text-slate-500 block text-[10px] uppercase font-semibold">Age / Sex / Weight</span>
            <span className="font-bold text-slate-900">
              {selectedPatient.age} yo / {selectedPatient.sex} / {selectedPatient.weightKg} kg
            </span>
          </div>

          <div>
            <span className="text-slate-500 block text-[10px] uppercase font-semibold">Admission Diagnosis</span>
            <span className="font-bold text-slate-900 truncate block">
              {selectedPatient.admissionDiagnosis}
            </span>
          </div>
        </div>

        {/* Executive Risk Assessment Strip */}
        {pred && (
          <div className="border border-slate-300 rounded p-4 space-y-3 bg-white">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-200 pb-3">
              <div>
                <span className="text-[10px] font-bold uppercase tracking-wider text-slate-500">
                  Model Estimated Sepsis Risk Score
                </span>
                <div className="flex items-baseline gap-2 mt-0.5">
                  <span className="text-3xl font-extrabold font-mono text-slate-900">
                    {pred.riskScore.toFixed(1)}%
                  </span>
                  <span className="text-xs font-semibold px-2 py-0.5 rounded uppercase border border-slate-300">
                    {pred.riskLevel} Risk Category
                  </span>
                  <span className="text-xs text-slate-600 font-medium">
                    (Trajectory: {pred.trend})
                  </span>
                </div>
              </div>

              <div className="text-right text-xs font-mono text-slate-600">
                <div>Model: {pred.modelUsed} ({pred.modelVersion})</div>
                <div>Data Quality: {pred.dataQuality.level} ({pred.dataQuality.score}%)</div>
                <div>6h Horizon Projection: <strong>{pred.projectedRisk6h.toFixed(1)}%</strong></div>
              </div>
            </div>

            <p className="text-xs text-slate-700 leading-relaxed">
              <strong>Clinical Assessment Summary:</strong> Telemetry pattern indicates an estimated sepsis risk of {pred.riskScore.toFixed(1)}% with an estimated {pred.trend.toLowerCase()} trend. Baseline ICU population risk is {pred.baseExpectedRisk}%. {pred.alertTriggered ? 'Threshold criteria breached: early clinical review recommended.' : 'Current physiological telemetry remains within nominal parameters.'}
            </p>
          </div>
        )}

        {/* Explainability / SHAP Factor Attributions */}
        {pred?.featureContributions && (
          <div className="space-y-2">
            <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wider border-b border-slate-200 pb-1">
              Primary Feature Contributions to Estimated Risk (SHAP Decomposition)
            </h3>
            <div className="overflow-x-auto">
              <table className="w-full text-xs text-left">
                <thead className="bg-slate-100 text-slate-600 text-[10px] uppercase font-semibold">
                  <tr>
                    <th className="p-2">Physiological Factor</th>
                    <th className="p-2">Current Value</th>
                    <th className="p-2">Normal Target</th>
                    <th className="p-2">Risk Contribution</th>
                    <th className="p-2">Clinical Interpretation</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-200 text-slate-800">
                  {pred.featureContributions.slice(0, 6).map((fc, i) => (
                    <tr key={i}>
                      <td className="p-2 font-medium">{fc.label}</td>
                      <td className="p-2 font-mono font-bold">
                        {fc.currentValue} {fc.unit}
                      </td>
                      <td className="p-2 text-slate-500 font-mono">
                        {fc.normalRange} {fc.unit}
                      </td>
                      <td className="p-2 font-mono font-bold">
                        <span className={fc.direction === 'risk_increasing' ? 'text-rose-700' : 'text-emerald-700'}>
                          {fc.contributionPercent > 0 ? '+' : ''}{fc.contributionPercent.toFixed(1)}%
                        </span>
                      </td>
                      <td className="p-2 text-[11px] text-slate-600">
                        {fc.clinicalInterpretation}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* Latest Physiological Snapshot */}
        {m && (
          <div className="space-y-2">
            <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wider border-b border-slate-200 pb-1">
              Physiological Telemetry &amp; Biomarkers at Timestamp {new Date(m.timestamp).toLocaleTimeString()}
            </h3>
            <div className="grid grid-cols-4 sm:grid-cols-6 gap-2 text-xs font-mono text-center">
              <div className="p-2 bg-slate-50 rounded border border-slate-200">
                <span className="text-[10px] text-slate-500 block">HR (bpm)</span>
                <span className="font-bold text-slate-900">{m.heartRate}</span>
              </div>
              <div className="p-2 bg-slate-50 rounded border border-slate-200">
                <span className="text-[10px] text-slate-500 block">BP / MAP</span>
                <span className="font-bold text-slate-900">{m.sbp}/{m.dbp} ({m.map})</span>
              </div>
              <div className="p-2 bg-slate-50 rounded border border-slate-200">
                <span className="text-[10px] text-slate-500 block">RR (bpm)</span>
                <span className="font-bold text-slate-900">{m.respiratoryRate}</span>
              </div>
              <div className="p-2 bg-slate-50 rounded border border-slate-200">
                <span className="text-[10px] text-slate-500 block">Temp (°C)</span>
                <span className="font-bold text-slate-900">{m.temperature}°C</span>
              </div>
              <div className="p-2 bg-slate-50 rounded border border-slate-200">
                <span className="text-[10px] text-slate-500 block">SpO₂ (%)</span>
                <span className="font-bold text-slate-900">{m.spo2}%</span>
              </div>
              <div className="p-2 bg-slate-50 rounded border border-slate-200">
                <span className="text-[10px] text-slate-500 block">Lactate (mmol/L)</span>
                <span className="font-bold text-rose-700">{m.lactate}</span>
              </div>
            </div>
          </div>
        )}

        {/* Documented Clinical Notes Section */}
        {patientNotes.length > 0 && (
          <div className="space-y-2">
            <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wider border-b border-slate-200 pb-1">
              Documented Clinical Notes &amp; Observation Attestations ({patientNotes.length})
            </h3>
            <div className="space-y-2">
              {patientNotes.map((note) => (
                <div key={note.id} className="p-3 bg-slate-50 border border-slate-200 rounded text-xs space-y-1">
                  <div className="flex items-center justify-between text-[11px]">
                    <div className="flex items-center gap-2">
                      <span className="font-bold text-slate-900">{note.title}</span>
                      <span className="text-slate-500">[{note.category}]</span>
                    </div>
                    <span className="font-mono text-slate-600">
                      Linked Risk: <strong>{note.linkedRiskScore}% ({note.linkedRiskLevel})</strong>
                    </span>
                  </div>
                  <p className="text-slate-800 leading-relaxed text-xs">{note.content}</p>
                  <div className="text-[10px] text-slate-500 font-mono pt-1 border-t border-slate-200 flex items-center justify-between">
                    <span>
                      Author: {note.authorName} ({note.authorTitle}) · {new Date(note.timestamp).toLocaleString()}
                    </span>
                    <span>Epoch: {new Date(note.linkedObservationTime).toLocaleTimeString()}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Clinical Sign-Off Box */}
        <div className="pt-6 border-t-2 border-slate-200 flex flex-col sm:flex-row sm:items-end justify-between gap-6 text-xs text-slate-700">
          <div className="space-y-1">
            <div>
              <strong>Reviewing Clinician:</strong> {currentUser.name}
            </div>
            <div>
              <strong>Credentials &amp; Role:</strong> {currentUser.department}
            </div>
            <div className="text-[11px] text-slate-500">
              Audit ID: {`AUD-REP-${Date.now().toString(36).toUpperCase()}`}
            </div>
          </div>

          <div className="w-56 border-t border-slate-400 pt-1 text-center text-[11px] text-slate-500">
            Attending Intensivist Signature / Date
          </div>
        </div>
      </div>
    </div>
  );
};
