/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { useApp } from '../../context/AppContext';
import { SafetyBanner } from '../common/SafetyBanner';
import { RiskBadge } from '../common/RiskBadge';
import { VitalMultiChart } from '../common/VitalMultiChart';
import { ShapWaterfall } from '../common/ShapWaterfall';
import {
  SIMULATION_SCENARIOS,
  SimulationScenarioId,
} from '../../services/simulationService';
import {
  Play,
  Pause,
  RotateCcw,
  StepForward,
  FastForward,
  Activity,
  AlertTriangle,
  Zap,
  TrendingUp,
  Eye,
} from 'lucide-react';
import { RiskLevel } from '../../types/sepsis';

export const SimulationView: React.FC = () => {
  const {
    patients,
    simulationScenario,
    setSimulationScenario,
    isSimulating,
    simulationSpeed,
    setSimulationSpeed,
    toggleSimulation,
    stepSimulationForward,
    resetSimulation,
    setSelectedPatientId,
    setCurrentView,
  } = useApp();

  const activeScenarioConfig =
    SIMULATION_SCENARIOS.find((s) => s.id === simulationScenario) ||
    SIMULATION_SCENARIOS[0];

  const targetPatient =
    patients.find((p) => p.id === activeScenarioConfig.patientId) || patients[0];

  const pred = targetPatient?.latestPrediction;
  const m = targetPatient?.latestMeasurement || targetPatient?.history[targetPatient?.history.length - 1];

  const handleScenarioChange = (id: SimulationScenarioId) => {
    setSimulationScenario(id);
    const targetConfig = SIMULATION_SCENARIOS.find((s) => s.id === id);
    if (targetConfig) {
      setSelectedPatientId(targetConfig.patientId);
    }
  };

  return (
    <div className="space-y-6 font-sans">
      {/* Prominent Synthetic Data Notice */}
      <div className="bg-cyan-950/40 border border-cyan-500/40 rounded-lg p-3.5 flex items-center justify-between text-xs text-cyan-200">
        <div className="flex items-center gap-2">
          <Zap className="w-4 h-4 text-cyan-400 shrink-0" />
          <span>
            <strong>SYNTHETIC DATA — NOT REAL PATIENT DATA.</strong> Simulation mode executes continuous physiological state transitions, calculating real-time ML risk trajectories and alert triggers.
          </span>
        </div>
        <span className="font-mono text-[11px] bg-cyan-900/60 px-2 py-0.5 rounded border border-cyan-700">
          INVESTIGATIONAL DEMO
        </span>
      </div>

      {/* Scenario Selector & Controls Bar */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-lg p-5 space-y-4">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <h2 className="text-base font-bold text-white flex items-center gap-2">
              <Activity className="w-4 h-4 text-cyan-400" />
              ICU Clinical Scenario Simulation Engine
            </h2>
            <p className="text-xs text-slate-400 mt-0.5">
              Select one of four synthetic clinical trajectories to test early warning detection.
            </p>
          </div>

          {/* Interactive Playback Controls */}
          <div className="flex items-center gap-2 bg-slate-950 p-1.5 rounded-lg border border-slate-800">
            <button
              onClick={toggleSimulation}
              className={`px-3 py-1.5 rounded font-semibold text-xs flex items-center gap-1.5 transition-colors ${
                isSimulating
                  ? 'bg-amber-500 text-slate-950 hover:bg-amber-400'
                  : 'bg-cyan-500 text-slate-950 hover:bg-cyan-400'
              }`}
            >
              {isSimulating ? (
                <>
                  <Pause className="w-3.5 h-3.5" />
                  <span>Pause</span>
                </>
              ) : (
                <>
                  <Play className="w-3.5 h-3.5" />
                  <span>Play Simulation</span>
                </>
              )}
            </button>

            <button
              onClick={stepSimulationForward}
              disabled={isSimulating}
              className="p-1.5 text-slate-300 hover:text-white rounded hover:bg-slate-800 disabled:opacity-40 transition-colors"
              title="Advance 1 Hour"
            >
              <StepForward className="w-4 h-4" />
            </button>

            <button
              onClick={resetSimulation}
              className="p-1.5 text-slate-300 hover:text-rose-400 rounded hover:bg-slate-800 transition-colors"
              title="Reset Scenario"
            >
              <RotateCcw className="w-4 h-4" />
            </button>

            {/* Speed Selector */}
            <div className="flex items-center gap-1 pl-2 border-l border-slate-800 text-[11px] font-mono">
              <span className="text-slate-500">Speed:</span>
              {[1, 2, 5].map((spd) => (
                <button
                  key={spd}
                  onClick={() => setSimulationSpeed(spd)}
                  className={`px-1.5 py-0.5 rounded transition-colors ${
                    simulationSpeed === spd
                      ? 'bg-slate-800 text-cyan-400 font-bold border border-slate-700'
                      : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  {spd}x
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* 4 Clinical Scenarios Tabs */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-2.5 pt-2">
          {SIMULATION_SCENARIOS.map((sc) => {
            const isSelected = sc.id === simulationScenario;
            return (
              <button
                key={sc.id}
                onClick={() => handleScenarioChange(sc.id)}
                className={`text-left p-3 rounded-lg border transition-all ${
                  isSelected
                    ? 'bg-cyan-950/40 border-cyan-500 ring-1 ring-cyan-500/50'
                    : 'bg-slate-950/60 border-slate-800 hover:border-slate-700'
                }`}
              >
                <div className="flex items-center justify-between text-xs font-semibold">
                  <span className={isSelected ? 'text-cyan-300 font-bold' : 'text-slate-200'}>
                    {sc.name.split(':')[0]}
                  </span>
                  <span className="font-mono text-[10px] text-slate-500 bg-slate-900 px-1.5 py-0.2 rounded border border-slate-800">
                    {sc.bed}
                  </span>
                </div>
                <div className="text-[11px] text-slate-300 mt-1 font-medium truncate">
                  {sc.name.split(':')[1]}
                </div>
                <p className="text-[11px] text-slate-500 mt-1 line-clamp-2 leading-snug">
                  {sc.description}
                </p>
              </button>
            );
          })}
        </div>
      </div>

      {/* Target Patient Live Simulation Display */}
      {targetPatient && (
        <div className="bg-slate-900/90 border border-slate-800 rounded-lg p-5 space-y-5">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-800 pb-4">
            <div>
              <div className="flex items-center gap-2">
                <span className="font-mono text-xs font-bold text-white bg-slate-800 px-2 py-0.5 rounded border border-slate-700">
                  {targetPatient.bed}
                </span>
                <h3 className="text-lg font-bold text-white">{targetPatient.name}</h3>
                <span className="text-xs text-slate-400">
                  ({targetPatient.age} yo {targetPatient.sex})
                </span>
              </div>
              <p className="text-xs text-slate-400 mt-1">
                {activeScenarioConfig.description}
              </p>
            </div>

            <div className="flex items-center gap-3">
              <RiskBadge
                score={pred?.riskScore}
                level={pred?.riskLevel ?? 'LOW'}
                trend={pred?.trend}
                size="lg"
              />

              <button
                onClick={() => {
                  setSelectedPatientId(targetPatient.id);
                  setCurrentView('patients');
                }}
                className="px-3 py-1.5 rounded bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-medium flex items-center gap-1.5 border border-slate-700 transition-colors"
              >
                <Eye className="w-3.5 h-3.5 text-cyan-400" />
                Open Patient Dossier
              </button>
            </div>
          </div>

          {/* Real-Time Live Telemetry Metrics Strip */}
          {m && (
            <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-6 gap-2.5 font-mono text-xs">
              <div className="bg-slate-950 p-2.5 rounded border border-slate-800">
                <span className="text-slate-500 text-[10px] block">Heart Rate</span>
                <span className={`text-base font-bold ${m.heartRate > 100 ? 'text-rose-400' : 'text-slate-100'}`}>
                  {m.heartRate} bpm
                </span>
              </div>

              <div className="bg-slate-950 p-2.5 rounded border border-slate-800">
                <span className="text-slate-500 text-[10px] block">Blood Pressure / MAP</span>
                <span className={`text-base font-bold ${m.map < 65 ? 'text-rose-400' : 'text-slate-100'}`}>
                  {m.sbp}/{m.dbp} ({m.map})
                </span>
              </div>

              <div className="bg-slate-950 p-2.5 rounded border border-slate-800">
                <span className="text-slate-500 text-[10px] block">Resp Rate &amp; SpO₂</span>
                <span className={`text-base font-bold ${m.respiratoryRate > 22 ? 'text-amber-400' : 'text-slate-100'}`}>
                  {m.respiratoryRate} /min · {m.spo2}%
                </span>
              </div>

              <div className="bg-slate-950 p-2.5 rounded border border-slate-800">
                <span className="text-slate-500 text-[10px] block">Serum Lactate</span>
                <span className={`text-base font-bold ${m.lactate > 2.0 ? 'text-rose-400' : 'text-slate-100'}`}>
                  {m.lactate} mmol/L
                </span>
              </div>

              <div className="bg-slate-950 p-2.5 rounded border border-slate-800">
                <span className="text-slate-500 text-[10px] block">White Blood Cells</span>
                <span className="text-base font-bold text-slate-100">
                  {m.wbc} ×10⁹/L
                </span>
              </div>

              <div className="bg-slate-950 p-2.5 rounded border border-slate-800">
                <span className="text-slate-500 text-[10px] block">Shock Index</span>
                <span className={`text-base font-bold ${(m.shockIndex || 0) > 0.85 ? 'text-rose-400' : 'text-slate-100'}`}>
                  {(m.shockIndex || 0).toFixed(2)}
                </span>
              </div>
            </div>
          )}

          {/* Time Series Telemetry Plot */}
          <div className="space-y-2">
            <h4 className="text-xs font-bold text-slate-300 uppercase tracking-wider">
              Simulated Telemetry Evolution ({targetPatient.history.length} Cumulative Hours)
            </h4>
            <VitalMultiChart history={targetPatient.history} height={240} />
          </div>

          {/* Real-time SHAP decomposition for the simulated state */}
          {pred && (
            <div className="pt-2 border-t border-slate-800">
              <h4 className="text-xs font-bold text-slate-300 uppercase tracking-wider mb-2">
                Live Feature Contribution Attribution (SHAP Decomposition)
              </h4>
              <ShapWaterfall
                baseRisk={pred.baseExpectedRisk}
                finalRisk={pred.riskScore}
                features={pred.featureContributions}
                compact
              />
            </div>
          )}
        </div>
      )}
    </div>
  );
};
