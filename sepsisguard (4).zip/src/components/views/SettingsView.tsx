/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { SafetyBanner } from '../common/SafetyBanner';
import {
  Sliders,
  RotateCcw,
  CheckCircle2,
  AlertTriangle,
  Cpu,
  Clock,
  ShieldCheck,
} from 'lucide-react';
import { MLModelType } from '../../types/sepsis';

export const SettingsView: React.FC = () => {
  const {
    thresholds,
    setThresholds,
    activeModel,
    setActiveModel,
    temperatureUnit,
    setTemperatureUnit,
    staleHoursLimit,
    setStaleHoursLimit,
    resetEntireDemo,
    currentUser,
    addAuditLog,
  } = useApp();

  const [lowMax, setLowMax] = useState(thresholds.lowMax);
  const [modMax, setModMax] = useState(thresholds.moderateMax);
  const [highMax, setHighMax] = useState(thresholds.highMax);
  const [savedSuccess, setSavedSuccess] = useState(false);

  const handleSaveThresholds = (e: React.FormEvent) => {
    e.preventDefault();
    if (lowMax >= modMax || modMax >= highMax) {
      alert('Thresholds must be strictly ascending: Low < Moderate < High < 100%');
      return;
    }

    setThresholds({
      lowMax,
      moderateMax: modMax,
      highMax,
    });

    addAuditLog(
      'Risk Thresholds Modified',
      'SETTINGS',
      `Configured prototype thresholds: Low <${lowMax}%, Moderate <${modMax}%, High <${highMax}%, Critical ≥${highMax}%.`
    );

    setSavedSuccess(true);
    setTimeout(() => setSavedSuccess(false), 2500);
  };

  const handleModelChange = (model: MLModelType) => {
    setActiveModel(model);
    addAuditLog('Active ML Model Changed', 'SETTINGS', `Changed active inference model to ${model}.`);
  };

  return (
    <div className="space-y-6 font-sans">
      <SafetyBanner />

      <div className="bg-slate-900/90 border border-slate-800 rounded-lg p-5">
        <h2 className="text-base font-bold text-white flex items-center gap-2">
          <Sliders className="w-5 h-5 text-cyan-400" />
          System Configuration &amp; Investigational Thresholds
        </h2>
        <p className="text-xs text-slate-400 mt-1">
          Adjust risk cutoffs, telemetry stale limits, active machine learning model, and display preferences.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Prototype Risk Thresholds Config */}
        <div className="bg-slate-900/90 border border-slate-800 rounded-lg p-5 space-y-4">
          <div>
            <h3 className="text-xs font-bold text-slate-300 uppercase tracking-wider">
              Prototype Risk Level Thresholds (0–100%)
            </h3>
            <p className="text-xs text-slate-500 mt-0.5">
              Configurable cutoffs for research and prototype clinical validation.
            </p>
          </div>

          <form onSubmit={handleSaveThresholds} className="space-y-4">
            <div className="space-y-3 font-mono text-xs">
              <div className="p-3 bg-slate-950 rounded border border-slate-800 flex items-center justify-between">
                <div>
                  <span className="text-emerald-400 font-bold block">LOW RISK UPPER LIMIT</span>
                  <span className="text-[11px] text-slate-500 font-sans">Nominal telemetry; baseline monitoring</span>
                </div>
                <div className="flex items-center gap-2">
                  <input
                    type="number"
                    min="10"
                    max="40"
                    value={lowMax}
                    onChange={(e) => setLowMax(Number(e.target.value))}
                    className="w-16 bg-slate-900 border border-slate-700 rounded px-2 py-1 text-center font-bold text-white"
                  />
                  <span className="text-slate-400">%</span>
                </div>
              </div>

              <div className="p-3 bg-slate-950 rounded border border-slate-800 flex items-center justify-between">
                <div>
                  <span className="text-amber-400 font-bold block">MODERATE RISK UPPER LIMIT</span>
                  <span className="text-[11px] text-slate-500 font-sans">Compensated strain; monitor trajectory</span>
                </div>
                <div className="flex items-center gap-2">
                  <input
                    type="number"
                    min="25"
                    max="65"
                    value={modMax}
                    onChange={(e) => setModMax(Number(e.target.value))}
                    className="w-16 bg-slate-900 border border-slate-700 rounded px-2 py-1 text-center font-bold text-white"
                  />
                  <span className="text-slate-400">%</span>
                </div>
              </div>

              <div className="p-3 bg-slate-950 rounded border border-slate-800 flex items-center justify-between">
                <div>
                  <span className="text-orange-400 font-bold block">HIGH RISK UPPER LIMIT</span>
                  <span className="text-[11px] text-slate-500 font-sans">Clinical review recommended trigger</span>
                </div>
                <div className="flex items-center gap-2">
                  <input
                    type="number"
                    min="50"
                    max="85"
                    value={highMax}
                    onChange={(e) => setHighMax(Number(e.target.value))}
                    className="w-16 bg-slate-900 border border-slate-700 rounded px-2 py-1 text-center font-bold text-white"
                  />
                  <span className="text-slate-400">%</span>
                </div>
              </div>

              <div className="p-3 bg-slate-950 rounded border border-slate-800 flex items-center justify-between">
                <div>
                  <span className="text-rose-400 font-bold block">CRITICAL RISK</span>
                  <span className="text-[11px] text-slate-500 font-sans">Severe septic shock criteria</span>
                </div>
                <span className="font-bold text-rose-400">≥ {highMax}%</span>
              </div>
            </div>

            <div className="flex items-center justify-between pt-2">
              <span className="text-[11px] text-slate-500 italic">
                *Clearly marked as investigational thresholds.
              </span>
              <button
                type="submit"
                className="px-4 py-2 rounded bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold text-xs flex items-center gap-1.5 transition-colors"
              >
                {savedSuccess && <CheckCircle2 className="w-3.5 h-3.5" />}
                {savedSuccess ? 'Thresholds Saved' : 'Apply Thresholds'}
              </button>
            </div>
          </form>
        </div>

        {/* ML Model Architecture & Preferences */}
        <div className="space-y-4">
          {/* Active Model Selector */}
          <div className="bg-slate-900/90 border border-slate-800 rounded-lg p-5 space-y-3">
            <h3 className="text-xs font-bold text-slate-300 uppercase tracking-wider flex items-center gap-2">
              <Cpu className="w-4 h-4 text-cyan-400" />
              Active Inference Model
            </h3>
            <p className="text-xs text-slate-500">
              Select which mathematical algorithm calculates live patient sepsis risk and SHAP attributions.
            </p>

            <div className="space-y-2">
              {(
                [
                  'Gradient Boosted Trees (XGBoost)',
                  'Random Forest',
                  'Logistic Regression',
                ] as MLModelType[]
              ).map((mType) => (
                <button
                  key={mType}
                  onClick={() => handleModelChange(mType)}
                  className={`w-full text-left p-3 rounded border text-xs transition-colors flex items-center justify-between ${
                    activeModel === mType
                      ? 'bg-cyan-950/40 border-cyan-500 text-cyan-200 font-semibold'
                      : 'bg-slate-950 border-slate-800 text-slate-300 hover:border-slate-700'
                  }`}
                >
                  <div>
                    <div className="font-bold">{mType}</div>
                    <div className="text-[11px] text-slate-500 font-normal">
                      {mType.includes('XGBoost')
                        ? 'Nonlinear sequential gradient boosting with tree SHAP decomposition (Highest ROC-AUC 0.914)'
                        : mType.includes('Random Forest')
                        ? '15-tree bagging ensemble with out-of-bag voting (ROC-AUC 0.887)'
                        : 'Standardized log-odds coefficients with direct interpretable feature weights (ROC-AUC 0.832)'}
                    </div>
                  </div>
                  {activeModel === mType && (
                    <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-cyan-500 text-slate-950 font-bold shrink-0 ml-2">
                      ACTIVE
                    </span>
                  )}
                </button>
              ))}
            </div>
          </div>

          {/* Unit & Data Quality Preferences */}
          <div className="bg-slate-900/90 border border-slate-800 rounded-lg p-5 space-y-4">
            <h3 className="text-xs font-bold text-slate-300 uppercase tracking-wider">
              Telemetry &amp; Clinical Display Settings
            </h3>

            <div className="flex items-center justify-between text-xs pb-3 border-b border-slate-800">
              <div>
                <span className="text-slate-300 font-medium block">Temperature Unit</span>
                <span className="text-slate-500 text-[11px]">Display format for clinical core temperature</span>
              </div>
              <div className="flex items-center gap-1 p-0.5 bg-slate-950 rounded border border-slate-800">
                <button
                  onClick={() => setTemperatureUnit('°C')}
                  className={`px-3 py-1 rounded text-xs transition-colors ${
                    temperatureUnit === '°C' ? 'bg-slate-800 text-white font-bold' : 'text-slate-400'
                  }`}
                >
                  °C
                </button>
                <button
                  onClick={() => setTemperatureUnit('°F')}
                  className={`px-3 py-1 rounded text-xs transition-colors ${
                    temperatureUnit === '°F' ? 'bg-slate-800 text-white font-bold' : 'text-slate-400'
                  }`}
                >
                  °F
                </button>
              </div>
            </div>

            <div className="flex items-center justify-between text-xs">
              <div>
                <span className="text-slate-300 font-medium block">Stale Telemetry Threshold</span>
                <span className="text-slate-500 text-[11px]">Flag data quality warning when vitals exceed hours</span>
              </div>
              <div className="flex items-center gap-1.5 font-mono">
                <input
                  type="number"
                  min="1"
                  max="12"
                  value={staleHoursLimit}
                  onChange={(e) => setStaleHoursLimit(Number(e.target.value))}
                  className="w-14 bg-slate-950 border border-slate-700 rounded px-2 py-1 text-center font-bold text-white text-xs"
                />
                <span className="text-slate-400">hours</span>
              </div>
            </div>

            {/* Reset Cohort Button */}
            <div className="pt-3 border-t border-slate-800 flex items-center justify-between">
              <span className="text-[11px] text-slate-500">Restore demo to initial 12 synthetic patients</span>
              <button
                onClick={resetEntireDemo}
                className="px-3 py-1.5 rounded bg-slate-800 hover:bg-slate-700 text-rose-300 border border-slate-700 text-xs flex items-center gap-1.5 transition-colors"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                Reset Demo Data
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
