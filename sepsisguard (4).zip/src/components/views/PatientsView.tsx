/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { RiskBadge } from '../common/RiskBadge';
import { SafetyBanner } from '../common/SafetyBanner';
import { ShapWaterfall } from '../common/ShapWaterfall';
import { VitalMultiChart } from '../common/VitalMultiChart';
import { PatientVitalsRecharts } from '../common/PatientVitalsRecharts';
import { ClinicalNotesSection } from '../common/ClinicalNotesSection';
import {
  User,
  Calendar,
  Bed,
  Activity,
  AlertTriangle,
  FileText,
  Clock,
  TrendingUp,
  Sliders,
  CheckCircle2,
  RefreshCw,
  PlusCircle,
  HelpCircle,
  Download,
} from 'lucide-react';
import { PatientMeasurement, RiskLevel } from '../../types/sepsis';

export const PatientsView: React.FC = () => {
  const {
    patients,
    selectedPatientId,
    setSelectedPatientId,
    setCurrentView,
    alerts,
    acknowledgeAlert,
    addMeasurementToPatient,
    activeModel,
    thresholds,
    temperatureUnit,
    addAuditLog,
  } = useApp();

  const currentPatient =
    patients.find((p) => p.id === selectedPatientId) || patients[0] || null;

  // Chart Display Tab State
  const [activeChartTab, setActiveChartTab] = useState<'vitals_recharts' | 'all_labs'>('vitals_recharts');

  // What-If Simulator Drawer State
  const [showWhatIfModal, setShowWhatIfModal] = useState(false);
  const [whatIfInputs, setWhatIfInputs] = useState<Partial<PatientMeasurement>>({});
  const [exportNotice, setExportNotice] = useState<string | null>(null);

  if (!currentPatient) {
    return <div className="p-8 text-center text-slate-500 text-sm">No patient selected.</div>;
  }

  const pred = currentPatient.latestPrediction;
  const m = currentPatient.latestMeasurement || currentPatient.history[currentPatient.history.length - 1];
  const patientAlerts = alerts.filter((a) => a.patientId === currentPatient.id);

  // Export longitudinal telemetry & labs to CSV
  const handleExportPatientCsv = () => {
    if (!currentPatient || !currentPatient.history || currentPatient.history.length === 0) return;

    const headers = [
      'patient_id',
      'mrn',
      'bed',
      'patient_name',
      'age',
      'sex',
      'admission_diagnosis',
      'code_status',
      'measurement_id',
      'timestamp',
      'heart_rate',
      'sbp',
      'dbp',
      'map',
      'respiratory_rate',
      'temperature_c',
      'spo2',
      'wbc',
      'lactate',
      'platelets',
      'creatinine',
      'glucose',
      'shock_index',
      'sirs_criteria_met',
      'qsofa_score',
      'delta_lactate_6h',
    ];

    const rows = currentPatient.history.map((h) => [
      `"${currentPatient.id}"`,
      `"${currentPatient.mrn}"`,
      `"${currentPatient.bed}"`,
      `"${currentPatient.name.replace(/"/g, '""')}"`,
      currentPatient.age,
      `"${currentPatient.sex}"`,
      `"${currentPatient.admissionDiagnosis.replace(/"/g, '""')}"`,
      `"${currentPatient.codeStatus}"`,
      `"${h.id}"`,
      `"${h.timestamp}"`,
      h.heartRate,
      h.sbp,
      h.dbp,
      h.map,
      h.respiratoryRate,
      h.temperature,
      h.spo2,
      h.wbc,
      h.lactate,
      h.platelets,
      h.creatinine,
      h.glucose,
      h.shockIndex ?? (h.sbp > 0 ? (h.heartRate / h.sbp).toFixed(2) : ''),
      h.sirsCriteriaMet ?? '',
      h.qSofaScore ?? '',
      h.deltaLactate6h ?? '',
    ]);

    const csvContent = [headers.join(','), ...rows.map((r) => r.join(','))].join('\r\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.setAttribute('href', url);
    const safeName = currentPatient.name.toLowerCase().replace(/[^a-z0-9]/g, '_');
    link.setAttribute('download', `${currentPatient.id}_${safeName}_longitudinal_vitals_labs.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);

    addAuditLog(
      'Patient Longitudinal CSV Exported',
      'REPORT',
      `Exported ${currentPatient.history.length} longitudinal records for ${currentPatient.id} (${currentPatient.name}, ${currentPatient.bed}) to CSV.`,
      currentPatient.id
    );

    setExportNotice(`Exported ${currentPatient.history.length} records to CSV.`);
    setTimeout(() => setExportNotice(null), 3500);
  };

  // Initialize what-if form with current values
  const handleOpenWhatIf = () => {
    if (m) {
      setWhatIfInputs({
        heartRate: m.heartRate,
        sbp: m.sbp,
        dbp: m.dbp,
        map: m.map,
        respiratoryRate: m.respiratoryRate,
        temperature: m.temperature,
        spo2: m.spo2,
        wbc: m.wbc,
        lactate: m.lactate,
        platelets: m.platelets,
        creatinine: m.creatinine,
        glucose: m.glucose,
      });
    }
    setShowWhatIfModal(true);
  };

  const handleApplyWhatIf = (e: React.FormEvent) => {
    e.preventDefault();
    addMeasurementToPatient(currentPatient.id, whatIfInputs);
    setShowWhatIfModal(false);
  };

  const formatTemp = (celsius: number) => {
    if (temperatureUnit === '°F') {
      return `${Math.round((celsius * 1.8 + 32) * 10) / 10}°F`;
    }
    return `${celsius}°C`;
  };

  return (
    <div className="space-y-6">
      <SafetyBanner />

      {/* Patient Selection Bar */}
      <div className="flex items-center gap-2 overflow-x-auto pb-2 border-b border-slate-800 text-xs">
        <span className="text-[11px] font-semibold text-slate-500 uppercase shrink-0">
          Select ICU Bed:
        </span>
        {patients.map((p) => {
          const isSelected = p.id === currentPatient.id;
          const pRisk = p.latestPrediction?.riskScore ?? 10;
          const pLevel = p.latestPrediction?.riskLevel ?? 'LOW';

          return (
            <button
              key={p.id}
              onClick={() => setSelectedPatientId(p.id)}
              className={`px-3 py-1.5 rounded font-mono text-xs transition-colors shrink-0 flex items-center gap-1.5 ${
                isSelected
                  ? 'bg-cyan-950/70 border border-cyan-500 text-cyan-200 font-bold'
                  : 'bg-slate-900 border border-slate-800 text-slate-400 hover:text-slate-200 hover:bg-slate-800'
              }`}
            >
              <span>{p.bed}</span>
              <span className="text-slate-500">·</span>
              <span
                className={`font-semibold tabular-nums ${
                  pLevel === 'CRITICAL'
                    ? 'text-rose-400'
                    : pLevel === 'HIGH'
                    ? 'text-orange-400'
                    : pLevel === 'MODERATE'
                    ? 'text-amber-400'
                    : 'text-emerald-400'
                }`}
              >
                {pRisk.toFixed(0)}%
              </span>
            </button>
          );
        })}
      </div>

      {/* Patient Dossier Header */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-lg p-5 flex flex-col lg:flex-row lg:items-center justify-between gap-4">
        <div>
          <div className="flex flex-wrap items-center gap-3">
            <span className="font-mono text-base font-bold text-white bg-slate-800 px-2.5 py-1 rounded border border-slate-700">
              {currentPatient.bed}
            </span>
            <h1 className="text-xl font-bold text-white">{currentPatient.name}</h1>
            <span className="text-xs text-slate-400 font-mono">
              {currentPatient.mrn} · {currentPatient.age} yo {currentPatient.sex} · {currentPatient.weightKg} kg
            </span>
          </div>

          <div className="mt-2 flex flex-wrap items-center gap-4 text-xs text-slate-400">
            <div>
              <span className="text-slate-500">Diagnosis: </span>
              <span className="text-slate-200 font-medium">{currentPatient.admissionDiagnosis}</span>
            </div>
            <span className="text-slate-700">·</span>
            <div>
              <span className="text-slate-500">Code Status: </span>
              <span className="text-slate-200 font-medium">{currentPatient.codeStatus}</span>
            </div>
            <span className="text-slate-700">·</span>
            <div>
              <span className="text-slate-500">Telemetry History: </span>
              <span className="font-mono text-slate-200 font-medium">{currentPatient.history.length} hrs</span>
            </div>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex flex-col sm:flex-row sm:items-center gap-2.5">
          {exportNotice && (
            <span className="text-xs text-emerald-400 font-mono flex items-center gap-1 animate-pulse">
              <CheckCircle2 className="w-3.5 h-3.5" />
              {exportNotice}
            </span>
          )}

          <button
            onClick={handleExportPatientCsv}
            className="px-3.5 py-2 rounded bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold flex items-center gap-1.5 border border-slate-700 transition-colors"
            title="Export longitudinal vitals and laboratory observations to CSV"
          >
            <Download className="w-3.5 h-3.5 text-cyan-400" />
            Download CSV
          </button>

          <button
            onClick={handleOpenWhatIf}
            className="px-3.5 py-2 rounded bg-cyan-600/20 hover:bg-cyan-600/30 text-cyan-300 border border-cyan-500/40 text-xs font-semibold flex items-center gap-1.5 transition-colors"
          >
            <Sliders className="w-3.5 h-3.5" />
            What-If Simulator
          </button>

          <button
            onClick={() => setCurrentView('reports')}
            className="px-3.5 py-2 rounded bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold flex items-center gap-1.5 border border-slate-700 transition-colors"
          >
            <FileText className="w-3.5 h-3.5 text-cyan-400" />
            Generate PDF Report
          </button>
        </div>
      </div>

      {/* Risk Engine Assessment & Projections */}
      {pred && (
        <div className="grid grid-cols-1 md:grid-cols-4 gap-3">
          {/* Current Risk Gauge */}
          <div className="bg-slate-900/80 border border-slate-800 rounded-lg p-4 flex flex-col justify-between">
            <div className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider flex items-center justify-between">
              <span>Estimated Sepsis Risk</span>
              <RiskBadge score={pred.riskScore} level={pred.riskLevel} trend={pred.trend} size="sm" />
            </div>

            <div className="my-3">
              <div className="flex items-baseline gap-1">
                <span
                  className={`text-4xl font-extrabold font-mono tabular-nums ${
                    pred.riskLevel === 'CRITICAL'
                      ? 'text-rose-400'
                      : pred.riskLevel === 'HIGH'
                      ? 'text-orange-400'
                      : pred.riskLevel === 'MODERATE'
                      ? 'text-amber-400'
                      : 'text-emerald-400'
                  }`}
                >
                  {pred.riskScore.toFixed(1)}%
                </span>
                <span className="text-xs text-slate-400 font-mono">prob</span>
              </div>
              <div className="w-full bg-slate-950 h-2 rounded-full mt-2 overflow-hidden">
                <div
                  className={`h-full rounded-full transition-all duration-500 ${
                    pred.riskLevel === 'CRITICAL'
                      ? 'bg-rose-500'
                      : pred.riskLevel === 'HIGH'
                      ? 'bg-orange-500'
                      : pred.riskLevel === 'MODERATE'
                      ? 'bg-amber-500'
                      : 'bg-emerald-500'
                  }`}
                  style={{ width: `${pred.riskScore}%` }}
                />
              </div>
            </div>

            <div className="text-[11px] text-slate-400 flex items-center justify-between border-t border-slate-800/80 pt-2">
              <span>Cohort Base: {pred.baseExpectedRisk.toFixed(1)}%</span>
              <span className="font-mono text-slate-300">{pred.trend}</span>
            </div>
          </div>

          {/* 6-Hour Projected Risk */}
          <div className="bg-slate-900/80 border border-slate-800 rounded-lg p-4 flex flex-col justify-between">
            <div className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider">
              6-Hour Projection
            </div>
            <div className="my-2">
              <div className="text-3xl font-bold font-mono text-slate-100 tabular-nums">
                {pred.projectedRisk6h.toFixed(1)}%
              </div>
              <p className="text-[11px] text-slate-400 mt-1 leading-snug">
                Extrapolated from rolling physiological trajectory &amp; lactate clearance velocity.
              </p>
            </div>
            <div className="text-[11px] text-slate-500 font-mono border-t border-slate-800/80 pt-2">
              Δ {(pred.projectedRisk6h - pred.riskScore).toFixed(1)}% vs Current
            </div>
          </div>

          {/* 12-Hour Projected Risk */}
          <div className="bg-slate-900/80 border border-slate-800 rounded-lg p-4 flex flex-col justify-between">
            <div className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider">
              12-Hour Projection
            </div>
            <div className="my-2">
              <div className="text-3xl font-bold font-mono text-slate-100 tabular-nums">
                {pred.projectedRisk12h.toFixed(1)}%
              </div>
              <p className="text-[11px] text-slate-400 mt-1 leading-snug">
                Projected multi-hour horizon assuming current resuscitation trajectory.
              </p>
            </div>
            <div className="text-[11px] text-slate-500 font-mono border-t border-slate-800/80 pt-2">
              Δ {(pred.projectedRisk12h - pred.riskScore).toFixed(1)}% vs Current
            </div>
          </div>

          {/* Data Quality & Model Confidence */}
          <div className="bg-slate-900/80 border border-slate-800 rounded-lg p-4 flex flex-col justify-between">
            <div className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider">
              Data Quality &amp; Confidence
            </div>
            <div className="my-2 space-y-1">
              <div className="flex items-center justify-between text-xs">
                <span className="text-slate-400">Quality Score:</span>
                <span className="font-mono font-bold text-emerald-400 tabular-nums">
                  {pred.dataQuality.score}% ({pred.dataQuality.level})
                </span>
              </div>
              <div className="flex items-center justify-between text-xs">
                <span className="text-slate-400">Model Confidence:</span>
                <span className="font-mono font-bold text-cyan-400 tabular-nums">
                  {pred.confidenceScore}%
                </span>
              </div>
              <div className="flex items-center justify-between text-xs">
                <span className="text-slate-400">Model Architecture:</span>
                <span className="font-mono text-slate-300 text-[11px] truncate max-w-[130px]">
                  {activeModel.split(' ')[0]}
                </span>
              </div>
            </div>
            <div className="text-[11px] text-slate-400 truncate border-t border-slate-800/80 pt-2">
              {pred.dataQuality.notes}
            </div>
          </div>
        </div>
      )}

      {/* Two Column Layout: Left = Time-Series Charts, Right = SHAP Feature Contributions */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left: Physiological Telemetry Charts */}
        <div className="lg:col-span-7 space-y-4">
          <div className="bg-slate-900/90 border border-slate-800 rounded-lg p-4 space-y-3">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-800 pb-3">
              <div>
                <h3 className="text-sm font-bold text-white uppercase tracking-wider flex items-center gap-2">
                  <Activity className="w-4 h-4 text-cyan-400" />
                  ICU Telemetry Time-Series
                </h3>
                <p className="text-xs text-slate-400 mt-0.5">
                  Continuous physiological trajectory over {currentPatient.history.length} hours of ICU observation.
                </p>
              </div>

              {/* Segmented Tab Switcher */}
              <div className="flex items-center gap-1 p-0.5 bg-slate-950 rounded border border-slate-800 text-xs">
                <button
                  onClick={() => setActiveChartTab('vitals_recharts')}
                  className={`px-2.5 py-1 rounded transition-colors font-medium ${
                    activeChartTab === 'vitals_recharts'
                      ? 'bg-slate-800 text-cyan-300 font-semibold shadow-xs'
                      : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  Vitals Stream (Recharts)
                </button>
                <button
                  onClick={() => setActiveChartTab('all_labs')}
                  className={`px-2.5 py-1 rounded transition-colors font-medium ${
                    activeChartTab === 'all_labs'
                      ? 'bg-slate-800 text-cyan-300 font-semibold shadow-xs'
                      : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  Multi-Lab Matrix
                </button>
              </div>
            </div>

            {/* Tab 1: Recharts Patient Vitals (Heart Rate, MAP, SpO2) */}
            {activeChartTab === 'vitals_recharts' ? (
              <PatientVitalsRecharts history={currentPatient.history} height={300} />
            ) : (
              /* Tab 2: All Labs & Biomarkers */
              <VitalMultiChart history={currentPatient.history} height={260} />
            )}
          </div>

          {/* Current Physiological Snapshot Table */}
          {m && (
            <div className="bg-slate-900/90 border border-slate-800 rounded-lg p-4 space-y-2">
              <h3 className="text-xs font-bold text-slate-300 uppercase tracking-wider">
                Latest Laboratory &amp; Hemodynamic Snapshot
              </h3>

              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-xs font-mono">
                <div className="p-2 bg-slate-950/80 rounded border border-slate-800">
                  <span className="text-slate-500 text-[11px] block">Heart Rate</span>
                  <span className="text-slate-100 font-bold">{m.heartRate} bpm</span>
                  <span className="text-[10px] text-slate-500 block">Target: 60-100</span>
                </div>

                <div className="p-2 bg-slate-950/80 rounded border border-slate-800">
                  <span className="text-slate-500 text-[11px] block">Blood Pressure / MAP</span>
                  <span className="text-slate-100 font-bold">{m.sbp}/{m.dbp} ({m.map})</span>
                  <span className="text-[10px] text-slate-500 block">Target MAP ≥ 65</span>
                </div>

                <div className="p-2 bg-slate-950/80 rounded border border-slate-800">
                  <span className="text-slate-500 text-[11px] block">Resp Rate &amp; SpO₂</span>
                  <span className="text-slate-100 font-bold">{m.respiratoryRate} bpm · {m.spo2}%</span>
                  <span className="text-[10px] text-slate-500 block">Target: 12-20, &gt;95%</span>
                </div>

                <div className="p-2 bg-slate-950/80 rounded border border-slate-800">
                  <span className="text-slate-500 text-[11px] block">Serum Lactate</span>
                  <span className={`font-bold ${m.lactate > 2.0 ? 'text-rose-400' : 'text-slate-100'}`}>
                    {m.lactate} mmol/L
                  </span>
                  <span className="text-[10px] text-slate-500 block">Target &lt; 2.0</span>
                </div>

                <div className="p-2 bg-slate-950/80 rounded border border-slate-800">
                  <span className="text-slate-500 text-[11px] block">White Blood Cells</span>
                  <span className="text-slate-100 font-bold">{m.wbc} ×10⁹/L</span>
                  <span className="text-[10px] text-slate-500 block">Target: 4.5-11.0</span>
                </div>

                <div className="p-2 bg-slate-950/80 rounded border border-slate-800">
                  <span className="text-slate-500 text-[11px] block">Platelet Count</span>
                  <span className={`font-bold ${m.platelets < 150 ? 'text-amber-400' : 'text-slate-100'}`}>
                    {m.platelets} ×10⁹/L
                  </span>
                  <span className="text-[10px] text-slate-500 block">Target: 150-450</span>
                </div>

                <div className="p-2 bg-slate-950/80 rounded border border-slate-800">
                  <span className="text-slate-500 text-[11px] block">Serum Creatinine</span>
                  <span className="text-slate-100 font-bold">{m.creatinine} mg/dL</span>
                  <span className="text-[10px] text-slate-500 block">Target: 0.6-1.2</span>
                </div>

                <div className="p-2 bg-slate-950/80 rounded border border-slate-800">
                  <span className="text-slate-500 text-[11px] block">Shock Index / SIRS</span>
                  <span className="text-slate-100 font-bold">
                    {(m.shockIndex || 0).toFixed(2)} · {m.sirsCriteriaMet}/4 criteria
                  </span>
                  <span className="text-[10px] text-slate-500 block">SI &gt; 0.85 abnormal</span>
                </div>
              </div>
            </div>
          )}

          {/* Patient Alert History */}
          <div className="bg-slate-900/90 border border-slate-800 rounded-lg p-4 space-y-3">
            <h3 className="text-xs font-bold text-slate-300 uppercase tracking-wider flex items-center justify-between">
              <span>Alert History for {currentPatient.bed}</span>
              <span className="text-[10px] font-mono text-slate-500">{patientAlerts.length} Recorded</span>
            </h3>

            {patientAlerts.length === 0 ? (
              <div className="text-xs text-slate-500 py-3 text-center">
                No active or acknowledged alerts recorded for this patient.
              </div>
            ) : (
              <div className="space-y-2">
                {patientAlerts.map((alt) => (
                  <div
                    key={alt.id}
                    className="p-3 bg-slate-950/70 border border-slate-800 rounded flex flex-col sm:flex-row sm:items-center justify-between gap-2 text-xs"
                  >
                    <div>
                      <div className="flex items-center gap-2">
                        <RiskBadge
                          score={alt.riskScore}
                          level={alt.severity.toUpperCase() as RiskLevel}
                          showTrend={false}
                          size="sm"
                        />
                        <span className="font-semibold text-slate-200">{alt.headline}</span>
                      </div>
                      <p className="text-[11px] text-slate-400 mt-1">{alt.primaryReason}</p>
                      <div className="text-[10px] text-slate-500 font-mono mt-1">
                        Triggered: {new Date(alt.timestamp).toLocaleString()}
                        {alt.acknowledgedBy && (
                          <span className="text-cyan-400 ml-2">
                            · Acknowledged by {alt.acknowledgedBy} ({new Date(alt.acknowledgedAt!).toLocaleTimeString()})
                          </span>
                        )}
                      </div>
                    </div>

                    {alt.status === 'active' && (
                      <button
                        onClick={() => acknowledgeAlert(alt.id)}
                        className="px-2.5 py-1 text-xs rounded bg-rose-600/30 hover:bg-rose-600/50 text-rose-200 border border-rose-500/40 shrink-0"
                      >
                        Acknowledge
                      </button>
                    )}
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* Right: SHAP Explainability & Feature Contribution Breakdown */}
        <div className="lg:col-span-5 space-y-4">
          <div className="bg-slate-900/90 border border-slate-800 rounded-lg p-4">
            <div className="mb-3">
              <h3 className="text-sm font-bold text-white uppercase tracking-wider flex items-center gap-2">
                <HelpCircle className="w-4 h-4 text-cyan-400" />
                Explain Prediction — SHAP Attributions
              </h3>
              <p className="text-xs text-slate-400 mt-0.5">
                Exact Shapley feature contributions relative to population baseline.
              </p>
            </div>

            {pred?.featureContributions ? (
              <ShapWaterfall
                baseRisk={pred.baseExpectedRisk}
                finalRisk={pred.riskScore}
                features={pred.featureContributions}
              />
            ) : (
              <div className="p-8 text-center text-xs text-slate-500">
                Prediction has not yet been computed for this patient.
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Secure Clinical Notes & Observation Attestation Section */}
      <ClinicalNotesSection patient={currentPatient} />

      {/* What-If Prediction Modal / Drawer */}
      {showWhatIfModal && (
        <div className="fixed inset-0 bg-black/70 backdrop-blur-xs z-50 flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-700 rounded-xl max-w-2xl w-full p-6 space-y-4 shadow-2xl">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div>
                <h3 className="text-base font-bold text-white">What-If Physiological Simulation</h3>
                <p className="text-xs text-slate-400">
                  Simulate ad-hoc telemetry adjustments for {currentPatient.bed} ({currentPatient.name}) to test model sensitivity.
                </p>
              </div>
              <button
                onClick={() => setShowWhatIfModal(false)}
                className="text-slate-400 hover:text-white text-lg font-bold"
              >
                &times;
              </button>
            </div>

            <form onSubmit={handleApplyWhatIf} className="space-y-4">
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 text-xs font-mono">
                <div>
                  <label className="text-slate-400 block mb-1">Heart Rate (bpm)</label>
                  <input
                    type="number"
                    value={whatIfInputs.heartRate ?? 75}
                    onChange={(e) => setWhatIfInputs({ ...whatIfInputs, heartRate: Number(e.target.value) })}
                    className="w-full bg-slate-950 border border-slate-700 rounded px-2.5 py-1.5 text-white"
                  />
                </div>

                <div>
                  <label className="text-slate-400 block mb-1">Systolic BP (mmHg)</label>
                  <input
                    type="number"
                    value={whatIfInputs.sbp ?? 120}
                    onChange={(e) => setWhatIfInputs({ ...whatIfInputs, sbp: Number(e.target.value) })}
                    className="w-full bg-slate-950 border border-slate-700 rounded px-2.5 py-1.5 text-white"
                  />
                </div>

                <div>
                  <label className="text-slate-400 block mb-1">Diastolic BP (mmHg)</label>
                  <input
                    type="number"
                    value={whatIfInputs.dbp ?? 75}
                    onChange={(e) => setWhatIfInputs({ ...whatIfInputs, dbp: Number(e.target.value) })}
                    className="w-full bg-slate-950 border border-slate-700 rounded px-2.5 py-1.5 text-white"
                  />
                </div>

                <div>
                  <label className="text-slate-400 block mb-1">Respiratory Rate</label>
                  <input
                    type="number"
                    value={whatIfInputs.respiratoryRate ?? 16}
                    onChange={(e) => setWhatIfInputs({ ...whatIfInputs, respiratoryRate: Number(e.target.value) })}
                    className="w-full bg-slate-950 border border-slate-700 rounded px-2.5 py-1.5 text-white"
                  />
                </div>

                <div>
                  <label className="text-slate-400 block mb-1">Serum Lactate (mmol/L)</label>
                  <input
                    type="number"
                    step="0.1"
                    value={whatIfInputs.lactate ?? 1.2}
                    onChange={(e) => setWhatIfInputs({ ...whatIfInputs, lactate: Number(e.target.value) })}
                    className="w-full bg-slate-950 border border-slate-700 rounded px-2.5 py-1.5 text-white"
                  />
                </div>

                <div>
                  <label className="text-slate-400 block mb-1">WBC (×10⁹/L)</label>
                  <input
                    type="number"
                    step="0.1"
                    value={whatIfInputs.wbc ?? 7.5}
                    onChange={(e) => setWhatIfInputs({ ...whatIfInputs, wbc: Number(e.target.value) })}
                    className="w-full bg-slate-950 border border-slate-700 rounded px-2.5 py-1.5 text-white"
                  />
                </div>

                <div>
                  <label className="text-slate-400 block mb-1">Platelets (×10⁹/L)</label>
                  <input
                    type="number"
                    value={whatIfInputs.platelets ?? 230}
                    onChange={(e) => setWhatIfInputs({ ...whatIfInputs, platelets: Number(e.target.value) })}
                    className="w-full bg-slate-950 border border-slate-700 rounded px-2.5 py-1.5 text-white"
                  />
                </div>

                <div>
                  <label className="text-slate-400 block mb-1">Creatinine (mg/dL)</label>
                  <input
                    type="number"
                    step="0.1"
                    value={whatIfInputs.creatinine ?? 0.9}
                    onChange={(e) => setWhatIfInputs({ ...whatIfInputs, creatinine: Number(e.target.value) })}
                    className="w-full bg-slate-950 border border-slate-700 rounded px-2.5 py-1.5 text-white"
                  />
                </div>

                <div>
                  <label className="text-slate-400 block mb-1">Temperature (°C)</label>
                  <input
                    type="number"
                    step="0.1"
                    value={whatIfInputs.temperature ?? 36.8}
                    onChange={(e) => setWhatIfInputs({ ...whatIfInputs, temperature: Number(e.target.value) })}
                    className="w-full bg-slate-950 border border-slate-700 rounded px-2.5 py-1.5 text-white"
                  />
                </div>
              </div>

              <div className="pt-3 border-t border-slate-800 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setShowWhatIfModal(false)}
                  className="px-4 py-2 text-xs rounded bg-slate-800 text-slate-300 hover:bg-slate-700"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 text-xs font-semibold rounded bg-cyan-500 hover:bg-cyan-400 text-slate-950"
                >
                  Calculate What-If Sepsis Prediction
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
