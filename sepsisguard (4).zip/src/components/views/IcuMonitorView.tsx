/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { RiskBadge } from '../common/RiskBadge';
import {
  Activity,
  Heart,
  Droplets,
  Thermometer,
  Wind,
  Search,
  ArrowUpDown,
  Filter,
  Eye,
  SlidersHorizontal,
} from 'lucide-react';
import { RiskLevel } from '../../types/sepsis';

export const IcuMonitorView: React.FC = () => {
  const { patients, setSelectedPatientId, setCurrentView, temperatureUnit } = useApp();
  const [filterSeverity, setFilterSeverity] = useState<string>('all');
  const [sortBy, setSortBy] = useState<'risk_desc' | 'bed' | 'name' | 'lactate'>('risk_desc');
  const [search, setSearch] = useState('');

  const filteredPatients = patients
    .filter((p) => {
      const matchSearch =
        p.name.toLowerCase().includes(search.toLowerCase()) ||
        p.bed.toLowerCase().includes(search.toLowerCase()) ||
        p.admissionDiagnosis.toLowerCase().includes(search.toLowerCase());

      if (!matchSearch) return false;
      if (filterSeverity === 'all') return true;
      if (filterSeverity === 'critical_high') {
        const lvl = p.latestPrediction?.riskLevel;
        return lvl === 'CRITICAL' || lvl === 'HIGH';
      }
      if (filterSeverity === 'worsening') return p.latestPrediction?.trend === 'Worsening';
      return p.latestPrediction?.riskLevel === filterSeverity;
    })
    .sort((a, b) => {
      if (sortBy === 'risk_desc') {
        return (b.latestPrediction?.riskScore ?? 0) - (a.latestPrediction?.riskScore ?? 0);
      }
      if (sortBy === 'bed') return a.bed.localeCompare(b.bed);
      if (sortBy === 'name') return a.name.localeCompare(b.name);
      if (sortBy === 'lactate') {
        return (b.latestMeasurement?.lactate ?? 0) - (a.latestMeasurement?.lactate ?? 0);
      }
      return 0;
    });

  const handleOpenPatient = (id: string) => {
    setSelectedPatientId(id);
    setCurrentView('patients');
  };

  const formatTemp = (celsius: number) => {
    if (temperatureUnit === '°F') {
      return `${Math.round((celsius * 1.8 + 32) * 10) / 10}°F`;
    }
    return `${celsius}°C`;
  };

  return (
    <div className="space-y-4">
      {/* Top Filter and Controls Bar */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-3 bg-slate-900/80 p-3.5 rounded-lg border border-slate-800">
        <div>
          <h2 className="text-sm font-bold text-white uppercase tracking-wider flex items-center gap-2">
            <Activity className="w-4 h-4 text-cyan-400" />
            ICU Multi-Bed Telemetry Monitor
          </h2>
          <p className="text-xs text-slate-400 mt-0.5">
            Continuous physiological telemetry, hemodynamics, and predictive sepsis risk trajectories.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          {/* Search */}
          <div className="relative">
            <Search className="w-3.5 h-3.5 absolute left-2.5 top-2.5 text-slate-500" />
            <input
              type="text"
              placeholder="Search monitor..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="pl-8 pr-3 py-1 text-xs bg-slate-950 border border-slate-700 rounded text-slate-200 placeholder-slate-500 focus:outline-none focus:border-cyan-500 w-44"
            />
          </div>

          {/* Quick Filter */}
          <select
            value={filterSeverity}
            onChange={(e) => setFilterSeverity(e.target.value)}
            className="text-xs bg-slate-950 border border-slate-700 rounded px-2.5 py-1 text-slate-300 focus:outline-none"
          >
            <option value="all">All Beds ({patients.length})</option>
            <option value="critical_high">Critical & High Risk</option>
            <option value="worsening">Worsening Trend</option>
            <option value="CRITICAL">Critical Only</option>
            <option value="HIGH">High Only</option>
            <option value="MODERATE">Moderate Only</option>
            <option value="LOW">Low Only</option>
          </select>

          {/* Sort */}
          <select
            value={sortBy}
            onChange={(e) => setSortBy(e.target.value as any)}
            className="text-xs bg-slate-950 border border-slate-700 rounded px-2.5 py-1 text-slate-300 focus:outline-none"
          >
            <option value="risk_desc">Sort: Risk Score (High → Low)</option>
            <option value="lactate">Sort: Lactate (High → Low)</option>
            <option value="bed">Sort: Bed ID (Ascending)</option>
            <option value="name">Sort: Patient Name</option>
          </select>
        </div>
      </div>

      {/* Bed Telemetry Cards List / Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-3.5">
        {filteredPatients.map((patient) => {
          const m = patient.latestMeasurement;
          const pred = patient.latestPrediction;
          const riskScore = pred?.riskScore ?? 15;
          const riskLevel = pred?.riskLevel ?? 'LOW';
          const trend = pred?.trend ?? 'Stable';
          const topFactors = pred?.featureContributions?.slice(0, 2) || [];

          return (
            <div
              key={patient.id}
              className={`bg-slate-900/90 border rounded-lg p-4 transition-all duration-150 flex flex-col justify-between gap-3 ${
                riskLevel === 'CRITICAL'
                  ? 'border-rose-500/50 shadow-sm shadow-rose-950/40'
                  : riskLevel === 'HIGH'
                  ? 'border-orange-500/40'
                  : 'border-slate-800'
              }`}
            >
              {/* Top Row: Bed, Patient Name, Diagnosis, Risk */}
              <div className="flex items-start justify-between gap-2">
                <div>
                  <div className="flex items-center gap-2">
                    <span className="font-mono text-xs font-bold text-cyan-300 bg-slate-950 px-2 py-0.5 rounded border border-slate-800">
                      {patient.bed}
                    </span>
                    <span className="font-bold text-slate-100 text-sm">{patient.name}</span>
                    <span className="text-xs text-slate-400">
                      ({patient.age}y {patient.sex.charAt(0)})
                    </span>
                  </div>
                  <div className="text-xs text-slate-400 mt-1 truncate max-w-sm">
                    {patient.admissionDiagnosis}
                  </div>
                </div>

                <div className="text-right flex flex-col items-end gap-1">
                  <RiskBadge score={riskScore} level={riskLevel} trend={trend} size="md" />
                  <span className="text-[10px] text-slate-500 font-mono">
                    Projected 6h: {pred?.projectedRisk6h}%
                  </span>
                </div>
              </div>

              {/* Main Telemetry Matrix */}
              {m && (
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-xs font-mono bg-slate-950/70 p-2.5 rounded border border-slate-800/80">
                  {/* Hemodynamics: HR & BP */}
                  <div className="space-y-1">
                    <div className="flex items-center justify-between text-slate-400 text-[11px]">
                      <span>HR</span>
                      <span className={m.heartRate > 100 || m.heartRate < 55 ? 'text-rose-400 font-bold' : 'text-slate-200'}>
                        {m.heartRate} bpm
                      </span>
                    </div>
                    <div className="flex items-center justify-between text-slate-400 text-[11px]">
                      <span>BP</span>
                      <span className="text-slate-200">{m.sbp}/{m.dbp}</span>
                    </div>
                    <div className="flex items-center justify-between text-slate-400 text-[11px]">
                      <span>MAP</span>
                      <span className={m.map < 65 ? 'text-rose-400 font-bold' : 'text-slate-200'}>
                        {m.map} mmHg
                      </span>
                    </div>
                  </div>

                  {/* Respiration & Oxygen */}
                  <div className="space-y-1 border-l border-slate-800/80 pl-2">
                    <div className="flex items-center justify-between text-slate-400 text-[11px]">
                      <span>RR</span>
                      <span className={m.respiratoryRate > 22 ? 'text-amber-400 font-bold' : 'text-slate-200'}>
                        {m.respiratoryRate} /min
                      </span>
                    </div>
                    <div className="flex items-center justify-between text-slate-400 text-[11px]">
                      <span>SpO₂</span>
                      <span className={m.spo2 < 93 ? 'text-rose-400 font-bold' : 'text-slate-200'}>
                        {m.spo2}%
                      </span>
                    </div>
                    <div className="flex items-center justify-between text-slate-400 text-[11px]">
                      <span>Temp</span>
                      <span className={m.temperature > 38.0 || m.temperature < 36.0 ? 'text-amber-400 font-bold' : 'text-slate-200'}>
                        {formatTemp(m.temperature)}
                      </span>
                    </div>
                  </div>

                  {/* Labs: Lactate & WBC */}
                  <div className="space-y-1 border-l border-slate-800/80 pl-2">
                    <div className="flex items-center justify-between text-slate-400 text-[11px]">
                      <span>Lactate</span>
                      <span className={m.lactate > 2.0 ? 'text-rose-400 font-bold' : 'text-slate-200'}>
                        {m.lactate} mmol/L
                      </span>
                    </div>
                    <div className="flex items-center justify-between text-slate-400 text-[11px]">
                      <span>WBC</span>
                      <span className={m.wbc > 12.0 || m.wbc < 4.0 ? 'text-amber-400 font-bold' : 'text-slate-200'}>
                        {m.wbc} ×10⁹/L
                      </span>
                    </div>
                    <div className="flex items-center justify-between text-slate-400 text-[11px]">
                      <span>Platelets</span>
                      <span className={m.platelets < 150 ? 'text-rose-400 font-bold' : 'text-slate-200'}>
                        {m.platelets}
                      </span>
                    </div>
                  </div>

                  {/* Derived Scores & AKI */}
                  <div className="space-y-1 border-l border-slate-800/80 pl-2">
                    <div className="flex items-center justify-between text-slate-400 text-[11px]">
                      <span>Shock Idx</span>
                      <span className={(m.shockIndex || 0) > 0.85 ? 'text-rose-400 font-bold' : 'text-slate-200'}>
                        {(m.shockIndex || 0).toFixed(2)}
                      </span>
                    </div>
                    <div className="flex items-center justify-between text-slate-400 text-[11px]">
                      <span>SIRS</span>
                      <span className={(m.sirsCriteriaMet || 0) >= 2 ? 'text-amber-400 font-bold' : 'text-slate-200'}>
                        {m.sirsCriteriaMet}/4 criteria
                      </span>
                    </div>
                    <div className="flex items-center justify-between text-slate-400 text-[11px]">
                      <span>Creatinine</span>
                      <span className={m.creatinine > 1.3 ? 'text-amber-400 font-bold' : 'text-slate-200'}>
                        {m.creatinine} mg/dL
                      </span>
                    </div>
                  </div>
                </div>
              )}

              {/* Bottom Row: Top Explainability Feature & Quick Action */}
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pt-1 border-t border-slate-800/80 text-xs">
                <div className="text-[11px] text-slate-400 truncate">
                  {topFactors.length > 0 ? (
                    <span>
                      <strong className="text-slate-300">SHAP Driver: </strong>
                      {topFactors[0].label} ({topFactors[0].currentValue} {topFactors[0].unit}){' '}
                      <span className={topFactors[0].direction === 'risk_increasing' ? 'text-rose-400' : 'text-emerald-400'}>
                        ({topFactors[0].contributionPercent > 0 ? '+' : ''}{topFactors[0].contributionPercent}%)
                      </span>
                    </span>
                  ) : (
                    <span>All physiological parameters within normal bounds</span>
                  )}
                </div>

                <div className="flex items-center gap-2 shrink-0">
                  <button
                    onClick={() => handleOpenPatient(patient.id)}
                    className="px-3 py-1 rounded bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-medium flex items-center gap-1.5 transition-colors"
                  >
                    <Eye className="w-3.5 h-3.5 text-cyan-400" />
                    Open Dossier & SHAP
                  </button>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
