/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { SafetyBanner } from '../common/SafetyBanner';
import {
  ShieldCheck,
  Search,
  Filter,
  Clock,
  Download,
  FileCheck,
} from 'lucide-react';
import { AuditLogEntry } from '../../types/sepsis';

export const AuditLogsView: React.FC = () => {
  const { auditLogs } = useApp();
  const [filterCategory, setFilterCategory] = useState<string>('all');
  const [search, setSearch] = useState<string>('');

  const filteredLogs = auditLogs.filter((log) => {
    if (filterCategory !== 'all' && log.category !== filterCategory) return false;
    if (search) {
      const q = search.toLowerCase();
      return (
        log.action.toLowerCase().includes(q) ||
        log.userName.toLowerCase().includes(q) ||
        log.details.toLowerCase().includes(q) ||
        (log.patientId && log.patientId.toLowerCase().includes(q))
      );
    }
    return true;
  });

  const handleExportAuditJson = () => {
    const dataStr = 'data:text/json;charset=utf-8,' + encodeURIComponent(JSON.stringify(auditLogs, null, 2));
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute('href', dataStr);
    downloadAnchor.setAttribute('download', `sepsisguard_audit_log_${Date.now()}.json`);
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
  };

  return (
    <div className="space-y-6 font-sans">
      <SafetyBanner />

      {/* Header and Controls */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-lg p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-base font-bold text-white flex items-center gap-2">
            <ShieldCheck className="w-5 h-5 text-cyan-400" />
            Clinical Decision Support Audit Log &amp; Traceability
          </h2>
          <p className="text-xs text-slate-400 mt-0.5">
            Immutable session event trail recording clinician acknowledgments, ML inferences, and system actions.
          </p>
        </div>

        <button
          onClick={handleExportAuditJson}
          className="px-3.5 py-2 rounded bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-medium flex items-center gap-1.5 border border-slate-700 transition-colors shrink-0"
        >
          <Download className="w-3.5 h-3.5 text-slate-400" />
          Export Audit Trail (JSON)
        </button>
      </div>

      {/* Filter and Search Bar */}
      <div className="flex flex-wrap items-center justify-between gap-3 bg-slate-900/80 p-3.5 rounded-lg border border-slate-800 text-xs">
        <div className="relative">
          <Search className="w-3.5 h-3.5 absolute left-2.5 top-2.5 text-slate-500" />
          <input
            type="text"
            placeholder="Search audit trail..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="pl-8 pr-3 py-1 bg-slate-950 border border-slate-700 rounded text-slate-200 placeholder-slate-500 focus:outline-none focus:border-cyan-500 w-56"
          />
        </div>

        <div className="flex items-center gap-1.5">
          <span className="text-slate-400">Category:</span>
          <select
            value={filterCategory}
            onChange={(e) => setFilterCategory(e.target.value)}
            className="bg-slate-950 border border-slate-700 rounded px-2.5 py-1 text-slate-200 focus:outline-none"
          >
            <option value="all">All Categories ({auditLogs.length})</option>
            <option value="ALERT">Alert Actions</option>
            <option value="PREDICTION">Predictions &amp; Telemetry</option>
            <option value="SYSTEM">System &amp; Simulation</option>
            <option value="IMPORT">CSV Ingestion</option>
            <option value="AUTH">Role / Persona Changes</option>
          </select>
        </div>
      </div>

      {/* Audit Log Table */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-lg overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-xs text-left font-mono">
            <thead className="bg-slate-950 text-slate-400 uppercase text-[10px] border-b border-slate-800">
              <tr>
                <th className="p-3">Timestamp</th>
                <th className="p-3">Category</th>
                <th className="p-3">Clinician / Persona</th>
                <th className="p-3">Action</th>
                <th className="p-3">Target Patient</th>
                <th className="p-3">Details &amp; Attestation</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800 text-slate-300">
              {filteredLogs.map((log) => {
                const badgeColor =
                  log.category === 'ALERT'
                    ? 'text-rose-400 bg-rose-950/40 border-rose-800'
                    : log.category === 'PREDICTION'
                    ? 'text-cyan-400 bg-cyan-950/40 border-cyan-800'
                    : log.category === 'IMPORT'
                    ? 'text-emerald-400 bg-emerald-950/40 border-emerald-800'
                    : log.category === 'AUTH'
                    ? 'text-purple-400 bg-purple-950/40 border-purple-800'
                    : 'text-slate-400 bg-slate-950 border-slate-800';

                return (
                  <tr key={log.id} className="hover:bg-slate-800/40">
                    <td className="p-3 text-slate-500 whitespace-nowrap">
                      {new Date(log.timestamp).toLocaleString()}
                    </td>
                    <td className="p-3 whitespace-nowrap">
                      <span className={`px-2 py-0.5 rounded border text-[10px] font-bold ${badgeColor}`}>
                        {log.category}
                      </span>
                    </td>
                    <td className="p-3 whitespace-nowrap">
                      <div className="text-slate-200 font-semibold">{log.userName}</div>
                      <div className="text-[10px] text-slate-500">{log.userRole}</div>
                    </td>
                    <td className="p-3 font-semibold text-slate-200 whitespace-nowrap">
                      {log.action}
                    </td>
                    <td className="p-3 font-bold text-cyan-400 whitespace-nowrap">
                      {log.patientId || '—'}
                    </td>
                    <td className="p-3 text-slate-400 font-sans max-w-md leading-relaxed">
                      {log.details}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
