/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { SafetyBanner } from '../common/SafetyBanner';
import { evaluateModelOnSyntheticValidationCohort } from '../../services/mlEngine';
import { MLModelType } from '../../types/sepsis';
import {
  Cpu,
  ShieldCheck,
  BarChart3,
  Sliders,
  CheckCircle,
  HelpCircle,
  Database,
  ArrowRight,
} from 'lucide-react';

export const ModelPerformanceView: React.FC = () => {
  const { activeModel, setActiveModel, thresholds, setThresholds, currentUser } = useApp();
  const [selectedEvaluationModel, setSelectedEvaluationModel] = useState<MLModelType>(activeModel);
  const [thresholdCutoff, setThresholdCutoff] = useState<number>(thresholds.moderateMax);

  const metrics = evaluateModelOnSyntheticValidationCohort(selectedEvaluationModel, thresholdCutoff);

  const handleSetActiveModel = (model: MLModelType) => {
    setSelectedEvaluationModel(model);
    setActiveModel(model);
  };

  return (
    <div className="space-y-6 font-sans">
      <SafetyBanner />

      {/* Header and Model Selector */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-lg p-5 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <Cpu className="w-5 h-5 text-cyan-400" />
            <h2 className="text-base font-bold text-white tracking-tight">
              Clinical ML Model Validation &amp; Architecture Lab
            </h2>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            Evaluated on stratified patient-level holdout validation set (180 synthetic ICU encounters, 3,240 observation hours) with zero temporal leakage.
          </p>
        </div>

        {/* Model Switcher Buttons */}
        <div className="flex items-center gap-1.5 p-1 bg-slate-950 rounded-lg border border-slate-800 text-xs">
          {(
            [
              'Gradient Boosted Trees (XGBoost)',
              'Random Forest',
              'Logistic Regression',
            ] as MLModelType[]
          ).map((mType) => {
            const isSelected = selectedEvaluationModel === mType;
            return (
              <button
                key={mType}
                onClick={() => handleSetActiveModel(mType)}
                className={`px-3 py-1.5 rounded font-medium transition-colors whitespace-nowrap ${
                  isSelected
                    ? 'bg-cyan-500 text-slate-950 font-bold shadow-sm'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                {mType.split(' ')[0]}
                {activeModel === mType && ' (Active)'}
              </button>
            );
          })}
        </div>
      </div>

      {/* Primary Quantitative Performance Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-7 gap-3">
        <div className="bg-slate-900/80 border border-slate-800 rounded-lg p-3.5">
          <div className="text-[11px] font-semibold text-slate-400 uppercase">ROC-AUC</div>
          <div className="text-2xl font-bold font-mono text-cyan-400 mt-1 tabular-nums">
            {metrics.rocAuc.toFixed(3)}
          </div>
          <div className="text-[10px] text-slate-500 font-mono mt-0.5">Area Under Curve</div>
        </div>

        <div className="bg-slate-900/80 border border-slate-800 rounded-lg p-3.5">
          <div className="text-[11px] font-semibold text-slate-400 uppercase">PR-AUC</div>
          <div className="text-2xl font-bold font-mono text-cyan-400 mt-1 tabular-nums">
            {metrics.prAuc.toFixed(3)}
          </div>
          <div className="text-[10px] text-slate-500 font-mono mt-0.5">Precision-Recall</div>
        </div>

        <div className="bg-slate-900/80 border border-slate-800 rounded-lg p-3.5">
          <div className="text-[11px] font-semibold text-slate-400 uppercase">Sensitivity</div>
          <div className="text-2xl font-bold font-mono text-emerald-400 mt-1 tabular-nums">
            {metrics.recall.toFixed(1)}%
          </div>
          <div className="text-[10px] text-slate-500 font-mono mt-0.5">True Positive Recall</div>
        </div>

        <div className="bg-slate-900/80 border border-slate-800 rounded-lg p-3.5">
          <div className="text-[11px] font-semibold text-slate-400 uppercase">Specificity</div>
          <div className="text-2xl font-bold font-mono text-emerald-400 mt-1 tabular-nums">
            {metrics.specificity.toFixed(1)}%
          </div>
          <div className="text-[10px] text-slate-500 font-mono mt-0.5">True Negative Rate</div>
        </div>

        <div className="bg-slate-900/80 border border-slate-800 rounded-lg p-3.5">
          <div className="text-[11px] font-semibold text-slate-400 uppercase">Precision</div>
          <div className="text-2xl font-bold font-mono text-slate-200 mt-1 tabular-nums">
            {metrics.precision.toFixed(1)}%
          </div>
          <div className="text-[10px] text-slate-500 font-mono mt-0.5">Pos Predictive Val</div>
        </div>

        <div className="bg-slate-900/80 border border-slate-800 rounded-lg p-3.5">
          <div className="text-[11px] font-semibold text-slate-400 uppercase">F1-Score</div>
          <div className="text-2xl font-bold font-mono text-slate-200 mt-1 tabular-nums">
            {metrics.f1Score.toFixed(1)}%
          </div>
          <div className="text-[10px] text-slate-500 font-mono mt-0.5">Harmonic Mean</div>
        </div>

        <div className="bg-slate-900/80 border border-slate-800 rounded-lg p-3.5">
          <div className="text-[11px] font-semibold text-slate-400 uppercase">Accuracy</div>
          <div className="text-2xl font-bold font-mono text-slate-200 mt-1 tabular-nums">
            {metrics.accuracy.toFixed(1)}%
          </div>
          <div className="text-[10px] text-slate-500 font-mono mt-0.5">N = {metrics.sampleSize} Cases</div>
        </div>
      </div>

      {/* Confusion Matrix and ROC / PR Curve Section */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Confusion Matrix Box */}
        <div className="lg:col-span-6 bg-slate-900/90 border border-slate-800 rounded-lg p-5 space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-sm font-bold text-white uppercase tracking-wider">
                Confusion Matrix (Holdout Validation)
              </h3>
              <p className="text-xs text-slate-400 mt-0.5">
                Evaluated at threshold cutoff = {thresholdCutoff}% estimated sepsis risk.
              </p>
            </div>
            <span className="text-[11px] font-mono text-cyan-400 bg-cyan-950/60 px-2 py-0.5 rounded border border-cyan-800">
              N = {metrics.sampleSize}
            </span>
          </div>

          {/* 2x2 Matrix */}
          <div className="space-y-2">
            <div className="grid grid-cols-3 gap-2 text-center text-xs font-mono">
              <div className="p-2 text-slate-500 flex items-center justify-center font-sans text-[11px]">
                Ground Truth \ Model
              </div>
              <div className="p-2 bg-slate-950 rounded font-semibold text-slate-300">
                Predicted Positive
              </div>
              <div className="p-2 bg-slate-950 rounded font-semibold text-slate-300">
                Predicted Negative
              </div>

              {/* Actual Positive Row */}
              <div className="p-3 bg-slate-950 rounded font-semibold text-slate-300 flex items-center justify-center">
                Actual Deterioration
              </div>
              <div className="p-4 bg-emerald-950/40 border border-emerald-600/40 rounded flex flex-col justify-center">
                <span className="text-xl font-bold text-emerald-400 tabular-nums">
                  {metrics.confusionMatrix.tp}
                </span>
                <span className="text-[10px] text-emerald-300 uppercase mt-0.5">True Positive (TP)</span>
              </div>
              <div className="p-4 bg-rose-950/40 border border-rose-600/40 rounded flex flex-col justify-center">
                <span className="text-xl font-bold text-rose-400 tabular-nums">
                  {metrics.confusionMatrix.fn}
                </span>
                <span className="text-[10px] text-rose-300 uppercase mt-0.5">False Negative (FN)</span>
              </div>

              {/* Actual Negative Row */}
              <div className="p-3 bg-slate-950 rounded font-semibold text-slate-300 flex items-center justify-center">
                Actual Stable/Nominal
              </div>
              <div className="p-4 bg-amber-950/40 border border-amber-600/40 rounded flex flex-col justify-center">
                <span className="text-xl font-bold text-amber-400 tabular-nums">
                  {metrics.confusionMatrix.fp}
                </span>
                <span className="text-[10px] text-amber-300 uppercase mt-0.5">False Positive (FP)</span>
              </div>
              <div className="p-4 bg-emerald-950/40 border border-emerald-600/40 rounded flex flex-col justify-center">
                <span className="text-xl font-bold text-emerald-400 tabular-nums">
                  {metrics.confusionMatrix.tn}
                </span>
                <span className="text-[10px] text-emerald-300 uppercase mt-0.5">True Negative (TN)</span>
              </div>
            </div>
          </div>

          {/* Interactive Threshold Slider */}
          <div className="p-3.5 bg-slate-950/80 rounded border border-slate-800 space-y-2">
            <div className="flex items-center justify-between text-xs">
              <span className="text-slate-300 font-medium">Alert Cutoff Threshold:</span>
              <span className="font-mono text-cyan-400 font-bold">{thresholdCutoff}%</span>
            </div>
            <input
              type="range"
              min="20"
              max="80"
              step="5"
              value={thresholdCutoff}
              onChange={(e) => setThresholdCutoff(Number(e.target.value))}
              className="w-full accent-cyan-400 cursor-pointer"
            />
            <div className="flex items-center justify-between text-[10px] text-slate-500 font-mono">
              <span>20% (Max Sensitivity / Higher False Positives)</span>
              <span>80% (High Specificity / Quiet Alerts)</span>
            </div>
          </div>
        </div>

        {/* ROC Curve & Validation Methodology */}
        <div className="lg:col-span-6 bg-slate-900/90 border border-slate-800 rounded-lg p-5 space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-sm font-bold text-white uppercase tracking-wider">
                Receiver Operating Characteristic (ROC Curve)
              </h3>
              <p className="text-xs text-slate-400 mt-0.5">
                True Positive Rate vs. False Positive Rate across all discrimination thresholds.
              </p>
            </div>
            <span className="text-xs font-mono font-bold text-cyan-400">
              AUC = {metrics.rocAuc.toFixed(3)}
            </span>
          </div>

          {/* SVG ROC Plot */}
          <div className="bg-slate-950/80 p-3 rounded border border-slate-800">
            <svg viewBox="0 0 320 220" className="w-full h-auto select-none">
              {/* Axes and reference line */}
              <line x1="40" y1="20" x2="40" y2="180" stroke="#475569" strokeWidth="1" />
              <line x1="40" y1="180" x2="300" y2="180" stroke="#475569" strokeWidth="1" />
              {/* Diagonal chance line */}
              <line x1="40" y1="180" x2="300" y2="20" stroke="#334155" strokeWidth="1" strokeDasharray="3 3" />

              {/* Grid */}
              {[0.25, 0.5, 0.75].map((g, idx) => (
                <g key={idx}>
                  <line
                    x1="40"
                    y1={180 - g * 160}
                    x2="300"
                    y2={180 - g * 160}
                    stroke="#1e293b"
                    strokeWidth="0.5"
                  />
                  <line
                    x1={40 + g * 260}
                    y1="20"
                    x2={40 + g * 260}
                    y2="180"
                    stroke="#1e293b"
                    strokeWidth="0.5"
                  />
                </g>
              ))}

              {/* ROC Curve Path */}
              {(() => {
                const pts = metrics.rocCurve.map(
                  (pt) => `${40 + pt.fpr * 260},${180 - pt.tpr * 160}`
                );
                return (
                  <path
                    d={`M ${pts.join(' L ')}`}
                    fill="none"
                    stroke="#06b6d4"
                    strokeWidth="2.5"
                    strokeLinecap="round"
                  />
                );
              })()}

              {/* Points */}
              {metrics.rocCurve.map((pt, i) => (
                <circle
                  key={i}
                  cx={40 + pt.fpr * 260}
                  cy={180 - pt.tpr * 160}
                  r="3.5"
                  fill="#06b6d4"
                  stroke="#0f172a"
                  strokeWidth="1"
                />
              ))}

              {/* Axis Labels */}
              <text x="170" y="205" textAnchor="middle" className="text-[10px] fill-slate-400 font-mono">
                False Positive Rate (1 - Specificity)
              </text>
              <text
                x="15"
                y="100"
                textAnchor="middle"
                transform="rotate(-90 15 100)"
                className="text-[10px] fill-slate-400 font-mono"
              >
                True Positive Rate (Sensitivity)
              </text>
            </svg>
          </div>

          {/* Scientific Anti-Leakage Rigor Notice */}
          <div className="p-3 bg-slate-950/70 border border-slate-800 rounded text-xs text-slate-300 space-y-1.5">
            <div className="flex items-center gap-1.5 text-cyan-400 font-semibold text-[11px] uppercase tracking-wider">
              <ShieldCheck className="w-4 h-4" />
              <span>Data Leakage Prevention Guarantee</span>
            </div>
            <p className="text-[11px] text-slate-400 leading-relaxed">
              In clinical ICU time-series, random row-level train/test splitting causes severe optimistic data leakage because a patient&apos;s past and future vitals bleed across sets. SepsisGuard enforces <strong>patient-level stratified partitioning</strong>: all hourly rows for any patient exist strictly in train or strictly in holdout test.
            </p>
          </div>
        </div>
      </div>

      {/* Model Feature Weights & Engineering Breakdown */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-lg p-5 space-y-3">
        <h3 className="text-xs font-bold text-slate-300 uppercase tracking-wider">
          Features Utilized in Selected Model Architecture ({selectedEvaluationModel})
        </h3>
        <div className="flex flex-wrap gap-2">
          {metrics.featuresUsed.map((feat, idx) => (
            <span
              key={idx}
              className="text-xs font-mono px-3 py-1.5 rounded bg-slate-950 border border-slate-800 text-slate-200"
            >
              {feat}
            </span>
          ))}
        </div>
      </div>
    </div>
  );
};
