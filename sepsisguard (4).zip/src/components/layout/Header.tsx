/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import {
  Bell,
  Sun,
  Moon,
  UserCheck,
  ChevronDown,
  RotateCcw,
  Activity,
  Play,
  Pause,
  AlertTriangle,
} from 'lucide-react';
import { UserRole } from '../../types/sepsis';

export const Header: React.FC = () => {
  const {
    currentUser,
    switchUserRole,
    unacknowledgedAlertsCount,
    setCurrentView,
    isDarkMode,
    toggleDarkMode,
    resetEntireDemo,
    isSimulating,
    toggleSimulation,
    patients,
  } = useApp();

  const [roleMenuOpen, setRoleMenuOpen] = useState(false);

  const worseningCount = patients.filter((p) => p.latestPrediction?.trend === 'Worsening').length;
  const criticalCount = patients.filter((p) => p.latestPrediction?.riskLevel === 'CRITICAL').length;

  return (
    <header className="h-16 px-6 border-b border-slate-800 bg-slate-900/90 backdrop-blur-md sticky top-0 z-30 flex items-center justify-between">
      {/* Zone 1: Brand Wordmark (Single text element) */}
      <div className="flex items-center gap-3">
        <a
          href="#overview"
          onClick={(e) => {
            e.preventDefault();
            setCurrentView('overview');
          }}
          className="text-lg font-bold tracking-tight text-white hover:text-cyan-400 transition-colors flex items-center gap-2"
        >
          <span className="w-2.5 h-2.5 rounded-sm bg-cyan-400 animate-pulse" />
          SepsisGuard
        </a>
        <span className="text-xs text-slate-500 font-mono hidden md:inline">ICU EARLY WARNING CDS</span>
      </div>

      {/* Zone 2: Clinical Telemetry Breadcrumb / Quick Stats */}
      <div className="hidden lg:flex items-center gap-5 text-xs text-slate-400">
        <div className="flex items-center gap-2">
          <span className="text-slate-500">ICU Census:</span>
          <span className="font-mono text-slate-200 font-medium tabular-nums">{patients.length} Beds</span>
        </div>
        <span className="text-slate-700">·</span>
        <div className="flex items-center gap-2">
          <span className="text-slate-500">Worsening:</span>
          <span className={`font-mono font-medium tabular-nums ${worseningCount > 0 ? 'text-amber-400' : 'text-slate-300'}`}>
            {worseningCount} Patients
          </span>
        </div>
        <span className="text-slate-700">·</span>
        <div className="flex items-center gap-2">
          <span className="text-slate-500">Critical Risk:</span>
          <span className={`font-mono font-medium tabular-nums ${criticalCount > 0 ? 'text-rose-400 font-semibold' : 'text-slate-300'}`}>
            {criticalCount}
          </span>
        </div>
        {isSimulating && (
          <>
            <span className="text-slate-700">·</span>
            <div className="flex items-center gap-1.5 text-cyan-400 font-mono text-[11px] animate-pulse">
              <span className="w-1.5 h-1.5 rounded-full bg-cyan-400" />
              <span>SIMULATION ACTIVE</span>
            </div>
          </>
        )}
      </div>

      {/* Zone 3: Primary Actions (Alerts, Persona Switcher, Simulation toggle, Theme) */}
      <div className="flex items-center gap-3">
        {/* Simulation Quick Toggle */}
        <button
          onClick={toggleSimulation}
          title={isSimulating ? 'Pause simulation engine' : 'Start real-time simulation'}
          className={`flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded border transition-colors ${
            isSimulating
              ? 'bg-cyan-950/70 border-cyan-500/40 text-cyan-300 hover:bg-cyan-900/60'
              : 'bg-slate-800 border-slate-700 text-slate-300 hover:bg-slate-700 hover:text-white'
          }`}
        >
          {isSimulating ? (
            <>
              <Pause className="w-3.5 h-3.5 text-cyan-400" />
              <span className="hidden sm:inline">Pause Sim</span>
            </>
          ) : (
            <>
              <Play className="w-3.5 h-3.5 text-slate-400" />
              <span className="hidden sm:inline">Live Sim</span>
            </>
          )}
        </button>

        {/* Alerts Bell */}
        <button
          onClick={() => setCurrentView('alerts')}
          className="relative p-2 text-slate-400 hover:text-white rounded hover:bg-slate-800 transition-colors"
          title="Clinical Alerts Queue"
        >
          <Bell className="w-4 h-4" />
          {unacknowledgedAlertsCount > 0 && (
            <span className="absolute -top-0.5 -right-0.5 w-4 h-4 rounded-full bg-rose-500 text-white text-[10px] font-bold flex items-center justify-center font-mono">
              {unacknowledgedAlertsCount}
            </span>
          )}
        </button>

        {/* User Role Switcher Dropdown */}
        <div className="relative">
          <button
            onClick={() => setRoleMenuOpen(!roleMenuOpen)}
            className="flex items-center gap-2 px-2.5 py-1.5 rounded border border-slate-700 bg-slate-800/80 text-xs text-slate-200 hover:bg-slate-700 transition-colors"
          >
            <UserCheck className="w-3.5 h-3.5 text-cyan-400" />
            <div className="text-left hidden sm:block">
              <div className="font-semibold leading-none">{currentUser.name.split(',')[0]}</div>
              <div className="text-[10px] text-slate-400 font-mono mt-0.5">{currentUser.role}</div>
            </div>
            <ChevronDown className="w-3 h-3 text-slate-400" />
          </button>

          {roleMenuOpen && (
            <div
              className="absolute right-0 mt-2 w-64 rounded-md border border-slate-700 bg-slate-900 shadow-xl py-1.5 z-50 text-xs"
              onMouseLeave={() => setRoleMenuOpen(false)}
            >
              <div className="px-3 py-1.5 text-[11px] font-semibold text-slate-400 uppercase tracking-wider border-b border-slate-800">
                Switch Clinician Persona
              </div>

              {(['Doctor', 'Nurse', 'Admin/Researcher'] as UserRole[]).map((role) => (
                <button
                  key={role}
                  onClick={() => {
                    switchUserRole(role);
                    setRoleMenuOpen(false);
                  }}
                  className={`w-full text-left px-3 py-2 flex flex-col gap-0.5 hover:bg-slate-800 transition-colors ${
                    currentUser.role === role ? 'bg-cyan-950/40 text-cyan-300 font-medium' : 'text-slate-300'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <span>
                      {role === 'Doctor'
                        ? 'Dr. Sarah Lin, MD'
                        : role === 'Nurse'
                        ? 'Marcus Vance, RN'
                        : 'Dr. Elena Rostova, PhD'}
                    </span>
                    <span className="text-[10px] font-mono text-slate-500">{role}</span>
                  </div>
                  <span className="text-[10px] text-slate-400">
                    {role === 'Doctor'
                      ? 'Attending Intensivist'
                      : role === 'Nurse'
                      ? 'MICU Staff Nurse'
                      : 'AI/ML Researcher & Admin'}
                  </span>
                </button>
              ))}

              <div className="border-t border-slate-800 mt-1 pt-1 px-3 py-1">
                <button
                  onClick={() => {
                    resetEntireDemo();
                    setRoleMenuOpen(false);
                  }}
                  className="w-full text-left text-[11px] text-slate-400 hover:text-rose-300 flex items-center gap-1.5 py-1"
                >
                  <RotateCcw className="w-3 h-3" />
                  Reset Demo State & Cohort
                </button>
              </div>
            </div>
          )}
        </div>

        {/* Theme Toggle */}
        <button
          onClick={toggleDarkMode}
          className="p-2 text-slate-400 hover:text-white rounded hover:bg-slate-800 transition-colors"
          title={isDarkMode ? 'Switch to light mode' : 'Switch to dark mode'}
        >
          {isDarkMode ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
        </button>
      </div>
    </header>
  );
};
