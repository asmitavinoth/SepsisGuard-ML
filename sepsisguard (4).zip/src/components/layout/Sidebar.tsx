/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { useApp, NavView } from '../../context/AppContext';
import {
  Activity,
  LayoutGrid,
  Users,
  Bell,
  Cpu,
  PlayCircle,
  FileText,
  UploadCloud,
  ShieldCheck,
  Sliders,
  ShieldAlert,
} from 'lucide-react';

interface NavItem {
  id: NavView;
  label: string;
  icon: React.ComponentType<{ className?: string }>;
  badge?: number | string;
  roleRestriction?: string;
}

export const Sidebar: React.FC = () => {
  const { currentView, setCurrentView, unacknowledgedAlertsCount, isSimulating, currentUser } = useApp();

  const navItems: NavItem[] = [
    { id: 'overview', label: 'Overview', icon: Activity },
    { id: 'icu-monitor', label: 'ICU Monitor', icon: LayoutGrid },
    { id: 'patients', label: 'Patients', icon: Users },
    {
      id: 'alerts',
      label: 'Alerts',
      icon: Bell,
      badge: unacknowledgedAlertsCount > 0 ? unacknowledgedAlertsCount : undefined,
    },
    { id: 'model-performance', label: 'Model Performance', icon: Cpu },
    {
      id: 'simulation',
      label: 'Simulation',
      icon: PlayCircle,
      badge: isSimulating ? 'LIVE' : undefined,
    },
    { id: 'reports', label: 'Reports', icon: FileText },
    { id: 'data-import', label: 'Data Import', icon: UploadCloud },
    { id: 'audit-logs', label: 'Audit Logs', icon: ShieldCheck },
    { id: 'settings', label: 'Settings', icon: Sliders },
  ];

  return (
    <aside className="w-64 border-r border-slate-800 bg-slate-900/50 flex flex-col shrink-0 min-h-[calc(100vh-4rem)]">
      {/* Clinician Active Role Summary */}
      <div className="p-4 border-b border-slate-800/80">
        <div className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider">
          Active Clinician View
        </div>
        <div className="mt-1 flex items-center justify-between">
          <span className="text-sm font-semibold text-slate-200 truncate">{currentUser.name}</span>
          <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-slate-800 text-cyan-400 border border-slate-700">
            {currentUser.role}
          </span>
        </div>
        <div className="text-[11px] text-slate-400 truncate mt-0.5">{currentUser.department}</div>
      </div>

      {/* Navigation Links */}
      <nav className="p-3 space-y-1 flex-1 overflow-y-auto">
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = currentView === item.id;

          return (
            <button
              key={item.id}
              onClick={() => setCurrentView(item.id)}
              className={`w-full flex items-center justify-between px-3 py-2 rounded-md text-xs font-medium transition-colors ${
                isActive
                  ? 'bg-cyan-500/15 text-cyan-300 border border-cyan-500/30'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
              }`}
            >
              <div className="flex items-center gap-2.5">
                <Icon
                  className={`w-4 h-4 shrink-0 ${
                    isActive ? 'text-cyan-400' : 'text-slate-500'
                  }`}
                />
                <span className="truncate">{item.label}</span>
              </div>

              {item.badge !== undefined && (
                <span
                  className={`text-[10px] font-mono px-1.5 py-0.2 rounded font-semibold ${
                    item.id === 'alerts'
                      ? 'bg-rose-500 text-white'
                      : item.id === 'simulation'
                      ? 'bg-cyan-500 text-slate-950 animate-pulse'
                      : 'bg-slate-800 text-slate-300'
                  }`}
                >
                  {item.badge}
                </span>
              )}
            </button>
          );
        })}
      </nav>

      {/* Safety Notice in Sidebar Footer */}
      <div className="p-3.5 border-t border-slate-800 bg-slate-950/40 text-[11px] text-slate-400 space-y-1.5">
        <div className="flex items-center gap-1.5 text-amber-400/90 font-semibold text-[10px] uppercase tracking-wider">
          <ShieldAlert className="w-3.5 h-3.5 shrink-0" />
          <span>Research Prototype</span>
        </div>
        <p className="text-[11px] text-slate-400 leading-snug">
          Predictions are statistical estimations for investigational decision support. Not a medical device.
        </p>
      </div>
    </aside>
  );
};
