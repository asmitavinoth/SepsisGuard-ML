/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { AppProvider, useApp } from './context/AppContext';
import { Header } from './components/layout/Header';
import { Sidebar } from './components/layout/Sidebar';
import { OverviewView } from './components/views/OverviewView';
import { IcuMonitorView } from './components/views/IcuMonitorView';
import { PatientsView } from './components/views/PatientsView';
import { AlertsView } from './components/views/AlertsView';
import { ModelPerformanceView } from './components/views/ModelPerformanceView';
import { SimulationView } from './components/views/SimulationView';
import { DataImportView } from './components/views/DataImportView';
import { ReportsView } from './components/views/ReportsView';
import { AuditLogsView } from './components/views/AuditLogsView';
import { SettingsView } from './components/views/SettingsView';

const AppContent: React.FC = () => {
  const { currentView } = useApp();

  const renderCurrentView = () => {
    switch (currentView) {
      case 'overview':
        return <OverviewView />;
      case 'icu-monitor':
        return <IcuMonitorView />;
      case 'patients':
        return <PatientsView />;
      case 'alerts':
        return <AlertsView />;
      case 'model-performance':
        return <ModelPerformanceView />;
      case 'simulation':
        return <SimulationView />;
      case 'data-import':
        return <DataImportView />;
      case 'reports':
        return <ReportsView />;
      case 'audit-logs':
        return <AuditLogsView />;
      case 'settings':
        return <SettingsView />;
      default:
        return <OverviewView />;
    }
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans selection:bg-cyan-500/30 selection:text-cyan-200">
      {/* Top Header */}
      <Header />

      {/* Main Layout Container */}
      <div className="flex-1 flex overflow-hidden">
        {/* Desktop Sidebar (hidden during print) */}
        <div className="hidden md:block print:hidden">
          <Sidebar />
        </div>

        {/* Viewport Content */}
        <main className="flex-1 overflow-y-auto p-4 sm:p-6 lg:p-8 bg-gradient-to-b from-slate-950 via-slate-900/40 to-slate-950">
          <div className="max-w-7xl mx-auto">
            {renderCurrentView()}
          </div>
        </main>
      </div>

      {/* Persistent Disclaimer Footer */}
      <footer className="print:hidden border-t border-slate-900 bg-slate-950 px-6 py-2.5 text-center text-[11px] text-slate-500 flex flex-col sm:flex-row items-center justify-between gap-2">
        <div className="flex items-center gap-2">
          <span className="w-1.5 h-1.5 rounded-full bg-cyan-400" />
          <span>SepsisGuard ICU Early Warning System v2.4.1</span>
          <span className="text-slate-700">·</span>
          <span className="text-amber-400 font-medium">SYNTHETIC DATA ONLY — NOT REAL PATIENT DATA</span>
        </div>
        <div>
          <span>Research and educational prototype. Predictions must not replace professional clinical judgment.</span>
        </div>
      </footer>
    </div>
  );
};

export default function App() {
  return (
    <AppProvider>
      <AppContent />
    </AppProvider>
  );
}
