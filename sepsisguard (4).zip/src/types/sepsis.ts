/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export type RiskLevel = 'LOW' | 'MODERATE' | 'HIGH' | 'CRITICAL';
export type TrendDirection = 'Improving' | 'Stable' | 'Worsening';
export type MLModelType = 'Logistic Regression' | 'Random Forest' | 'Gradient Boosted Trees (XGBoost)';
export type AlertSeverity = 'low' | 'moderate' | 'high' | 'critical';
export type UserRole = 'Admin/Researcher' | 'Doctor' | 'Nurse';

export interface UserProfile {
  id: string;
  name: string;
  role: UserRole;
  department: string;
}

export interface PatientMeasurement {
  id: string;
  patientId: string;
  timestamp: string; // ISO string
  
  // Vitals
  heartRate: number; // bpm (normal: 60-100)
  sbp: number; // mmHg (normal: 90-120)
  dbp: number; // mmHg (normal: 60-80)
  map: number; // mmHg (calculated or measured, normal: 70-105)
  respiratoryRate: number; // breaths/min (normal: 12-20)
  temperature: number; // °C (normal: 36.1 - 37.5)
  spo2: number; // % (normal: 95-100)

  // Labs
  wbc: number; // x10^9/L (normal: 4.5 - 11.0)
  lactate: number; // mmol/L (normal: 0.5 - 2.0, critical > 2.0, septic shock > 4.0)
  platelets: number; // x10^9/L (normal: 150 - 450)
  creatinine: number; // mg/dL (normal: 0.6 - 1.2)
  glucose: number; // mg/dL (normal: 70 - 140)

  // Derived & Engineered Features
  shockIndex?: number; // HR / SBP (normal: 0.5-0.7, > 0.9 ominous)
  sirsCriteriaMet?: number; // 0-4
  qSofaScore?: number; // 0-3 (RR >= 22, SBP <= 100, altered mental status)
  deltaLactate6h?: number; // rate of change in past 6h
  mapDeficit?: number; // max(0, 65 - MAP)
  pulsePressure?: number; // SBP - DBP

  // Quality assessment
  isSynthetic?: boolean;
}

export interface DataQualityReport {
  score: number; // 0-100
  level: 'High' | 'Moderate' | 'Low';
  isStale: boolean;
  hoursSinceLastMeasurement: number;
  imputedFields: string[];
  outlierFields: string[];
  notes: string;
}

export interface FeatureContribution {
  featureKey: string;
  label: string;
  currentValue: number;
  unit: string;
  normalRange: string;
  contributionPercent: number; // e.g. +18.4% or -4.2%
  direction: 'risk_increasing' | 'risk_decreasing';
  clinicalInterpretation: string;
}

export interface PredictionResult {
  patientId: string;
  timestamp: string;
  riskScore: number; // 0 to 100%
  riskLevel: RiskLevel;
  trend: TrendDirection;
  projectedRisk6h: number;
  projectedRisk12h: number;
  confidenceScore: number; // 0-100%
  dataQuality: DataQualityReport;
  modelUsed: MLModelType;
  modelVersion: string;
  baseExpectedRisk: number; // Population base rate (~14.5%)
  featureContributions: FeatureContribution[];
  alertTriggered: boolean;
  alertSeverity?: AlertSeverity;
}

export interface Patient {
  id: string;
  mrn: string;
  name: string;
  age: number;
  sex: 'Male' | 'Female' | 'Other';
  bed: string;
  admissionDate: string;
  admissionDiagnosis: string;
  weightKg: number;
  codeStatus: string;
  
  // Historical measurements in chronological order
  history: PatientMeasurement[];
  
  // Latest evaluation
  latestPrediction?: PredictionResult;
  latestMeasurement?: PatientMeasurement;
  
  // Clinical Notes & Documentation
  clinicalNotes?: ClinicalNote[];

  // Flags
  isSimulationPatient?: boolean;
  scenarioType?: 'stable' | 'gradual_deterioration' | 'rapid_deterioration' | 'recovery';
}

export type ClinicalNoteCategory =
  | 'Assessment & Plan'
  | 'Bedside Evaluation'
  | 'Resuscitation Response'
  | 'Diagnostic Workup'
  | 'Attending Sign-Off';

export interface ClinicalNote {
  id: string;
  patientId: string;
  authorId: string;
  authorName: string;
  authorRole: UserRole;
  authorTitle: string;
  timestamp: string;
  lastEditedAt?: string;
  lastEditedBy?: string;
  category: ClinicalNoteCategory;
  title: string;
  content: string;
  linkedRiskScore: number;
  linkedRiskLevel: RiskLevel;
  linkedObservationTime: string;
  linkedObservationId?: string;
  isConfidential?: boolean;
}

export interface ClinicalAlert {
  id: string;
  patientId: string;
  patientName: string;
  bed: string;
  riskScore: number;
  severity: AlertSeverity;
  headline: string;
  primaryReason: string;
  contributingFactors: string[];
  timestamp: string;
  status: 'active' | 'acknowledged';
  acknowledgedBy?: string;
  acknowledgedAt?: string;
  clinicalNote?: string;
}

export interface AuditLogEntry {
  id: string;
  timestamp: string;
  userId: string;
  userName: string;
  userRole: UserRole;
  category: 'PREDICTION' | 'ALERT' | 'SYSTEM' | 'IMPORT' | 'REPORT' | 'AUTH' | 'SETTINGS';
  action: string;
  details: string;
  patientId?: string;
}

export interface RiskThresholds {
  lowMax: number; // default: 25
  moderateMax: number; // default: 50
  highMax: number; // default: 75
  // >= highMax is CRITICAL
}

export interface ModelMetrics {
  modelType: MLModelType;
  sampleSize: number;
  accuracy: number;
  precision: number;
  recall: number; // Sensitivity
  specificity: number;
  f1Score: number;
  rocAuc: number;
  prAuc: number;
  confusionMatrix: {
    tp: number;
    fp: number;
    tn: number;
    fn: number;
  };
  rocCurve: { fpr: number; tpr: number; threshold: number }[];
  prCurve: { recall: number; precision: number }[];
  featuresUsed: string[];
}
